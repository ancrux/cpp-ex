#ifndef _MIME_HEADER_H_
#define _MIME_HEADER_H_

// MIME_Header is deprecated!!! Don't use it again unless for backward-compatibility

#include "Config.h"

#include "String.h"
#include "Codec.h"

#include <list>

namespace aos {

class AOS_API MIME_Header
{
public:
	typedef std::list< std::pair< std::string, std::string > > Pairs;

public:
	enum
	{
		No_Parser = 0,
		Decode_Parser,
		Address_Parser,
		Attribute_Parser
	};

public:
	MIME_Header();
	MIME_Header(const std::string& header, int parser = MIME_Header::No_Parser);
	~MIME_Header();

public:
	void assign(const std::string& header, int parser = MIME_Header::No_Parser);
	void parse(int parser); // if fails, clear list_ & set parser_ to No_Parser
	void apply(std::string& header);

public:
	Pairs::iterator begin() { return pairs_.begin(); };
	Pairs::iterator end() { return pairs_.end(); };

public:
	const std::string& name() { return name_; };
	const std::string& value() { return value_; };
	int parser_type() { return parser_; }; // get parser type
	void dump()
	{
		::printf("name:%s\tparser:%d\n", this->name().c_str(), this->parser_type());
		::printf("value:%s\n", this->value().c_str());
		for(Pairs::iterator it = pairs_.begin(); it != pairs_.end(); ++it)
		{
			::printf("<%s,%s> ", it->first.c_str(), it->second.c_str());
		}
		::printf("\n");
	};

public:
	void decode(const std::string& value) { parse_decode_(value); };
	void address(const std::string& value) { parse_address_(value); };
	void attribute(const std::string& value) { parse_attribute_(value); };

protected:
	void parse_nothing_(const std::string& value); // no parser
	void parse_decode_(const std::string& value); // parse decode charset
	void parse_address_(const std::string& value); // parse email addresses
	void parse_attribute_(const std::string& value); // parse attribute key/value
	void trim_quote_(std::string& value); // trim double quote '"'

protected:
	std::string name_; // header name
	std::string value_; // header value
	int parser_; // parser type
	Pairs pairs_; // parse result
};

} // namespace aos

#endif // _MIME_HEADER_H_
