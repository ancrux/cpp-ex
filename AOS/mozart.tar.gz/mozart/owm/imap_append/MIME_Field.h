#ifndef _MIME_FIELD_H_
#define _MIME_FIELD_H_

#include "Config.h"

#include "String.h"

namespace aos {

class AOS_API MIME_Field
{
public:
	MIME_Field()
	:
	pos_(0)
	{
	};
	MIME_Field(const std::string& field)
	{
		attach(field);
	};
	void attach(const std::string& field)
	{
		pos_ = 0;
		toker_.str(field.c_str(), field.size());
	};
	void detach()
	{
		pos_ = 0;
		name_.clear();
		value_.clear();
	};
	int next()
	{
		int ch;
		if ( pos_ == 0 )
		{
			toker_.set_separator(":");
			ch = toker_.next();
			if ( ch == ':' )
			{
				// read name
				name_.assign(toker_.token(), toker_.size());
				name_ += ':';

				// read value
				toker_.set_separator(";\r\n");
				ch = toker_.next();
				if ( ch <= aos::Tokenizer::End ) { pos_ = 0; return pos_; }
				value_.assign(toker_.token(), toker_.size());
				trim_value(value_);
			}
			else { pos_ = 0; return pos_; }
		}
		else
		{
			// read name
			toker_.set_separator("=\r\n\t ");
			ch = toker_.next();
			if ( ch <= aos::Tokenizer::End ) { pos_ = 0; return pos_; }
			name_.assign(toker_.token(), toker_.size());

			// read value
			toker_.set_separator(";\r\n");
			ch = toker_.next();
			if ( ch <= aos::Tokenizer::End ) { pos_ = 0; return pos_; }
			value_.assign(toker_.token(), toker_.size());
			trim_value(value_);
		}
		
		return ++pos_;
	};

public:
	std::string& name() { return name_; };
	std::string& value() { return value_; };

protected:
	void trim_value(std::string& value)
	{
		aos::trim(value);
		if ( value.size() > 1 )
		{
			if ( value[0] == value[value.size()-1] && value[0] == '"' )
			{
				value.erase(value.end()-1, value.end());
				value.erase(value.begin(), value.begin()+1);
			}
		}
	};

protected:
	aos::Tokenizer toker_;
	int pos_;
	std::string name_;
	std::string value_;
};

} // namespace aos

#endif // _MIME_FIELD_H_
