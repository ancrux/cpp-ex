#include "MBox_Reader.h"

MBox_Reader::MBox_Reader()
:
fp_(NULL)
{
}

MBox_Reader::~MBox_Reader()
{
	this->close();
}

int
MBox_Reader::open(const char* mbox_file)
{
	if ( fp_ ) this->close(); // close FILE before open

	fp_ = ACE_OS::fopen(mbox_file, "rb");
	if ( !fp_ ) return -1;

	char buf[MAX_LINE_SIZE+1];
	ACE_OS::fgets(buf, MAX_LINE_SIZE, fp_);
	if ( ACE_OS::strncmp(buf, "From ", 5) != 0 )
	{
		this->close();
		return -1;
	}

	return 0;
}

int
MBox_Reader::close()
{
	int rc = 0;
	if ( fp_ )
	{
		rc = ACE_OS::fclose(fp_);
		if ( rc == 0 ) fp_ = NULL;
	}

	return rc;
}

int
MBox_Reader::fetch_next_to_data(std::string& data)
{
	if ( fp_ )
	{
		data.resize(0);

		char buf[MAX_LINE_SIZE+1];
		while ( ACE_OS::fgets(buf, MAX_LINE_SIZE, fp_) != NULL )
		{
			if ( ACE_OS::strncmp(buf, "From ", 5) == 0 )
				break;

			data.append(buf);
		}

		return (int) data.size();
	}

	return -1;
}

int
MBox_Reader::fetch_next_to_file(const char* filename)
{
	return -1;
}


