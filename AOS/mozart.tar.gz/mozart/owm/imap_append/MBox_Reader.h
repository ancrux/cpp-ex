#ifndef _MBOX_READER_H_
#define _MBOX_READER_H_

#include "ace/OS.h"

#include <string>

class MBox_Reader
{
public:
	static const int MAX_LINE_SIZE = 40960;

public:
	MBox_Reader();
	~MBox_Reader();

public:
	int open(const char* mbox_file);
	int close();

public:
	int fetch_next_to_data(std::string& data);
	int fetch_next_to_file(const char* filename);

protected:
	FILE* fp_;
};

#endif
