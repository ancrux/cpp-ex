
int mboxfile_to_imap4(const char* server, u_short port, int ssl, const char* user, const char* pass, const char* mbox, const char* mbox_file)
{
	ACE_Time_Value t1 = ACE_OS::gettimeofday();
	size_t n_sent_mail = 0;
	size_t n_sent_byte = 0;
	size_t n_total_mail = 0;
	size_t n_total_byte = 0;

	int is_login = 0;

	if ( ssl )
	{
		//ACE_INET_Addr server_addr(143, "zcsdemo.cellopoint.com");
		//ACE_SOCK_Connector connector;
		//ACE_SOCK_Stream stream;

		ACE_INET_Addr server_addr(port, server); // SSL
		ACE_SSL_SOCK_Connector connector; // SSL
		aos::SSL_Socket_Stream stream; //ACE_SSL_SOCK_Stream stream; // SSL

		ACE_Time_Value timeout(10);
		int flags = 0;

		ACE_Message_Block mb(4096); // read/write buffer
		if ( connector.connect(stream, server_addr, &timeout) != -1 )
		{
			int status = IMAP4_Client_IO::OK;

			IMAP4_Client_IO io;
			io.open("A001");

			// greetings
			io.greetings(stream, flags, &timeout, mb);
			
			// login
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.login(stream, flags, &timeout, mb, user, pass);
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
				else
					is_login = 1;
			}

			//io.capability(stream, flags, &timeout, mb);
			//io.list(stream, flags, &timeout, mb, "\"\"", "\"*\"");

			// create
			if ( status == IMAP4_Client_IO::OK )
				io.create(stream, flags, &timeout, mb, mbox); // don't care status

			// select
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.select(stream, flags, &timeout, mb, mbox);
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
			}

			MBox_Reader reader;
			if ( reader.open(mbox_file) == -1 )
			{
				ACE_OS::printf("open mbox file error!\n");
			}
			else
			{
				std::string charset("big5");

				aos::MIME_Entity e;
				std::string data;
				data.reserve(1024 * 1024);
				while( reader.fetch_next_to_data(data) > 0 )
				{
					// import eml
					e.import_data(data.c_str(), data.size());

					// process eml
					ZM_Util::zm_fix_ctype_text(e, charset.c_str());
					charset = ZM_Util::zm_get_best_charset(e, charset.c_str());
					::printf("default_charset:%s\n", charset.c_str()); //@
					ZM_Util::zm_fix_mail_header(e, charset.c_str());

					// export eml
					e.export_data(data);

					// append
					ACE_OS::printf("DATA_SIZE: %d\n", data.size());
					status = io.append_from_data(stream, flags, &timeout, mb, mbox, data.c_str(), data.size());
					if ( status != IMAP4_Client_IO::OK )
					{
						ACE_OS::printf("%s\n", io.buf().c_str());
						break;
					}
					else
					{
						++n_sent_mail;
						n_sent_byte += data.size();
					}
					++n_total_mail;
					n_total_byte += data.size();
				}

				reader.close();
			}

			//// fetch
			//std::string data;
			//io.fetch_to_data(stream, flags, &timeout, mb, "1", "BODY[]", data);
			//ACE_OS::printf("%s\n", data.c_str());

			// logout
			io.logout(stream, flags, &timeout, mb);

			io.close();
			stream.close();
		}
		else
		{
			ACE_OS::printf("connect: %s:%d failed!\n", server, port);
		}
	}
	else
	{
		ACE_INET_Addr server_addr(port, server);
		ACE_SOCK_Connector connector;
		aos::Socket_Stream stream; //ACE_SOCK_Stream stream;

		//ACE_INET_Addr server_addr(port, server); // SSL
		//ACE_SSL_SOCK_Connector connector; // SSL
		//ACE_SSL_SOCK_Stream stream; // SSL

		ACE_Time_Value timeout(10);
		int flags = 0;

		ACE_Message_Block mb(4096); // read/write buffer
		if ( connector.connect(stream, server_addr, &timeout) != -1 )
		{
			int status = IMAP4_Client_IO::OK;

			IMAP4_Client_IO io;
			io.open("A001");

			// greetings
			io.greetings(stream, flags, &timeout, mb);
			
			// login
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.login(stream, flags, &timeout, mb, user, pass);
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
				else
					is_login = 1;
			}

			//io.capability(stream, flags, &timeout, mb);
			//io.list(stream, flags, &timeout, mb, "\"\"", "\"*\"");

			// create
			if ( status == IMAP4_Client_IO::OK )
				io.create(stream, flags, &timeout, mb, mbox); // don't care status

			// select
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.select(stream, flags, &timeout, mb, mbox);
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
			}

			MBox_Reader reader;
			if ( reader.open(mbox_file) == -1 )
			{
				ACE_OS::printf("open mbox file error!\n");
			}
			else
			{
				std::string charset("big5");

				aos::MIME_Entity e;
				std::string data;
				data.reserve(1024 * 1024);
				while( reader.fetch_next_to_data(data) > 0 )
				{
					// import eml
					e.import_data(data.c_str(), data.size());

					// process eml
					ZM_Util::zm_fix_ctype_text(e, charset.c_str());
					charset = ZM_Util::zm_get_best_charset(e, charset.c_str());
					::printf("default_charset:%s\n", charset.c_str()); //@
					ZM_Util::zm_fix_mail_header(e, charset.c_str());

					// export eml
					e.export_data(data);

					// append
					status = io.append_from_data(stream, flags, &timeout, mb, mbox, data.c_str(), data.size());
					if ( status != IMAP4_Client_IO::OK )
					{
						ACE_OS::printf("%s\n", io.buf().c_str());
						break;
					}
					else
					{
						++n_sent_mail;
						n_sent_byte += data.size();
					}
					++n_total_mail;
					n_total_byte += data.size();
				}

				reader.close();
			}

			//// fetch
			//std::string data;
			//io.fetch_to_data(stream, flags, &timeout, mb, "1", "BODY[]", data);
			//ACE_OS::printf("%s\n", data.c_str());

			// logout
			io.logout(stream, flags, &timeout, mb);

			io.close();
			stream.close();
		}
		else
		{
			ACE_OS::printf("connect: %s:%d failed!\n", server, port);
		}
	}

	ACE_Time_Value t2 = ACE_OS::gettimeofday();
	double elapsed = (t2.msec()-t1.msec())/1000;
	ACE_OS::printf("sent/total=%d/%d, (%d/%d) bytes\n", n_sent_mail, n_total_mail, n_sent_byte, n_total_byte);
	ACE_OS::printf("elapsed:%.3f sec (%.3f KB/sec) (%.3f Mail/sec)\n", elapsed, n_sent_byte/elapsed/1000, n_sent_mail/elapsed);

	return (is_login)?0:-1;
}

int run_imap4_client_io(int argc, ACE_TCHAR* argv[])
{
	std::string server("localhost");
	u_short port = 143;
	int ssl = 0;
	std::string user;
	std::string pass;
	std::string mbox("INBOX");

	std::string mbox_dir;
	std::string mbox_file;

	int copyINBOX = 1;
	int copySent = 1;
	int copyDrafts = 1;
	int copyJunk = 1;
	int copyTrash = 1;
	int copyVirus =1;

	// get console parameters
	ACE_Get_Opt cmdline(argc, argv, ACE_TEXT(""));

	if ( argc < 4 )
	{
		ACE_OS::printf("Usage: %s <account> <password> <mbox_dir>\n", ACE::basename(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
		return -1;
	}

	// get configuration filename
	std::string cfg_file(ACE::basename(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
	if ( cfg_file.rfind('.') != std::string::npos ) cfg_file = ACE::dirname(cfg_file.c_str(), '.');
	cfg_file.insert(0, 1, ACE_DIRECTORY_SEPARATOR_CHAR);
	cfg_file.insert(0, ACE::dirname(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
	cfg_file += ".ini";
	ACE_OS::printf("cfg_file:%s\n", cfg_file.c_str()); //@

	// read configurattion
	ACE_Configuration_Heap config;
	config.open();

	ACE_Ini_ImpExp iniIO(config);
	iniIO.import_config(cfg_file.c_str());

	// iterate through entire file (not including sub-section iteration)
	ACE_Configuration_Section_Key sec;
	config.open_section(config.root_section(), ACE_TEXT("Server"), 0, sec);

	ACE_TString value;

	config.get_string_value(sec, ACE_TEXT("Server"), value);
	server = value.c_str();
	ACE_OS::printf("Server: %s\n", server.c_str());
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Port"), value);
	port = (u_short) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Port: %d\n", port);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("SSL"), value);
	ssl = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("SSL: %d\n", ssl);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("INBOX"), value);
	copyINBOX = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("INBOX: %d\n", copyINBOX);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Sent"), value);
	copySent = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Sent: %d\n", copySent);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Drafts"), value);
	copyDrafts = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Drafts: %d\n", copyDrafts);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Trash"), value);
	copyTrash = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Trash: %d\n", copyTrash);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Junk"), value);
	copyJunk = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Junk: %d\n", copyJunk);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Virus"), value);
	copyVirus = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Virus: %d\n", copyVirus);
	value.resize(0);

	user = argv[1];
	pass = argv[2];
	mbox_dir = argv[3];

	/*
	server = "192.168.1.19";
	port = 993;
	ssl = 1;
	//user = "angus";
	//pass = "111111";
	//*/

	std::set< std::string > skip_mbox;
	if (!copyINBOX) skip_mbox.insert("saved-messages");
	if (!copySent) skip_mbox.insert("sent-mail");
	if (!copyDrafts) skip_mbox.insert("saved-drafts");
	if (!copyTrash) skip_mbox.insert("mail-trash");
	if (!copyJunk) skip_mbox.insert("spam-mail");
	if (!copyVirus) skip_mbox.insert("virus-mail");

	std::string charset("big5");

	int rc = 0;

	// if mbox_dir is a mbox file:
	ACE_stat stat;
	if ( ACE_OS::lstat(mbox_dir.c_str(), &stat) != -1 && (stat.st_mode & S_IFMT) == S_IFREG )
	{
		mbox_file = mbox_dir;

		config.get_string_value(sec, ACE_TEXT("File"), value);
		mbox = aos::trim((char*) value.c_str());
		ACE_OS::printf("File: %s\n", mbox.c_str());
		value.resize(0);

		rc = mboxfile_to_imap4(server.c_str(), port, ssl, user.c_str(), pass.c_str(), mbox.c_str(), mbox_file.c_str());

		return rc;
	}

	// if mbox_dir is a directory:
	ACE_Dirent dir;
	ACE_DIRENT* d;

	dir.open(mbox_dir.c_str());
	while( (d = dir.read()) != 0 )
	{
		mbox_file = mbox_dir;
		mbox_file += ACE_DIRECTORY_SEPARATOR_CHAR;
		mbox_file.append(d->d_name);

		ACE_stat stat;
		if ( ACE_OS::lstat(mbox_file.c_str(), &stat) != -1 && (stat.st_mode & S_IFMT) == S_IFREG ) 
		{
			ACE_OS::printf("%s\n", mbox_file.c_str()); //@
			MBox_Reader reader;
			if ( reader.open(mbox_file.c_str()) == -1 )
			{
				ACE_OS::printf("open mbox file error!\n");
				continue;
			}

			if ( *(d->d_name) == '.' || skip_mbox.find(d->d_name) != skip_mbox.end() )
				continue;
			
			mbox.assign(d->d_name);

			UErrorCode status;
			UConverter* uconv;

			status = U_ZERO_ERROR;
			uconv = ucnv_open(charset.c_str(), &status);
			UnicodeString ustr(mbox.c_str(), (::int32_t) mbox.size(), uconv, status);
			ucnv_close(uconv);

			status = U_ZERO_ERROR;
			uconv = ucnv_open("IMAP-mailbox-name", &status);
			size_t n_max = ucnv_getMaxCharSize(uconv) * mbox.size() + 1;
			mbox.resize(n_max);
			size_t n_len = ustr.extract((char*) mbox.c_str(), (::int32_t) mbox.size(), uconv, status);
			mbox.resize(n_len);
			ucnv_close(uconv);

			// convert OpenWebmail folder to Zimbra folder
			if ( ACE_OS::strncmp(d->d_name, "saved-messages", 14) == 0 ) mbox.assign(d->d_name); // mbox = "INBOX";
			else if ( ACE_OS::strncmp(d->d_name, "sent-mail", 9) == 0 ) mbox = "Sent";
			else if ( ACE_OS::strncmp(d->d_name, "saved-drafts", 12) == 0 ) mbox = "Drafts";
			else if ( ACE_OS::strncmp(d->d_name, "mail-trash", 10) == 0 ) mbox = "Trash";
			else if ( ACE_OS::strncmp(d->d_name, "spam-mail", 9) == 0 ) mbox = "Junk";
			else if ( ACE_OS::strncmp(d->d_name, "virus-mail", 10) == 0 ) mbox = "Virus";

			if ( !mbox.empty() )
			{
				mbox = '"' + mbox + '"';
				ACE_OS::printf("%s\n", mbox.c_str()); //@
				rc = mboxfile_to_imap4(server.c_str(), port, ssl, user.c_str(), pass.c_str(), mbox.c_str(), mbox_file.c_str());
			}
		}
	}
	dir.close();

	return rc;
}

