#include "MIME_Util.h"

#include "Codec.h"
//#include "aos/String.h"

#include "unicode/utypes.h" /* Basic ICU data types */
#include "unicode/ucnv.h" /* C Converter API */
#include "unicode/ucsdet.h" /* C Detector API */

#include <boost/regex.hpp>
using namespace boost;

//#include <boost/regex/icu.hpp>
//#include <boost/xpressive/xpressive.hpp>

//#include "hash/hash_32.c"

namespace aos {

/// MIME_Header_Util

MIME_Header_Util::MIME_Header_Util(size_t line_size)
:
parser_(MIME_Header_Util::No_Parser)
{
	this->line_size(line_size);
}

MIME_Header_Util::~MIME_Header_Util()
{
}

/*
void
MIME_Header_Util::parse_encoded3(const std::string& str, int trim_crlf, int map_charset)
{
	using namespace boost::xpressive;

	pairs_.clear();
	parser_ = MIME_Header_Util::Encoded_Parser;

	std::string s;
	if ( trim_crlf )
	{
		aos::Tokenizer toker(str.c_str(), str.size());
		toker.set_separator("\r\n");

		int ch = toker.next();
		while( ch > aos::Tokenizer::End )
		{
			const char* buf = toker.token();
			size_t len = toker.size();
			if ( len > 0 && ( *buf == ' ' || *buf == '\t' ) )
			{
				++buf;
				--len;
			}
			s.append(buf, len);

			ch = toker.next();
		}
	}
	else
	{
		s.assign(str);
	}

	sregex re = sregex::compile("=\\?([^?]+)\\?(B|Q)\\?([^?]+)\\?=", boost::xpressive::regex_constants::icase );
	//static const regex re("=\\?([^?]+)\\?(B|Q)\\?([^?]+)\\?=", regex::icase);
	boost::xpressive::smatch match;

	std::string::const_iterator start = s.begin();
	std::string::const_iterator end = s.end();

	char enc = '\0';
	std::string charset;
	std::string text;
	while( regex_search(start, end, match, re) )
	{
		text.assign(start, match[0].first);
		if ( !text.empty() )
		{
			// text without charset will be merged into the last pair
			if ( !pairs_.empty() )
			{
				Pairs::iterator last = --(pairs_.end());
				last->second += text;
			}
			else
				pairs_.push_back(std::make_pair("", text));
		}
		
		charset.assign(match[1].first, match[1].second);
		enc = *(match[2].first);
		text.assign(match[3].first, match[3].second);

		if ( map_charset ) MIME_Util::map_charset(charset);

		switch(enc)
		{
			case 'B':
			case 'b':
				{
				aos::Base64 base64;
				size_t n_decode = base64.decode(text.c_str(), text.size(), (char*) text.c_str());
				text.resize(n_decode);
				break;
				}
			case 'Q':
			case 'q':
				{
				//RFC2047: 4.2. The "Q" encoding (2)
				//replace '_' with ' '
				size_t n_len = text.size();
				char* cstr = (char*) text.c_str();
				for(size_t i=0; i < n_len; ++i)
				{
					if ( *(cstr+i) == '_' ) *(cstr+i) = ' ';
				}

				aos::QP qp;
				size_t n_decode = qp.decode(text.c_str(), text.size(), (char*) text.c_str());
				text.resize(n_decode);
				break;
				}
			default:
				break;
		}

		// if the same charset as the last one, append text to the last one
		// else new entry
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			if ( aos::strnicmp(last->first.c_str(), charset.c_str(), charset.size()) == 0 )
				last->second += text;
			else
				pairs_.push_back(std::make_pair(charset, text));
		}
		else
			pairs_.push_back(std::make_pair(charset, text));

		start = match[0].second;
	}
	text.assign(start, end);
	if ( !text.empty() )
	{
		// text without charset will be merged into the last pair
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			last->second += text;
		}
		else
			pairs_.push_back(std::make_pair("", text));
	}
}
//*/

/*
void
MIME_Header_Util::parse_encoded2(const std::string& str, int trim_crlf, int map_charset)
{
	pairs_.clear();
	parser_ = MIME_Header_Util::Encoded_Parser;

	std::string s;
	if ( trim_crlf )
	{
		aos::Tokenizer toker(str.c_str(), str.size());
		toker.set_separator("\r\n");

		int ch = toker.next();
		while( ch > aos::Tokenizer::End )
		{
			const char* buf = toker.token();
			size_t len = toker.size();
			if ( len > 0 && ( *buf == ' ' || *buf == '\t' ) )
			{
				++buf;
				--len;
			}
			s.append(buf, len);

			ch = toker.next();
		}
	}
	else
	{
		s.assign(str);
	}

	static const regex re("=\\?([^?]+)\\?(B|Q)\\?([^?]+)\\?=", regex::icase);
	smatch match;

	std::string::const_iterator start = s.begin();
	std::string::const_iterator end = s.end();

	char enc = '\0';
	std::string charset;
	std::string text;
	while( regex_search(start, end, match, re) )
	{
		text.assign(start, match[0].first);
		if ( !text.empty() )
		{
			// text without charset will be merged into the last pair
			if ( !pairs_.empty() )
			{
				Pairs::iterator last = --(pairs_.end());
				last->second += text;
			}
			else
				pairs_.push_back(std::make_pair("", text));
		}
		
		charset.assign(match[1].first, match[1].second);
		enc = *(match[2].first);
		text.assign(match[3].first, match[3].second);

		if ( map_charset ) MIME_Util::map_charset(charset);

		switch(enc)
		{
			case 'B':
			case 'b':
				{
				aos::Base64 base64;
				size_t n_decode = base64.decode(text.c_str(), text.size(), (char*) text.c_str());
				text.resize(n_decode);
				break;
				}
			case 'Q':
			case 'q':
				{
				//RFC2047: 4.2. The "Q" encoding (2)
				//replace '_' with ' '
				size_t n_len = text.size();
				char* cstr = (char*) text.c_str();
				for(size_t i=0; i < n_len; ++i)
				{
					if ( *(cstr+i) == '_' ) *(cstr+i) = ' ';
				}

				aos::QP qp;
				size_t n_decode = qp.decode(text.c_str(), text.size(), (char*) text.c_str());
				text.resize(n_decode);
				break;
				}
			default:
				break;
		}

		// if the same charset as the last one, append text to the last one
		// else new entry
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			if ( aos::strnicmp(last->first.c_str(), charset.c_str(), charset.size()) == 0 )
				last->second += text;
			else
				pairs_.push_back(std::make_pair(charset, text));
		}
		else
			pairs_.push_back(std::make_pair(charset, text));

		start = match[0].second;
	}
	text.assign(start, end);
	if ( !text.empty() )
	{
		// text without charset will be merged into the last pair
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			last->second += text;
		}
		else
			pairs_.push_back(std::make_pair("", text));
	}
}
//*/

void
MIME_Header_Util::parse_encoded(const std::string& str, int trim_crlf, int map_charset)
{
	pairs_.clear();
	parser_ = MIME_Header_Util::Encoded_Parser;

	std::string s;
	if ( trim_crlf )
	{
		aos::Tokenizer toker(str.c_str(), str.size());
		toker.set_separator("\r\n");

		int ch = toker.next();
		while( ch > aos::Tokenizer::End )
		{
			const char* buf = toker.token();
			size_t len = toker.size();
			if ( len > 0 && ( *buf == ' ' || *buf == '\t' ) )
			{
				++buf;
				--len;
			}
			s.append(buf, len);

			ch = toker.next();
		}
	}
	else
	{
		s.assign(str);
	}

	std::string charset;
	std::string text;
	size_t pos_beg = 0;
	size_t pos_end = 0;

	while( (pos_end = s.find("=?", pos_beg)) != std::string::npos )
	{
		text.assign(s, pos_beg, pos_end-pos_beg);
		if ( !text.empty() )
		{
			// text without charset will be merged into the last pair
			if ( !pairs_.empty() )
			{
				Pairs::iterator last = --(pairs_.end());
				last->second += text;
			}
			else
				pairs_.push_back(std::make_pair("", text));
		}
		pos_beg = pos_end;

		size_t qmark1 = s.find('?', pos_beg+2);
		pos_end = qmark1;
		if ( qmark1 != std::string::npos && qmark1-pos_beg > 2 )
		{
			size_t qmark2 = s.find('?', qmark1+1);
			pos_end = qmark2;
			if ( qmark2 != std::string::npos && qmark2-qmark1 == 2 )
			{
				char enc = ::toupper(s[qmark1+1]);
				if ( enc == 'B' || enc == 'Q' )
				{
					size_t qmark_end = s.find("?=", qmark2+1);
					pos_end = qmark_end;
					if ( qmark_end != std::string::npos )
					{
						charset.assign(s, pos_beg+2, qmark1-pos_beg-2);
						text.assign(s, qmark2+1, qmark_end-qmark2-1);

						if ( map_charset ) MIME_Util::map_charset(charset);

						switch(enc)
						{
							case 'B':
								{
								MIME_Util::from_Base64(text);
								//aos::Base64 base64;
								//size_t n_decode = base64.decode(text.c_str(), text.size(), (char*) text.c_str());
								//text.resize(n_decode);
								break;
								}
							case 'Q':
								{
								//RFC2047: 4.2. The "Q" encoding (2)
								//replace '_' with ' '
								size_t n_len = text.size();
								char* cstr = (char*) text.c_str();
								for(size_t i=0; i < n_len; ++i)
								{
									if ( *(cstr+i) == '_' ) *(cstr+i) = ' ';
								}

								MIME_Util::from_QP(text);
								//aos::QP qp;
								//size_t n_decode = qp.decode(text.c_str(), text.size(), (char*) text.c_str());
								//text.resize(n_decode);
								break;
								}
							default:
								break;
						}

						// if the same charset as the last one, append text to the last one
						// else new entry
						if ( !pairs_.empty() )
						{
							Pairs::iterator last = --(pairs_.end());
							if ( aos::strnicmp(last->first.c_str(), charset.c_str(), charset.size()) == 0 )
								last->second += text;
							else
								pairs_.push_back(std::make_pair(charset, text));
						}
						else
							pairs_.push_back(std::make_pair(charset, text));

						pos_end += 2;
						pos_beg = pos_end;

						continue;
					}
				}
			}
		}

		text.assign(s, pos_beg, pos_end-pos_beg);
		if ( !text.empty() )
		{
			// text without charset will be merged into the last pair
			if ( !pairs_.empty() )
			{
				Pairs::iterator last = --(pairs_.end());
				last->second += text;
			}
			else
				pairs_.push_back(std::make_pair("", text));
		}
		pos_beg = pos_end;
	}

	if ( pos_beg != std::string::npos )
	{
		text.assign(s, pos_beg, std::string::npos);
		// text without charset will be merged into the last pair
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			last->second += text;
		}
		else
			pairs_.push_back(std::make_pair("", text));
	}
}

int
MIME_Header_Util::map_charset_decoded(const char* default_charset)
{
 	if ( parser_ != MIME_Header_Util::Encoded_Parser )
		return -1;

	for(MIME_Header_Util::Pairs::iterator it = pairs_.begin();
		it != pairs_.end();
		++it)
	{
		MIME_Util::map_charset(it->first, default_charset);
	}

	return 0;
}

UnicodeString&
MIME_Header_Util::build_unicode_decoded(UnicodeString& ustr)
{
	ustr.truncate(0);
	if ( parser_ != MIME_Header_Util::Encoded_Parser )
		return ustr;

	MIME_Header_Util::Pairs::iterator it = pairs_.begin();
	while( it != pairs_.end() )
	{
		if ( it->first.empty() )
		{
			ustr += it->second.c_str();
		}
		else
		{
			UErrorCode status;
			ustr += MIME_Util::to_unicode(it->second, it->first.c_str(), status);
		}
		++it;
	}

	return ustr;
}

std::string&
MIME_Header_Util::build_utf8_decoded(std::string& str)
{
	UnicodeString ustr;
	UErrorCode status = U_ZERO_ERROR;
	str = MIME_Util::from_unicode(MIME_Header_Util::build_unicode_decoded(ustr), "utf-8", status);
	return str;
}

void
MIME_Header_Util::parse_address(const std::string& str)
{
	pairs_.clear();
	parser_ = MIME_Header_Util::Address_Parser;

	const char* ptr = str.c_str();
	const char* start = ptr;
	const char* ptr_end = ptr + str.size();

	std::string item;
	std::string name;
	while( ptr < ptr_end )
	{
		if ( *ptr == '"' )
		{
			item.append(start, ptr-start);
			
			aos::QS qs;
			size_t n_decode = qs.decode(ptr, (char*) ptr);
			item.append(ptr, n_decode);

			ptr += qs.decode_read();
			start = ptr;
		}
		else if ( *ptr == ',' )
		{
			item.append(start, ptr-start);

			// process item
			bool angle_brackets = false;
			size_t angle_lpos = item.find_last_of('<');
			if ( angle_lpos != std::string::npos )
			{
				size_t angle_rpos = item.find_last_of('>');
				if ( angle_rpos != std::string::npos && angle_rpos > angle_lpos )
				{
					angle_brackets = true;
					name = item.substr(0, angle_lpos);
					pairs_.push_back(std::make_pair(aos::trim(name), item.substr(angle_lpos+1, angle_rpos-angle_lpos-1)));
				}
			}

			if ( !angle_brackets )
				pairs_.push_back(std::make_pair("", aos::trim(item)));

			start = ++ptr;

			// clear item
			item.resize(0);
		}
		else
		{
			++ptr;
		}
	}
	// process last item
	item.append(start, ptr-start);

	bool angle_brackets = false;
	size_t angle_lpos = item.find_last_of('<');
	if ( angle_lpos != std::string::npos )
	{
		size_t angle_rpos = item.find_last_of('>');
		if ( angle_rpos != std::string::npos && angle_rpos > angle_lpos )
		{
			angle_brackets = true;
			name = item.substr(0, angle_lpos);
			pairs_.push_back(std::make_pair(aos::trim(name), item.substr(angle_lpos+1, angle_rpos-angle_lpos-1)));
		}
	}

	if ( !angle_brackets )
		pairs_.push_back(std::make_pair("", aos::trim(item)));

	/*
	// aos::Tokenizer version
	int ch;
	aos::Tokenizer toker(str.c_str(), str.size());
	toker.set_separator("\",");

	std::string item;
	const char* start = str.c_str();
	while(true)
	{
		ch = toker.next(0, start);
		if ( ch <= aos::Tokenizer::End ) break;

		item.append(toker.token(), toker.size());
		size_t n_size = toker.size();
		if ( ch == '"' )
		{
			start = (toker.size())?toker.token_end():toker.token_end()-1; // zero-size contains '"'

			aos::QS qs;
			size_t n_decode = qs.decode(start, (char*) start);
			item.append(start, n_decode);

			start += qs.decode_read();
		}
		else
		{
			start = toker.token_end()+1;

			// process item
			//::printf("%s\n", item.c_str()); //@

			bool angle_brackets = false;
			size_t angle_lpos = item.find_last_of('<');
			if ( angle_lpos != std::string::npos )
			{
				size_t angle_rpos = item.find_last_of('>');
				if ( angle_rpos != std::string::npos && angle_rpos > angle_lpos )
				{
					angle_brackets = true;
					pairs_.push_back(std::make_pair(aos::trim(item.substr(0, angle_lpos)), item.substr(angle_lpos+1, angle_rpos-angle_lpos-1)));
				}
			}

			if ( !angle_brackets )
				pairs_.push_back(std::make_pair("", aos::trim(item)));

			// clear item
			item.resize(0);
		}
	}
	//*/
}

/*
void
MIME_Header_Util::parse_address2(const std::string& str)
{
	pairs_.clear();
	parser_ = MIME_Header_Util::Address_Parser;

	int ch;
	aos::Tokenizer toker;
	toker.str(str.c_str(), str.size());
	toker.set_separator(",\r\n");

	while(true)
	{
		ch = toker.next();
		if ( ch <= aos::Tokenizer::End ) break;
		std::string address(toker.token(), toker.size());

		static const regex re_addr("(.*)(<.*@.*>)", regex::icase);
		smatch match;
		std::string::const_iterator start = address.begin();
		std::string::const_iterator end = address.end();
		if ( regex_search(start, end, match, re_addr) )
		{
			std::string name(match[1].first, match[1].second);
			//aos::trim(name);
			trim_quoted_string(name);
			std::string email(match[2].first, match[2].second);

			pairs_.push_back(std::make_pair(name, email));
		}
		else
		{
			pairs_.push_back(std::make_pair("", address));
		}
	}
}
//*/

std::string&
MIME_Header_Util::build_address(std::string& str, const char* charset, char enc )
{
	str.resize(0);
	if ( parser_ != MIME_Header_Util::Address_Parser )
		return str;

	MIME_Header_Util::Pairs::iterator it = pairs_.begin();
	while( it != pairs_.end() )
	{
		//+ address name to be encoded with charset
		if ( !it->first.empty() )
		{
			//+ should use aos::QS to encode
			str += "\"";
			str += it->first; 
			str += "\" ";
		}
		if ( !it->second.empty() )
		{
			str += "<";
			str += it->second;
			str += ">, ";
		}

		++it;
	}

	if ( str.size() >= 2 )
		str.resize(str.size()-2);

	return str;
}

void
MIME_Header_Util::parse_attribute(const std::string& str)
{
	pairs_.clear();
	parser_ = MIME_Header_Util::Attribute_Parser;

	int ch;
	aos::Tokenizer toker;
	toker.str(str.c_str(), str.size());

	std::string attrib_name;
	std::string attrib_value;

	// get first attribute value followed by ':', e.g 'Content-Disposition: attachment;'
	toker.set_separator(";\r\n");
	ch = toker.next();
	if ( ch == ';' )
	{
		attrib_value.assign(toker.token(), toker.size());

		pairs_.push_back(std::make_pair("", trim_quote(attrib_value)));
	}

	// get remaining attribute value(s) followed by '=', e.g 'filename="example.pdf";'
	while(true)
	{
		// read attribute name
		toker.set_separator("=\r\n\t ");
		ch = toker.next();
		if ( ch <= aos::Tokenizer::End ) break;
		attrib_name.assign(toker.token(), toker.size());

		// read attribute value
		toker.set_separator(";\r\n");
		ch = toker.next();
		if ( ch <= aos::Tokenizer::End ) break;
		attrib_value.assign(toker.token(), toker.size());

		pairs_.push_back(std::make_pair(attrib_name, trim_quote(attrib_value)));
	}
}

std::string&
MIME_Header_Util::build_attribute(std::string& str, const char* charset, char enc)
{
	str.resize(0);
	if ( parser_ != MIME_Header_Util::Attribute_Parser )
		return str;

	MIME_Header_Util::Pairs::iterator it = pairs_.begin();
	int count = 0;
	while( it != pairs_.end() )
	{
		if ( count )
		{
			str += it->first;
			//+ attribute value to be encoded with charset
			str += "=\"";
			str += it->second;
			str += "\"; ";
		}
		else
		{
			str += it->second;
			str += "; ";
		}

		++count;
		++it;
	}

	if ( str.size() >= 2 )
		str.resize(str.size()-2);

	return str;
}

std::string&
MIME_Header_Util::trim_quoted_string(std::string& str)
{
	aos::trim(str);
	if ( str.size() > 1 )
	{
		if ( str[0] == '"' && str[0] == str[str.size()-1] )
		{
			aos::QS qs;
			size_t n_decode = qs.decode(str.c_str(), str.size(), (char*) str.c_str());
			str.resize(n_decode);
		}
	}

	return str;
}

std::string&
MIME_Header_Util::trim_quote(std::string& str)
{
	aos::trim(str);
	if ( str.size() > 1 )
	{
		if ( str[0] == '"' && str[0] == str[str.size()-1] )
		{
			str.erase(str.end()-1, str.end());
			str.erase(str.begin(), str.begin()+1);
		}
	}

	return str;
}

/// MIME_Util

UnicodeString
MIME_Util::to_unicode(const std::string& from, const char* from_charset, UErrorCode& status)
{
	status = U_ZERO_ERROR;
	UConverter* uconv = ucnv_open(from_charset, &status);
	//if ( !U_SUCCESS(status) )
	//	uconv = ucnv_open(NULL, &status);

	//UChar uc = 0x0040;
	//ucnv_setSubstString(uconv, &uc, 1, &status);

	// convert to unicode
	//status = U_ZERO_ERROR;
	UnicodeString ustr(from.c_str(), (::int32_t) from.size(), uconv, status);

	ucnv_close(uconv);

	return ustr;
}

std::string
MIME_Util::from_unicode(const UnicodeString& ustr, const char* to_charset, UErrorCode& status)
{
	status = U_ZERO_ERROR;
	UConverter* uconv = ucnv_open(to_charset, &status);
	std::string str;
	
	// convert from unicode
	if ( U_SUCCESS(status) )
	{
		size_t n_max = ucnv_getMaxCharSize(uconv) * ustr.length() + 1;
		str.resize(n_max);
		size_t n_len = ustr.extract((char*) str.c_str(), (::int32_t) str.size(), uconv, status);
		str.resize(n_len);
	}

	ucnv_close(uconv);

	return str;
}

std::string
MIME_Util::to_utf8(const std::string& from, const char* from_charset, UErrorCode& status)
{
	return MIME_Util::from_unicode(MIME_Util::to_unicode(from, from_charset, status), "utf-8", status);
}

std::string
MIME_Util::from_utf8(const std::string& utf8, const char* to_charset, UErrorCode& status)
{
	return MIME_Util::from_unicode(MIME_Util::to_unicode(utf8, "utf-8", status), to_charset, status);
}

size_t
MIME_Util::to_Base64(std::string& str, size_t line_size)
{
	aos::Base64 base64(line_size);
	std::string tmp(str);

	size_t n_enough_encode = base64.enough_encode_size(tmp.size());
	str.resize(n_enough_encode);
	size_t n_encode = base64.encode(tmp.c_str(), tmp.size(), (char*) str.c_str());
	str.resize(n_encode);

	return n_encode;
}

size_t
MIME_Util::from_Base64(std::string& str)
{
	aos::Base64 base64;
	size_t n_decode = base64.decode(str.c_str(), str.size(), (char*) str.c_str());
	str.resize(n_decode);

	return n_decode;
}

size_t
MIME_Util::to_QP(std::string& str, size_t line_size)
{
	aos::QP qp(line_size);
	std::string tmp(str);

	size_t n_enough_encode = qp.enough_encode_size(tmp.size());
	str.resize(n_enough_encode);
	size_t n_encode = qp.encode(tmp.c_str(), tmp.size(), (char*) str.c_str());
	str.resize(n_encode);

	return n_encode;
}

size_t
MIME_Util::from_QP(std::string& str)
{
	aos::QP qp;
	size_t n_decode = qp.decode(str.c_str(), str.size(), (char*) str.c_str());
	str.resize(n_decode);

	return n_decode;
}

void
MIME_Util::map_charset(std::string& charset, const char* default_charset)
{
	aos::tolower(charset);
	if ( charset.empty() && default_charset ) charset = default_charset;
	else if ( charset.find("utf-7") != std::string::npos ) charset = "utf-7";
	else if ( charset.find("gb2312") != std::string::npos ) charset = "gbk";
	else if ( charset.find("big5") != std::string::npos ) charset = "big5";
}

int
MIME_Util::check_charset(const char* buf, size_t len, const char* charset)
{
	std::string before(buf, len);

	UErrorCode status = U_ZERO_ERROR;
	UnicodeString ustr = MIME_Util::to_unicode(before, charset, status);
	std::string after = MIME_Util::from_unicode(ustr, charset, status);

	//std::string guess_charset = MIME_Util::guess_charset(buf, len); //@
	
	int n_match = 0;
	const char* longer;
	const char* shorter;
	longer = (after.size() > before.size())?after.c_str():before.c_str();
	shorter = (longer == after.c_str())?before.c_str():after.c_str();

	// compare first for match count
	if ( *longer == *shorter )
		++n_match;

	//// compare all for match count
	//while( *longer && *shorter )
	//{
	//	if ( *longer == *shorter )
	//	{
	//		++longer;
	//		++shorter;
	//		++n_match;
	//	}
	//	else
	//		++longer;
	//}

	return n_match;
}

void
MIME_Util::decode_body(MIME_Entity& e, int process_child)
{
	e.decode_body();
	if ( e.has_child() && process_child )
	{
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			MIME_Util::decode_body(*(*it), process_child);
		}
	}
}

void
MIME_Util::encode_body(MIME_Entity& e, int process_child)
{
	e.encode_body();
	if ( e.has_child() && process_child )
	{
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			MIME_Util::encode_body(*(*it), process_child);
		}
	}
}

void
MIME_Util::get_url(MIME_Entity& e, std::set< std::string >& url_set)
{
	url_set.clear();

	if ( e.child().empty() )
	{
		//::printf("[BODY ctype='%s' encoding='%s' charset='%s']\n", e.get_content_type().c_str(), e.get_encoding().c_str(), e.get_charset().c_str());

		if ( e.get_primary_type() == "text" )
		{
			int res = e.decode_body();

			//static const regex re(
			//	"("
			//	"https?://([a-z0-9][a-z0-9_-]*)(\\.[a-z0-9][a-z0-9_-]*)+"
			//	"(:\\d+)?"
			//	"(/?[a-z0-9:#@%/;$(){}~_?&=\\+\\\\\\.-]*)"
			//	")"
			//	, regex::icase);
			static const regex re(
				"("
				"https?://[a-z0-9:#@%/;$(){}~_?&=\\+\\\\\\.-]+"
				")"
				, regex::icase);

			smatch match;
		
			std::string& body = e.body();
			std::string::const_iterator start = body.begin();
			std::string::const_iterator end = body.end();

			while ( regex_search(start, end, match, re) )
			{
				std::string url;
				url.assign(match[1].first, match[1].second);

				// .w3.org
				// .yahoo.
				// .opera.com
				// .google.
				// .pctools.com
				// .163.com
				
				if ( url.find(".w3.org") == std::string::npos &&
					url.find(".yahoo.") == std::string::npos &&
					url.find(".google.") == std::string::npos &&
					url.find(".opera.com") == std::string::npos &&
					url.find(".pctools.com") == std::string::npos
					)
					url_set.insert(url);
				
				start = match[0].second;
			}
		}

	}
	else
	{
		size_t n_boundary = e.get_boundary().size();
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			MIME_Util::get_url(*(*it), url_set);
		}
	}


	/*
	static const regex re("https?://.+\\s", regex::icase);
	smatch match;
	std::string boundary;

	for(MIME_Header_List::iterator it = header_.begin();
		it != header_.end();
		++it)
	{
		if ( aos::strnicmp((*it)->c_str(), "content-type:", 13) == 0
			&& regex_search(*(*it), match, re) )
		{
			boundary.assign(match[1].first, match[1].second);
			
			if ( boundary.size() > 2 )
			{
				if ( (*(boundary.begin()) == '"' && *(boundary.rbegin()) == '"') )
				{
					boundary.erase(boundary.end()-1, boundary.end());
					boundary.erase(boundary.begin(), boundary.begin()+1);
				}
			}
			break;
		}
	}

	return boundary;
	//*/
}

int
MIME_Util::get_phone(MIME_Entity& e)
{
	int count = 0;

	if ( e.child().empty() )
	{
		//::printf("[BODY ctype='%s' encoding='%s' charset='%s']\n", e.get_content_type().c_str(), e.get_encoding().c_str(), e.get_charset().c_str());

		if ( e.get_primary_type() == "text" )
		{
			int res = e.decode_body();

			// BIG# 0: utf-16(10,FF) utf-8(EF,BC,90)
			// BIG# 1: utf-16(11,FF) utf-8(EF,BC,91)
			// BIG# 9: utf-16(19,FF) utf-8(EF,BC,99)
			static const regex re(
				"^[^0-9]*"
				"("
				"0(\\s*[^0-9:>]{0,2}\\s*)(\\d(\\s*[^0-9:>]{0,2}\\s*)){7,12}\\d"
				")"
				"\\s*[^0-9:>]{0,2}$"
				, regex::icase);
			smatch match;
		
			std::string& body = e.body();
			std::string::const_iterator start = body.begin();
			std::string::const_iterator end = body.end();

			while ( regex_search(start, end, match, re) )
			{
				std::string url;
				url.assign(match[1].first, match[1].second);
				::printf("%s\n", url.c_str());
				
				start = match[0].second;
				++count;
			}
		}

	}
	else
	{
		//size_t n_boundary = e.get_boundary().size();
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			count += MIME_Util::get_phone(*(*it));
		}
	}

	return count;
}

void
MIME_Util::dump_body(MIME_Entity& e)
{
	//if ( has_header() )
	//{
	//	// dump header
	//	::printf("[HEADER]\n");
	//	for(MIME_Header_List::iterator it = header_.begin();
	//		it != header_.end();
	//		++it)
	//	{
	//		::printf("%s", (*it)->c_str());
	//	}
	//	::printf("[/HEADER]\n");
	//}

	//if ( preamble_ )
	//{
	//	// dump preamble
	//	::printf("[PREAMBLE]\n");
	//	::printf("%s", preamble().c_str());
	//	::printf("[/PREAMBLE]\n");
	//}

	if ( e.child().empty() )
	{
		//// dump body
		//::printf("[BODY ctype='%s' encoding='%s' charset='%s']\n", e.get_content_type().c_str(), e.get_encoding().c_str(), e.get_charset().c_str());

		if ( e.get_primary_type() == "text" /*&& e.get_sub_type() == "plain"*/ )
		{
			//getchar();
			int res = e.decode_body();
			//if ( res == 0 ) ::printf("%s", e.body().c_str());

			// charset: auto-detect
			std::string cs_guess = MIME_Util::guess_charset(e.body().c_str(), e.body().size());
			::printf("cs_guess:%s\n", cs_guess.c_str());

			// charset: name correction
			std::string from_charset(e.get_charset());
			::printf("cs_from:%s\n", from_charset.c_str());
			if ( aos::stricmp(from_charset.c_str(), "gb2312") == 0 )
				from_charset = "gbk";
			else if ( from_charset.find("utf-7") != std::string::npos )
				from_charset = "utf-7";

			UErrorCode status = U_ZERO_ERROR;
			// cs_from: major, cs_guess: minor
			if ( from_charset == "" ) from_charset = cs_guess;
			UConverter* uconv = ucnv_open(from_charset.c_str(), &status);
			//// cs_guess: major, cs_from: minor
			//if ( cs_guess == "" ) cs_guess = from_charset;
			//UConverter* uconv = ucnv_open(cs_guess.c_str(), &status);

			// if error, use default charset
			if ( status != U_ZERO_ERROR )
			{
				::printf("open status: %d\n", status);
				status = U_ZERO_ERROR; // reset status
				uconv = ucnv_open(NULL, &status);
				::printf("open status: %d charset: %s\n", status, ucnv_getDefaultName());
				//getchar();
			}

			// if success, start converting to utf-16
			if ( status == U_ZERO_ERROR )
			{
				size_t n_target = ucnv_getMinCharSize(uconv) * e.body().size() + 1;
				//::printf("buf: %d\n", n_target);
				UChar* target = new UChar[n_target];
				::int32_t len;

				//// Convert from_charset to UChar
				//// Unknown character will be convert to utf-8(EF,BF,BD) by default
				//len = ucnv_toUChars(uconv, target, n_target, e.body().c_str(), e.body().size(), &status);
				////target[len] = 0;

				// Convert from_charset to UnicodeString
				UnicodeString ustr(e.body().c_str(), (::int32_t) e.body().size(), uconv, status);

				//if ( U_FAILURE(status) ) {
				if ( status != U_ZERO_ERROR ) {
					::printf("toUChars status: %d\n", status);
					::printf("%s\n", e.body().c_str());
					getchar();
				}
				//::printf("utf-16 len: %d\n", len);
				ucnv_close(uconv);

				// if success, start converting to utf-8
				UErrorCode status = U_ZERO_ERROR;
				uconv = ucnv_open("utf-8", &status);

				if ( status == U_ZERO_ERROR )
				{
					size_t n_target = ucnv_getMaxCharSize(uconv) * e.body().size() + 1;
					e.body().resize(n_target);

					//// Convert from UChar to utf-8
					//len = ucnv_fromUChars(uconv, (char*) e.body().c_str(), e.body().size(), target, len, &status);
					//e.body().resize(len);

					// Convert from UnicodeString to utf-8
					len = ustr.extract((char*) e.body().c_str(), (::int32_t) e.body().size(), uconv, status);
					e.body().resize(len);

					//::printf("utf-8 len: %d\n", len);
					ucnv_close(uconv);
				}

				delete target;

				// if contains illegal characters
				//if ( ::strstr(e.body().c_str(), "\xEF\xBF\xBD") != 0 )
				//{
					//::printf("EFBFBD found!\n");
					//getchar();
					FILE* fp = ::fopen("d:\\_spam_\\_log_\\utf-8.txt", "a");
					::fwrite(e.body().c_str(), e.body().size(), 1, fp);
					::fwrite("\r\n", 2, 1, fp);
					//::fwrite(temp, cnv_size, 1, fp);
					//::fwrite("\r\n", 2, 1, fp);
					::fclose(fp);
				//}
			}

		}
		//::printf("[/BODY]\n");
	}
	else
	{
		// dump child
		//size_t n_boundary = e.get_boundary().size();
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			//if ( n_boundary ) ::printf("--%s\n", get_boundary().c_str());
			MIME_Util::dump_body(*(*it));
		}
		//if ( n_boundary ) ::printf("--%s--\n", get_boundary().c_str());
	}

	//if ( epilogue_ )
	//{
	//	// dump epilogue
	//	::printf("[EPILOGUE]\n");
	//	::printf("%s", epilogue().c_str());
	//	::printf("[/EPILOGUE]\n");
	//}
}

std::string
MIME_Util::guess_charset(const char* buf, size_t size)
{
	UCharsetDetector* csd;
    const UCharsetMatch* csm;

    UErrorCode status = U_ZERO_ERROR;
	csd = ucsdet_open(&status);
	ucsdet_setText(csd, buf, (::int32_t) size, &status);
    csm = ucsdet_detect(csd, &status);

	status = U_ZERO_ERROR;
	const char *name = ucsdet_getName(csm, &status);
	//const char *language = ucsdet_getLanguage(csm, &status);
	//int32_t confidence = ucsdet_getConfidence(csm, &status);

	return std::string(name);
}

//Fnv32_t
//MIME_Util::hash(MIME_Entity& e, Fnv32_t hash_val)
//{
//	if ( e.child().empty() )
//	{
//		hash_val = fnv_32_buf((void*) e.body().c_str(), e.body().size(), hash_val);
//		//hash_val = fnv324_str("more data", hash_val);
//	}
//	else
//	{
//		for(MIME_Entity_List::iterator it = e.child().begin();
//			it != e.child().end();
//			++it)
//		{
//			hash_val = MIME_Util::hash(*(*it), hash_val);
//		}
//	}
//
//	return hash_val;
//}
//
//Fnv32_t
//MIME_Util::get_hash(MIME_Entity& e)
//{
//	Fnv32_t hash_val = FNV1_32_INIT;
//	return MIME_Util::hash(e, hash_val);
//}

} // namespace aos
