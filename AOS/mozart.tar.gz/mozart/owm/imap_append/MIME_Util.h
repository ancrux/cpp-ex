#ifndef _MIME_UTIL_H_
#define _MIME_UTIL_H_

#include "Config.h"

#include "MIME_Entity.h"

#include "unicode/unistr.h" /* UnicodeString class */

#include <vector>
#include <list>
#include <set>
#include <map>

//#include "hash/fnv.h"

namespace aos {

class AOS_API MIME_Header_Util
{
public:
	typedef std::list< std::pair< std::string, std::string > > Pairs;

public:
	static const size_t DEFAULT_LINE_SIZE = 76;

public:
	enum
	{
		No_Parser= 0,
		Encoded_Parser,
		Address_Parser,
		Attribute_Parser
	};

public:
	MIME_Header_Util(size_t line_size = DEFAULT_LINE_SIZE);
	~MIME_Header_Util();

public:
	Pairs::iterator begin() { return pairs_.begin(); };
	Pairs::iterator end() { return pairs_.end(); };

public:
	void parse_encoded(const std::string& str, int trim_crlf = 1, int map_charset = 0);
	int map_charset_decoded(const char* default_charset = 0);
	//- void parse_encoded2(const std::string& str, int trim_crlf = 1, int map_charset = 0); // using boost:regex, about 40% slower!
	//- void parse_encoded3(const std::string& str, int trim_crlf = 1, int map_charset = 0); // using boost:xpressive, very slow!
	std::string& build_utf8_decoded(std::string& str);
	UnicodeString& build_unicode_decoded(UnicodeString& ustr);
	//+ std::string& build_utf8_encoded(std::string& utf8, const char* charset = "utf-8", char enc = 'B');
	//+ UnicodeString& build_unicode_encoded(UnicodeString& ustr, const char* charset = "utf-8", char enc = 'B');

	void parse_address(const std::string& str);
	//- void parse_address2(const std::string& str); // using boost::regex
	std::string& build_address(std::string& str, const char* charset = "utf-8", char enc = 'B');

	void parse_attribute(const std::string& str);
	std::string& build_attribute(std::string& str, const char* charset = "utf-8", char enc = 'B');

public:
	std::string& trim_quoted_string(std::string& str);
	std::string& trim_quote(std::string& str);

public:
	size_t line_size() const { return line_size_; };
	void line_size(size_t line_size)
	{
		line_size_ = line_size;
	};

protected:
	int parser_; // parser type
	Pairs pairs_; // parse result

protected:
	size_t line_size_; // max line size allowed in MIME header
};

class AOS_API MIME_Util
{
public: // unicode converter
	static UnicodeString to_unicode(const std::string& from, const char* from_charset, UErrorCode& status);
	static std::string from_unicode(const UnicodeString& ustr, const char* to_charset, UErrorCode& status);
	static std::string to_utf8(const std::string& from, const char* from_charset, UErrorCode& status);
	static std::string from_utf8(const std::string& utf8, const char* to_charset, UErrorCode& status);
	
public: // encoder/decoder
	static size_t to_Base64(std::string& str, size_t line_size = 0);
	static size_t from_Base64(std::string& str);
	static size_t to_QP(std::string& str, size_t line_size = 0);
	static size_t from_QP(std::string& str);

public:
	static void map_charset(std::string& charset, const char* default_charset = 0);
	static std::string guess_charset(const char* buf, size_t size); // guess text charset
	static int check_charset(const char* buf, size_t len, const char* charset); // check a charset's match ratio

public:
	static void decode_body(MIME_Entity& e, int process_child = 1);
	static void encode_body(MIME_Entity& e, int process_child = 1);
	//static void decode_body_ctype_match(MIME_Entity& e, const char* ctype, const char* stype, int decode_child = 1);
	//static void encode_body_ctype_match(MIME_Entity& e, const char* ctype, const char* stype, int encode_child = 1);
	//static void text_to_utf8(MIME_Entity& e);
	//static void text_to_utf16(MIME_Entity& e);

public:
	static int has_url(MIME_Entity& e);
	static void get_url(MIME_Entity& e, std::set< std::string >& url_set);
	static int get_phone(MIME_Entity& e);
	static void dump_body(MIME_Entity& e);

//public:
//	static Fnv32_t get_hash(MIME_Entity& e);
//	static Fnv32_t hash(MIME_Entity& e, Fnv32_t hash_val);
};

} // namespace aos

#endif // _MIME_UTIL_H_
