#include "MIME_Header.h"

#include <boost/regex.hpp>
using namespace boost;

namespace aos {

/// MIME_Header

MIME_Header::MIME_Header()
:
parser_(MIME_Header::No_Parser)
{
}

MIME_Header::MIME_Header(const std::string& header, int parser)
{
	this->assign(header, parser);
}

MIME_Header::~MIME_Header()
{
}

void
MIME_Header::assign(const std::string& header, int parser)
{
	std::string::size_type colon = header.find(':');
	std::string temp;
	if ( colon == std::string::npos )
	{
		name_.resize(0);
		temp = header;
	}
	else
	{
		name_ = header.substr(0, colon);
		temp = header.substr(colon+1);
	}
	value_.resize(0);
	
	aos::Tokenizer toker;
	toker.set_separator("\r\n");
	toker.str(temp.c_str(), temp.size());

	int ch = toker.next();
	std::string line;
	while( ch > aos::Tokenizer::End )
	{				
		aos::trim(line.assign(toker.token(), toker.size()));
		value_ += line;

		ch = toker.next();
	}

	this->parse(parser);
}

void
MIME_Header::parse(int parser)
{
	// parse header below...
	switch( parser )
	{
		case MIME_Header::Decode_Parser:
			parse_decode_(value_);
			break;
		case MIME_Header::Address_Parser:
			parse_address_(value_);
			break;
		case MIME_Header::Attribute_Parser:
			parse_attribute_(value_);
			break;
		default:
			parse_nothing_(value_);
			break;
	}
}

void
MIME_Header::parse_nothing_(const std::string& value)
{
	pairs_.clear();
	parser_ = MIME_Header::No_Parser;
}

void
MIME_Header::parse_decode_(const std::string& value)
{
	pairs_.clear();
	parser_ = MIME_Header::Decode_Parser;

	static const regex re("=\\?([^?]+)\\?(B|Q)\\?([^?]+)\\?=", regex::icase);
	smatch match;

	std::string::const_iterator start = value.begin();
	std::string::const_iterator end = value.end();

	char enc = '\0';
	std::string charset;
	std::string text;
	while( regex_search(start, end, match, re) )
	{
		text.assign(start, match[0].first);
		//aos::trim(text);
		if ( !text.empty() )
		{
			//pairs_.push_back(std::make_pair("", text));
			//::printf("no_charset:%s\n", text.c_str()); //@

			// text without charset will be merged into the last pair
			if ( !pairs_.empty() )
			{
				Pairs::iterator last = --(pairs_.end());
				last->second += text;
			}
			else
				pairs_.push_back(std::make_pair("", text));
		}
		
		charset.assign(match[1].first, match[1].second);
		enc = *(match[2].first);
		text.assign(match[3].first, match[3].second);
		
		//text.assign(start, match[0].first);
		//text.append(match[3].first, match[3].second);

		//::printf("%s %c %s\n", charset.c_str(), enc, text.c_str()); //@

		switch(enc)
		{
			case 'B':
			case 'b':
				{
				aos::Base64 base64;
				size_t n_decode = base64.decode(text.c_str(), text.size(), (char*) text.c_str());
				text.resize(n_decode);
				break;
				}
			case 'Q':
			case 'q':
				{
				//RFC2047: 4.2. The "Q" encoding (2)
				//replace '_' with ' '
				size_t n_len = text.size();
				char* cstr = (char*) text.c_str();
				for(size_t i=0; i < n_len; ++i)
				{
					if ( *(cstr+i) == '_' ) *(cstr+i) = ' ';
				}

				aos::QP qp;
				size_t n_decode = qp.decode(text.c_str(), text.size(), (char*) text.c_str());
				text.resize(n_decode);
				break;
				}
			default:
				break;
		}

		// if the same charset as the last one, append text to the last one
		// else new entry
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			if ( aos::strnicmp(last->first.c_str(), charset.c_str(), charset.size()) == 0 )
				last->second += text;
			else
				pairs_.push_back(std::make_pair(charset, text));
		}
		else
			pairs_.push_back(std::make_pair(charset, text));

		//Pairs::iterator last = --(pairs_.end()); //@
		//::printf("%s %c %s\n", last->first.c_str(), enc, last->second.c_str()); //@

		start = match[0].second;
	}
	text.assign(start, end);
	//aos::trim(text);
	if ( !text.empty() )
	{
		//pairs_.push_back(std::make_pair("", text));
		//::printf("no_charset:%s\n", text.c_str()); //@

		// text without charset will be merged into the last pair
		if ( !pairs_.empty() )
		{
			Pairs::iterator last = --(pairs_.end());
			last->second += text;
		}
		else
			pairs_.push_back(std::make_pair("", text));
	}
}

void
MIME_Header::parse_address_(const std::string& value)
{
	pairs_.clear();
	parser_ = MIME_Header::Address_Parser;

	int ch;
	aos::Tokenizer toker;
	toker.str(value.c_str(), value.size());
	toker.set_separator(",\r\n");

	while(true)
	{
		ch = toker.next();
		if ( ch <= aos::Tokenizer::End ) break;
		std::string address(toker.token(), toker.size());

		static const regex re_addr("(.*)(<.*@.*>)", regex::icase);
		smatch match;
		std::string::const_iterator start = address.begin();
		std::string::const_iterator end = address.end();
		if ( regex_search(start, end, match, re_addr) )
		{
			std::string name(match[1].first, match[1].second);
			aos::trim(name);
			trim_quote_(name); //? or use QS.decode
			std::string email(match[2].first, match[2].second);

			pairs_.push_back(std::make_pair(name, email));
		}
		else
		{
			pairs_.push_back(std::make_pair("", address));
		}
	}
}

void
MIME_Header::parse_attribute_(const std::string& value)
{
	pairs_.clear();
	parser_ = MIME_Header::Attribute_Parser;

	int ch;
	aos::Tokenizer toker;
	toker.str(value.c_str(), value.size());

	std::string attrib_name;
	std::string attrib_value;

	// get first attribute value followed by ':', e.g 'Content-Disposition: attachment;'
	toker.set_separator(";\r\n");
	ch = toker.next();
	if ( ch == ';' )
	{
		attrib_value.assign(toker.token(), toker.size());
		trim_quote_(attrib_value);

		pairs_.push_back(std::make_pair("", attrib_value));
	}

	// get remaining attribute value(s) followed by '=', e.g 'filename="example.pdf";'
	while(true)
	{
		// read attribute name
		toker.set_separator("=\r\n\t ");
		ch = toker.next();
		if ( ch <= aos::Tokenizer::End ) break;
		attrib_name.assign(toker.token(), toker.size());

		// read attribute value
		toker.set_separator(";\r\n");
		ch = toker.next();
		if ( ch <= aos::Tokenizer::End ) break;
		attrib_value.assign(toker.token(), toker.size());
		trim_quote_(attrib_value);

		pairs_.push_back(std::make_pair(attrib_name, attrib_value));
	}
}

void
MIME_Header::trim_quote_(std::string& value)
{
	aos::trim(value);
	if ( value.size() > 1 )
	{
		if ( value[0] == '"' && value[0] == value[value.size()-1] )
		{
			aos::QS qs;
			size_t n_decode = qs.decode(value.c_str(), value.size(), (char*) value.c_str());
			value.resize(n_decode);

			//value.erase(value.end()-1, value.end());
			//value.erase(value.begin(), value.begin()+1);
		}
	}
}

} // namespace aos
