<?php
set_time_limit(0);

header("Content-Type: text/plain");

$usage = <<<EOD
Usage:
{$argv[0]} <server> <user> <pass> <path_to_mbox_files>

Ex: {$argv[0]} 192.168.1.91 test1 111111 /var/mail/angus
EOD;

if ($argc < 5)
{
	echo $usage;
	exit(1);
}

$server    = $argv[1];
$user      = $argv[2];
$pass      = $argv[3];
$file      = $argv[4];
$dest      = iconv('big5', 'utf-7', $argv[5]);
if ( strlen($dest) > 0 ) $dest[0] = '&';

mbox_to_imap($server, $user, $pass, $file, $dest);

function mbox_to_imap($server, $user, $pass, $file, $dest)
{

	$fp = fsockopen("ssl://{$server}", 993, $errno, $errstr, 5);

	if (!$fp) { echo "$errstr ($errno)\r\n"; }
	else
	{
		stream_set_timeout($fp, 5);

		$mbox      = $file;
		$tag       = 'tag001';
		$result    = '';
		$n_max     = 0; // 0 for no limit

		echo fgets($fp);
		fwrite($fp, "$tag LOGIN {$user} {$pass}\r\n");
		echo read_response($fp);
		fwrite($fp, "$tag CREATE /{$dest}\r\n");
		check_response($fp);
		fwrite($fp, "$tag LIST \"\" *\r\n");
		echo read_response($fp);
		fwrite($fp, "$tag SELECT /$dest\r\n");
		check_response($fp);

		// start uploading
		if (file_exists($mbox))
		{
			$MAX_LINE = 102400;
			$mail = '';
			$line = '';
			$charset = 'big5'; // default charset

			$fh      = fopen($mbox, "r");

			if (!$fh)
			{
				echo "create file failed!\r\n";
				exit(1);
			}

			// escape first line
			$separator = fgets($fh, $MAX_LINE);
			echo "---START---\r\n" . $line;

			$c         = 0;
			$sline     = '';

			$line_to   = '';

			while (!feof($fh))
			{
				$line = fgets($fh, $MAX_LINE);

				//beginning of another mail, write previous mail
				if (substr($line, 0, 5) == 'From ')
				{
					// save last line in mail
					$mail .= $sline;
					// reset sline
					$sline = '';

					++$c;
					echo "#" . $c . "\n";
					//file_put_contents("d:/_spam_/_{$c}.eml", $mail);
					///*
					$n_size = strlen($mail);
					echo "size:" . strlen($mail) . "\n";

					fwrite($fp, "$tag APPEND $dest {{$n_size}}\r\n");

					$ret = read_response($fp);

					$mail .= "\r\n";
					//echo "=========begin============\n";
					//echo $mail;
					//echo "\n=======end================\n";
					fwrite2($fp, $mail);
					//fwrite($fp, "\r\n");
					$ret = read_response($fp);
					echo $ret;
					echo "\r\n";

					// reset mail
					$separator = $line;
					$mail      = '';
				}
				//read mail by line
				else
				{
					// handle folded line
					if ($line[0] == ' ' || $line[0] == '\t')
					{
						$sline .= $line;
						continue;
					}
					else
					{
						// process line
						if (strtolower(substr($sline, 0, 8)) == 'subject:')
						{
							$sline = fix_header($sline, $charset) . "\r\n";
						}
						else if (strtolower(substr($sline, 0, 5)) == 'from:')
						{
							echo $sline;
							$beforeAddr = $afterAddr = '';
							$pos        = strpos($sline, '<');

							if ($pos !== false)
							{
								$beforeAddr = substr($sline, 0, $pos);
								$beforeAddr = str_replace("\"","",$beforeAddr);
								//echo "#######".$beforeAddr."#####\n";
								$afterAddr  = substr($sline, $pos);
							}
							else
							{
								$beforeAddr = trim($sline);
								$beforeAddr = str_replace("\"","",$beforeAddr);
								//echo "#######".$beforeAddr."#####\n";
								$afterAddr  = "\r\n";
							}
							//echo $sline;
							$sline = fix_header($beforeAddr, $charset) . $afterAddr;
							//echo $sline;
						}
						/*
						else if (strtolower(substr($sline, 0, 3)) == 'to:')
						{
						echo $sline;
						$beforeAddr = $afterAddr = '';
						$pos        = strpos($sline, '<');

						if ($pos !== false)
						{
						$beforeAddr = substr($sline, 0, $pos);
						$beforeAddr = str_replace("\"","",$beforeAddr);
						//echo "#######".$beforeAddr."#####\n";
						$afterAddr  = substr($sline, $pos);
						}
						else
						{
						$beforeAddr = trim($sline);
						$beforeAddr = str_replace("\"","",$beforeAddr);
						//echo "#######".$beforeAddr."#####\n";
						$afterAddr  = "\r\n";
						}
						//echo $sline;
						$sline = fix_header($beforeAddr, $charset) . $afterAddr;
						//echo $sline;
						$line_to=str_replace("To: ","From: ",$sline);
						echo "/////////".$line_to."\n";
						//if($dest=="S") $mail=$line_to.$mail;
						}
						*/
						// save line in mail
						$mail .= $sline;
						// reset line
						$sline = $line;
					}
				}
			}
			//write last mail
			if (strlen($mail) > 0)
			{
				$mail.=$sline;
				++$c;
				echo "#" . $c . "\n";
				//file_put_contents("d:/_spam_/_{$c}.eml", $mail);
				///*
				$n_size = strlen($mail);
				echo "size:" . strlen($mail) . "\n";
				fwrite($fp, "$tag APPEND $dest {{$n_size}}\r\n");
				$ret = read_response($fp);

				$mail .= "\r\n";
				//echo "=========begin============\n";
				//echo $mail;
				//echo "\n=======end================\n";
				fwrite2($fp, $mail);
				//fwrite($fp, "\r\n");
				$ret = read_response($fp);
				echo $ret;
				echo "\r\n";
			}

			fclose($fh);
			//fclose($ff);
			//echo "mbox remain size: " . filesize(realpath($mbox_left)) . "\r\n";
		}
		else { echo "MBOX NOT FOUND: " . $mbox . "\r\n"; }
		//*/ end of uploading

		fwrite($fp, "$tag LOGOUT\r\n");
		echo read_response($fp);
		fclose($fp);
	}

} // function

function fwrite2 ($fp, &$mail)
{
	$n_total = strlen($mail);
	$n_block = 512;

	$n_pos   = 0;
	$c       = 0;

	while (1)
	{
		$n_left = $n_total - $n_pos;

		if ($n_left <= 0) break;

		if ($n_left < $n_block) $n_block = $n_left;

		$n_write = fwrite($fp, substr($mail, $n_pos, $n_block));
		$n_pos += $n_write;
		++$c;

		if ($c % 2 == 0) echo '.';
	}

	echo "\r\n";
}

function read_response ($fp, $content_only = false)
{
	$res  = '';

	$line = fgets($fp);

	if (!$content_only) $res .= $line;

	// has more line
	while ($line[0] == '*')
	{
		// has {n} octet to read
		$match = array ();

		if (preg_match('/\s+{(\d+)}\s*/', $line, $match) > 0)
		{
			$n_read  = intval($match[1]);
			$content = '';

			echo "n_read:" . $n_read . "\r\n";

			while ($n_read > 0)
			{
				$buf = fread($fp, $n_read);
				$n_read -= strlen($buf);
				$content .= $buf;

				echo "n_content:" . strlen($buf) . "\r\n";
			}

			$res .= $content;

			// {n} octet stream is always followed by a line
			$line = fgets($fp);

			if (!$content_only) $res .= $line;
		}

		$line = fgets($fp);

		if (!$content_only) $res .= $line;
	}
	//echo $res;
	//if(strpos($res, "OK") === false) exit(1);
	return $res;
}

function fix_header ($header, $default_charset = '')
{
	$name = $value = '';
	$pos  = strpos($header, ':');

	if ($pos !== false)
	{
		$name  = substr($header, 0, $pos);
		$value = trim(substr($header, $pos + 1));
	}
	else $value = trim($header);

	$arrH = imap_mime_header_decode($value);
	//print_r($arrH);

	$strH = $name . ': ';

	for ($i = 0, $c = count($arrH); $i < $c; ++$i)
	{
		if ($arrH[$i]->charset == 'default')
		{
			if (trim($arrH[$i]->text) == '') continue;

			else if ($default_charset != '') $strH .= '=?' . $default_charset . '?B?' . base64_encode($arrH[$i]->text) . '?= ';

			else $strH .= $arrH[$i]->text;
		}
		else { $strH .= '=?' . $arrH[$i]->charset . '?B?' . base64_encode($arrH[$i]->text) . '?= '; }
	}

	return $strH;
}
function check_response($fp)
{
	$str = read_response($fp);
	if(strpos($str, "OK")===false)
	{
		echo $str;
		exit(1);
	}
}
?>