<?php
set_time_limit(0);
header("Content-Type: text/plain");

if ( $argc != 3 )
{
$usage = <<<EOD
Usage:
	{$argv[0]} <mbox file> <eml folder>
	
	Ex: {$argv[0]} mbox c:\mbox
EOD;

echo $usage;

exit(1);
}

$file = $argv[1];
$folder = realpath($argv[2]);
if ( !$folder ) $folder = $argv[2];

mkdir($folder, 0777, true);
if ( !is_dir($folder) )
{
	echo "create folder failed: " . $folder . "\n";
	exit(1);
}
	
	$mbox = $file;
	$tag = 'tag001';
	$result = '';
	$n_max = 0; // 0 for no limit
	
	// start uploading
	if ( file_exists($mbox) )
	{
		$MAX_LINE = 102400;
		$mail = '';
		$mail_sender = 'Empty';
		$mail_date = date('Y-m-d', time());
		$line = '';
		$charset = 'big5'; // default charset
		$stop = false;
		
		$fh = fopen($mbox, "r");
		
		// escape first line
		$separator = fgets($fh, $MAX_LINE);
		echo "---START---\r\n" . $line;
		
		$c = 0;
		$sline = '';
		while(!feof($fh)) 
		{
			$line = fgets($fh, $MAX_LINE);
			$len = strlen($line);
			if ( $len > 2  && $line[$len-2] != "\x0D" )
			{
				$line[$len-1] = "\x0D";
				$line .= "\x0A";
			}
		
			if ( substr($line, 0, 5) == 'From ' )
			{
				// save last line in mail
				$mail .= $sline;
				// reset sline
				$sline = '';
				
				++$c;
				echo "#" . $c . "\n";
				file_put_contents("{$folder}/{$mail_date}_#{$c}_{$mail_sender}.eml", $mail);
				$n_size = strlen($mail);
				echo "size:" . strlen($mail) . "\n";
				
				
				// reset mail
				$separator = $line;
				$mail = '';
			}
			else
			{
				// handle folded line
				if ( $line[0] == ' ' || $line[0] == '\t' )
				{
					$sline .= $line;
					continue;
				}
				else
				{
					// process line
					if ( strtolower(substr($sline, 0, 8)) == 'subject:' )
					{
						echo $sline;
						$sline = fix_header($sline, $charset) . "\r\n";
					}
					else if ( strtolower(substr($sline, 0, 5)) == 'date:' )
					{
						$mail_date = date('Y-m-d', strtotime(substr($sline, 6)));
					}
					else if ( strtolower(substr($sline, 0, 5)) == 'from:' )
					{
						$beforeAddr = $afterAddr = '';
						$pos = strpos($sline, '<');
						if ( $pos !== false )
						{
							$beforeAddr = substr($sline, 0, $pos);
							$afterAddr = substr($sline, $pos);
						}
						else
						{
							$beforeAddr = trim($sline);
							$afterAddr = "\r\n";
						}
							
						// get sender
						$mail_sender = 'Empty';
						if ( preg_match('/(\w+)@(\w+)/i', $sline, $match) > 0 )
							$mail_sender = $match[1] . '@' . $match[2];
						/*
						$posAt = strpos($sline, '@');
						if ( $pos < $posAt )
						{
							$mail_sender = substr($sline, $pos+1, $posAt-$pos-1);
						}
						else
						{
							$mail_sender = substr($sline, 0, $posAt);
						}
						$mail_sender = trim($mail_sender);
						if ( !$mail_sender ) $mail_sender = 'Empty';
						$escape = array("\\", "/", ":", "*", "?", "\"", "<", ">", "|");
						$mail_sender = str_replace($escape, "", $mail_sender);
						*/
						echo "sender: $mail_sender\n";
						
						$sline = fix_header($beforeAddr, $charset) . $afterAddr;
					}
					
					// save line in mail
					$mail .= $sline;
					// reset line
					$sline = $line;
				}
			}
		}
		
		if ( strlen($mail) > 0 )
		{
				++$c;
				echo "#" . $c . "\n";
				file_put_contents("{$folder}/{$mail_date}_{$mail_sender}_#{$c}.eml", $mail);
				$n_size = strlen($mail);
				echo "size:" . strlen($mail) . "\n";
		}
		
		fclose($fh);
	}
	else
	{
		echo "MBOX NOT FOUND: " . $mbox . "\r\n";
	}

echo "\n$c eml(s) created under the folder: $folder\n";

function fix_header($header, $default_charset = '')
{
$name = $value = '';
$pos = strpos($header, ':');
if ( $pos !== false )
{
	$name = substr($header, 0, $pos);
	$value = trim(substr($header, $pos+1));
}
else
	$value = trim($header);

$arrH = imap_mime_header_decode($value);
//print_r($arrH);

$strH = $name . ': ';
for($i=0, $c=count($arrH); $i<$c; ++$i)
{
	if ( $arrH[$i]->charset == 'default' )
	{ 
		if ( trim($arrH[$i]->text) == '' )
			continue;
		else if ( $default_charset != '' )
			$strH .= '=?' . $default_charset . '?B?' . base64_encode($arrH[$i]->text) . '?= ';
		else
			$strH .= $arrH[$i]->text;
	}
	else
	{
		$strH .= '=?' . $arrH[$i]->charset . '?B?' . base64_encode($arrH[$i]->text) . '?= ';
	}
}

return $strH;
}
?>