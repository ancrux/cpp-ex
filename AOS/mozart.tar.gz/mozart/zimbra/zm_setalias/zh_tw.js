if ( !_T || Object.prototype.toString.call(_T) === '[object Object]' ) var _T = {};
// place at: /opt/zimbra/httpd/htdocs/setalias

_T['language'] = "語言 (Language)";
_T['lang_en'] = "English";
_T['lang_zh-tw'] = "中文(繁體)";

_T['set_alias'] = "設定郵件別名";
_T['account'] = "帳號";
_T['password'] = "密碼";
_T['mail_alias'] = "郵件別名";
_T['i_agree_clause'] = "我同意使用條款";
_T['apply'] = "套用";
_T['processing'] = "處理中"

_T['ok'] = "設定成功!";
_T['err_job'] = "錯誤階段";
_T['err_code'] = "錯誤碼";
_T['check_pass'] = "驗證密碼";
_T['alias_length'] = "檢查郵件別名長度";
_T['verify_alias'] = "檢查郵件別名";
_T['add_alias'] = "新增郵件別名";
_T['clean_up'] = "完成";

_T['err_check_pass'] = "帳號或密碼不正確!";
_T['err_alias_length'] = "不正確的郵件別名長度，必須是 {0} 到 {1} 個字元！";
_T['err_verify_alias'] = "郵件別名含有禁用字詞: ";
_T['err_add_alias'] = "設定失敗，郵件別名已經存在!";
_T['err_clean_up'] = "無法清除舊的郵件別名!";
_T['err_must_agree_clause'] = "您必須同意使用條款，才能設定郵件別名!";