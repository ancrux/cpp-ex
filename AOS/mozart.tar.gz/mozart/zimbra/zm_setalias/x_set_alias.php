<?php
//---------------------------------------------------------
// place this file at: /opt/zimbra/httpd/htdocs/setalias
//
// change EXCLUDE_KEYWORD_FILE accordingly if you wish to
// move its path.
//---------------------------------------------------------

//define('EXCLUDE_KEYWORD_FILE', '/opt/zimbra/httpd/htdocs/setalias/exclude.txt');
define('EXCLUDE_KEYWORD_FILE', './exclude.txt');
define('MAX_ALIAS_LEN', 12);
define('MIN_ALIAS_LEN', 4);
define('DIR_LOG', './log/');
define('PARTIAL_MATCH', false);

$account = trim($_POST['account']);
$pass = $_POST['pass'];
$alias = trim($_POST['alias']);
$old_alias = '';

$out = array();

do
{
	$arr = check_account_pass($account, $pass);
	$arr['job'] = 'check_pass';
	if ( $arr['ret'] != 0 ) 
	{
		sleep(1);
		break;
	}
	
	$arr = is_incorrect_length($alias);
	$arr['job'] = 'alias_length';
	if ( $arr['ret'] != 0 ) break;
	
	$arr = has_exclude_keyword($alias, PARTIAL_MATCH);
	$arr['job'] = 'verify_alias';
	if ( $arr['ret'] != 0 ) break;
	
	$arr = add_account_alias($account, $alias);
	$arr['job'] = 'add_alias';
	if ( $arr['ret'] != 0 ) break;
	
	$arr = get_account_alias($account);
	$arr['job'] = 'clean_up';
	if ( $arr['ret'] != 0 ) break;
	
	foreach($arr['out'] as $i => $other_alias)
	{
		if ( $other_alias == $alias ) continue;
		$arrDel = del_account_alias($account, $other_alias);
		if ( $arrDel['ret'] == 0 )
		{
			unset($arr['out'][$i]);
			$old_alias = $other_alias;
		}
	}
}
while(0);

$out['job'] = $arr['job'];
$out['ret'] = $arr['ret'];
$out['out'] = $arr['out'];
$out['account'] = $account;
$out['alias'] = $alias;
$out['old_alias'] = $old_alias;

// log result
if ( !file_exists(DIR_LOG) ) mkdir(DIR_LOG);
log_result($out);

print json_encode($out);

//-----------------------------
// zimbra API
//-----------------------------

function log_result(&$result)
{
	$now = time();
	$filename = DIR_LOG . date("Y-m", $now) . ".log";
	
	$msg = date("Y-m-d H:i:s\t", $now);
	$msg .= ($result['ret'] == 0)?"result=OK\t":"result=Error\t";
	$msg .= "account={$result['account']}\t";
	$msg .= "new_alias={$result['alias']}\t";
	$msg .= "old_alias={$result['old_alias']}\t";
	$msg .= "stage={$result['job']}\t";
	$msg .= "message=" . trim($result['out'][0]);
	$msg .= "\n";
	
	return file_put_contents($filename, $msg, FILE_APPEND);
}

function is_incorrect_length($alias)
{
	$arr = array();
	$arr['ret'] = 0;
	$arr['out'] = array();
	
	do
	{
		$tmp = explode('@', $alias);
		$len = strlen($tmp[0]); // user part length
		if ( $len < MIN_ALIAS_LEN || $len > MAX_ALIAS_LEN )
		{
			$arr['ret'] = -1;
			$arr['out'][] = "$len";
			$arr['out'][] = MIN_ALIAS_LEN;
			$arr['out'][] = MAX_ALIAS_LEN;
			break;
		}
	}
	while(0);
	
	return $arr;
}

function has_exclude_keyword($alias, $partial_match = true)
{
	$arr = array();
	$arr['ret'] = 0;
	$arr['out'] = array();
	
	do
	{
		$tmp = explode('@', $alias);
		$user_part = strtolower($tmp[0]);
		if ( $user_part == '' )
		{
			$arr['out'][] = 'user_part of alias is empty!';
			break;
		}
		
		$words = @file(EXCLUDE_KEYWORD_FILE);
		if ( $words === false )
		{
			$arr['out'][] = 'EXCLUDE_KEYWORD_FILE not found!';
			break;
		}
		
		if ( $partial_match == true )
		{
			foreach($words as $i => $line)
			{
				$word = trim($line); if ( $word == '' ) continue;
				if ( strpos($user_part, strtolower($word)) !== false )
				{
					$arr['ret'] = -1;
					$arr['out'][] = rtrim($word);
				}
			}
		}
		else
		{
			foreach($words as $i => $line)
			{
				$word = trim($line); if ( $word == '' ) continue;
				if ( 0 == strcasecmp($user_part, $word) )
				{
					$arr['ret'] = -1;
					$arr['out'][] = rtrim($word);
				}
			}
		}
	}
	while(0);
	
	return $arr;
}

function check_account_pass($account, $pass, $host = "localhost", $port = 110, $conn_timeout = 10)
{
	$arr = array();
	$arr['ret'] = -1;
	$arr['out'] = array();
	
	$fp = @fsockopen($host, $port, $err_no, $err_str, $conn_timeout);
	if ( $fp )
	{
		$res = fgets($fp);
		
		$cmd = "USER {$account}\r\n";
		fwrite($fp, $cmd);
		$res = fgets($fp);
		
		$cmd = "PASS {$pass}\r\n";
		fwrite($fp, $cmd);
		$res = fgets($fp);
		
		$arr['out'][] = $res;
		if ( $res[0] == '+' ) $arr['ret'] = 0;
		
		$cmd = "QUIT \r\n";
		fwrite($fp, $cmd);
		$res = fgets($fp);
		
		fclose($fp);
	}
	else
	{
		$arr['ret'] = $err_no;
		$arr['out'][] = "open '{$host}:{$port}' failed!";
	}
	
	return $arr;
}

function get_account_alias($account)
{
	$cmd = "zmprov ga {$account} zimbraMailAlias";
	
	$arr = array();
	$arr['ret'] = -1;
	$arr['out'] = array();
	
	exec($cmd, $out, $arr['ret']);
	
	foreach($out as $i => $line)
	{
		$v = explode(':', $line);
		if ( $v[0] != 'zimbraMailAlias' ) continue;
		$arr['out'][] = trim($v[1]);
	}
	
	return $arr;
}

function add_account_alias($account, $alias)
{
	$cmd = "zmprov aaa {$account} {$alias} 2>&1";
	
	$arr = array();
	$arr['ret'] = -1;
	$arr['out'] = array();
	
	exec($cmd, $arr['out'], $arr['ret']);
	
	return $arr;
}

function del_account_alias($account, $alias)
{
	$cmd = "zmprov raa {$account} {$alias} 2>&1";
	
	$arr = array();
	$arr['ret'] = -1;
	$arr['out'] = array();
	
	exec($cmd, $arr['out'], $arr['ret']);
	
	return $arr;
}
?>