if ( !_T || Object.prototype.toString.call(_T) === '[object Object]' ) var _T = {};
// place at: /opt/zimbra/httpd/htdocs/setalias

_T['language'] = "Language";
_T['lang_en'] = "English";
_T['lang_zh-tw'] = "中文(繁體)";

_T['set_alias'] = "Setup Mail Alias";
_T['account'] = "Account";
_T['password'] = "Password";
_T['mail_alias'] = "Mail Alias";
_T['i_agree_clause'] = "I agree to Terms of Use.";
_T['apply'] = "Apply";
_T['processing'] = "Processing"

_T['ok'] = "OK!";
_T['err_job'] = "Error Phrase";
_T['err_code'] = "Error Code";
_T['check_pass'] = "Authentication";
_T['alias_length'] = "Verify Mail Alias Length";
_T['verify_alias'] = "Verify Mail Alias";
_T['add_alias'] = "Add Mail Alias";
_T['clean_up'] = "Cleanup";

_T['err_check_pass'] = "Either account or password is incorrect!";
_T['err_alias_length'] = "Incorrect alias length, must between {0} and {1} characters!";
_T['err_verify_alias'] = "Mail alias contains forbidden phrase: ";
_T['err_add_alias'] = "Mail alias already exists!";
_T['err_clean_up'] = "Failed to remove old mail alias!";
_T['err_must_agree_clause'] = "You must agree to Terms of Use before setting mail alias!";
