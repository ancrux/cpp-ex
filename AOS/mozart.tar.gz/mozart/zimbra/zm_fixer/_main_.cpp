#include "ace/OS.h"
#include "ace/Get_Opt.h"
#include "ace/Configuration_Import_Export.h"
#include "ace/Process_Mutex.h"

#include "ace/INET_Addr.h"
#include "ace/SSL/SSL_SOCK_Stream.h" //#include "ace/SOCK_Stream.h"
#include "ace/SSL/SSL_SOCK_Connector.h" //#include "ace/SOCK_Connector.h"

#include "ace/File_Lock.h"

#include "MIME_Entity.h"
#include "MIME_Util.h"
using namespace aos;

#include "ZM_Util.h"
using namespace mozart;

#include <iostream>
using namespace std;

#include "_main_.h"

//int main(int argc, char* argv[])
int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	//test(argc, argv); return 0;//@

	// get console parameters
	//ACE_Get_Opt cmd(argc, argv, ACE_TEXT(""));

	ACE_Time_Value t1 = ACE_OS::gettimeofday();

	if ( argc < 2 || argc > 3 )
	{
		::printf("Usage:\n");
		::printf("%s input_eml output_eml\n", argv[0]);
		//ACE_OS::printf("%s input_eml output_eml\n", ACE::basename(cmd.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
		::exit(-1);
	}

	// assign input/output eml
	std::string in_eml(argv[1]);
	std::string out_eml(argv[1]);
	if ( argc == 3 ) out_eml.assign(argv[2]);
	::printf("in:%s out:%s\n", in_eml.c_str(), out_eml.c_str()); //@

	// get default charset
	//std::string charset("utf-8");
	int debug = false;
	int fix_qp_dot = false;
	std::string debug_sender;

	std::string charset("big5");

	static char DIR_SEP = '/';
	#ifdef WIN32
		DIR_SEP = '\\';
	#endif
	std::string lck_file;
	std::string ini_file(argv[0]);
	std::string::size_type dot = ini_file.rfind('.');
	std::string::size_type sep = ini_file.rfind(DIR_SEP);
	if ( dot != std::string::npos && sep != std::string::npos && dot > sep )
		ini_file.erase(dot);
	lck_file.assign(ini_file);
	lck_file += ".lck";
	ini_file += ".ini";
	::printf("ini_file:%s\n", ini_file.c_str()); //@

	FILE* fp = ::fopen(ini_file.c_str(), "rb");
	static const int BUF_SIZE = 4096;
	char buf[BUF_SIZE];
	if ( fp )
	{
		while( ::fgets(buf, BUF_SIZE, fp) != NULL )
		{
			std::string line(buf);
			if ( aos::strnicmp(buf, "DefaultCharset=", 15) == 0 )
			{
				line = line.substr(15);
				aos::trim(line, " \t\r\n\"\0\x0B");
				charset = line;
				::printf("ini_charset:%s\n", charset.c_str()); //@
			}
			else if ( aos::strnicmp(buf, "Debug=", 6) == 0 )
			{
				line = line.substr(6);
				aos::trim(line, " \t\r\n\"\0\x0B");
				debug = ::atoi(line.c_str());
				::printf("ini_debug:%d\n", debug); //@
			}
			else if ( aos::strnicmp(buf, "Fix_QP_Dot=", 11) == 0 )
			{
				line = line.substr(11);
				aos::trim(line, " \t\r\n\"\0\x0B");
				fix_qp_dot = ::atoi(line.c_str());
				::printf("ini_fix_qp_dot:%d\n", fix_qp_dot); //@
			}
		}
		::fclose(fp);
	}
	
	time_t now = ACE_OS::time();

	///* fix eml
	aos::MIME_Entity e;

	// import eml
	e.import_file(in_eml.c_str());
	::printf("input size:%d\n", e.size());

	if ( debug )
	{
		static const ACE_TCHAR* cmd_fmt = "cp %s ./in.%u.eml";
		ACE_TCHAR cmd[PATH_MAX+1];
		
		ACE_OS::snprintf(cmd, PATH_MAX, cmd_fmt, in_eml.c_str(), (unsigned int) now);
		::system(cmd);
	}

	// if lock file exists, simply skip fixing
	FILE* fp_lock = ::fopen(lck_file.c_str(), "rb");
	if ( fp_lock == NULL )
	{
		// process eml
		ZM_Util::zm_fix_ctype_text(e, charset.c_str());
		charset = ZM_Util::zm_get_best_charset(e, charset.c_str());
		::printf("default_charset:%s\n", charset.c_str()); //@
		ZM_Util::zm_fix_mail_header(e, charset.c_str());

		if ( fix_qp_dot )
		{
			int fix_count = 0;
			ZM_Util::zm_fix_qp_dot(e, fix_count);
		}
		

		//ZM_Util::zm_fix_attachment_name(e, charset.c_str()); //@
		//ZM_Util::zm_fix_text_to_utf8(e, charset.c_str()); //@
	}
	else
	{
		::fclose(fp_lock);
		::printf("locked!\n"); //@
	}
	
	// export eml
	int n_byte = -1;
	n_byte = e.export_file(out_eml.c_str());
	::printf("output size:%d\n", n_byte);
	//*/

	if ( debug )
	{
		static const ACE_TCHAR* path_fmt = "./out.%u.eml";
		ACE_TCHAR path[PATH_MAX+1];
		
		ACE_OS::snprintf(path, PATH_MAX, path_fmt, (unsigned int) now);
		e.export_file(path);
	}

	// check license
	int check_interval = 300; // in seconds
	ACE_OS::printf("check_time: %d\n", now);

	//if ( 1 )
	if ( now % check_interval >= 0 && now % check_interval < 5 )
	{
		static const ACE_TCHAR* uniqueName = "ZM_Fixer_License_Checker";
		ACE_Process_Mutex mutex(uniqueName);
		if ( mutex.tryacquire() == 0 ) // success
		{
			ACE_INET_Addr server_addr(80, "cgac.cellopoint.com");
			ACE_SOCK_Connector connector;
			ACE_SOCK_Stream stream;

			//ACE_INET_Addr server_addr(443, "cgac.cellopoint.com"); // SSL
			//ACE_SSL_SOCK_Connector connector; // SSL
			//ACE_SSL_SOCK_Stream stream; // SSL
			
			ACE_Time_Value timeout(3);
			int flags = 0;

			std::string http_res;
			if ( connector.connect(stream, server_addr, &timeout) != -1 )
			{
				unsigned char buf[4096];

				static const char* http_cmd = \
					"GET /admin/zm_fixer_license.php HTTP/1.1\r\n" \
					"Host: cgac.cellopoint.com\r\n" \
					"\r\n";
				ssize_t n_send = stream.send_n(http_cmd, ACE_OS::strlen(http_cmd), flags, &timeout);

				while(true)
				{
					ssize_t n_recv = stream.recv(buf, sizeof(buf), flags, &timeout);
					if ( n_recv > 0 )
						http_res.append((char*) buf, n_recv);
					else if ( n_recv < 0 && ACE_OS::last_error() != EWOULDBLOCK )
						break;

					size_t len = http_res.size();
					if ( len > 4 )
					{
						const char* last4 = http_res.c_str();
						last4 = last4 + len - 4;
						if ( ACE_OS::strncmp(last4, "\r\n\r\n", 4) == 0 )
							break;
					}
				}
				stream.close();
			}

			//ACE_OS::write_n(ACE_STDOUT, http_res.c_str(), http_res.size()); //@

			// if license check failed, create lock file.
			if ( http_res.find("Action=ForceDisable\r\n") != std::string::npos )
			{
				FILE* fp_lock = ::fopen(lck_file.c_str(), "wb");
				if ( fp_lock )
				{
					::fwrite(http_res.c_str(), sizeof(char), http_res.size(), fp_lock);
					::fclose(fp_lock);
				}

				// make lock file unaccessible
				ACE_File_Lock flock(ACE_INVALID_HANDLE, 0); // default to avoid unlink in dtor
				flock.open(lck_file.c_str(), O_RDONLY);
				
				// sleep for check_interval/2
				int sleep_time = check_interval-5;
				if ( sleep_time < 1 ) sleep_time = 1;
				ACE_OS::sleep(sleep_time);

				flock.remove(0); // don't unlink lock file after sleep()
			}
			// else delete lock file
			else
			{
				ACE_OS::unlink(lck_file.c_str());
			}
		}
	}

	ACE_Time_Value t2 = ACE_OS::gettimeofday();
	ACE_OS::printf("elasped:%d\n", t2.msec()-t1.msec());

	return 0;
}
