#ifndef _ZM_UTIL_H_
#define _ZM_UTIL_H_

#include "String.h"
#include "MIME_Entity.h"
using namespace aos;

#include <set>
#include <map>

namespace mozart {

class ZM_Util
{
public:
	typedef std::map< std::string, int > CHARSET_HITS;
	static const char* ZM_DEFAULT_CHARSET;

public:
	// basic zm_fix functions
	static std::string zm_get_best_charset(MIME_Entity& e, const char* default_charset = ZM_DEFAULT_CHARSET);
	static void zm_fix_mail_header(MIME_Entity& e, const char* default_charset = ZM_DEFAULT_CHARSET);
	static void zm_fix_ctype_text(MIME_Entity& e, const char* default_charset = ZM_DEFAULT_CHARSET);
	static void zm_fix_header_charset(std::string& hdr);
	static void zm_fix_qp_dot(MIME_Entity& e, int& fixed);
	static void zm_get_charset_hit(MIME_Entity& e, CHARSET_HITS& hits);

public: // optional zm_fix functions
	static void zm_fix_attachment_name(MIME_Entity& e, const char* default_charset = ZM_DEFAULT_CHARSET);
	static void zm_fix_text_to_utf8(MIME_Entity& e, const char* default_charset = ZM_DEFAULT_CHARSET);
};

} // namespace mozart

#endif // _ZM_UTIL_H_
