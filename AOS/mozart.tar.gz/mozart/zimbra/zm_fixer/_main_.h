
#include "MIME_Header.h"

int test(int argc, char* argv[])
{
	std::string cmd;
	cmd = "/opt/zimbra/postfix/sbin/sendmail -G -i -f angus@zcsdemo.cellopoint.com -- angus@zcsdemo.cellopoint.com < /usr/local/mozart/z_addon/out.eml";
	//cmd = "dir . ";
	::printf("cmd: %s\n", cmd.c_str());
	::system(cmd.c_str());

	//aos::MIME_Header hdr(
	//	"Subject: abc=?big5?B?t3G90KZQvsfAy6xkpECkVUlQ\r\n ?=def=?sd?B?xd?=? abc\r\n",
	//	MIME_Header::Decode_Parser);
	////hdr.assign("Subject: =?big5?B?t3G90KZQvsfAy6xkpECkVUlQ\r\n ?=\r\n");
	//hdr.dump();
	//hdr.parse(MIME_Header::No_Parser);
	//hdr.dump();

	//static const int BUFSIZE = 4096; 
	//char buf[BUFSIZE];
	//int n_read = 0;
	//while( (n_read = ACE_OS::read(ACE_STDIN, buf, BUFSIZE)) > 0 )
	//{
	//	ACE_OS::write(ACE_STDOUT, buf, n_read);
	//}

	return 0;
}

// main.h
