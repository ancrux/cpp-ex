
- download spamcop.net 的 script 放在 192.168.1.68

- 登入 1.68 後，先切換 user 成 bl
su - bl

- 程式是定期由 crontab 每小時執行
crontab -l
0 * * * * /usr/bin/php /home/bl/spamcop.php

- spamcop.php 的功能就是把 spamcop.net 的 spam black list 下載後，
轉成 ips 格式。再把 ips 檔 cp 到 gas1 /home/bl 目錄下，由 Yuteh 的
python scripts (也是 crontab 執行) 移到 /opt/mozart/sbrs_server/update
目錄更新

