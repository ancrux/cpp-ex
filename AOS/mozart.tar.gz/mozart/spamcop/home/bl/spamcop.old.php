<?
if (!function_exists('file_put_contents'))
{
	
define(FILE_APPEND, 1);
function file_put_contents($filename, &$data, $file_append = 0)
{
	$fp = fopen($filename, (!$file_append ? 'w+' : 'a+'));
	if(!$fp)
	{
		trigger_error('file_put_contents cannot write in file.', E_USER_ERROR);
		return;
	}
	fputs($fp, $data);
	fclose($fp);
}

}
set_time_limit(0);

system("rsync -e ssh -L bl@blrsync.spamcop.net:bl.data ~/bl.data");

$bl_file = "bl.data";

$arrLine = @file($bl_file);
$output = '';

$timestamp = date('Y-m-d_H_i_s');

$count = -1;
foreach($arrLine as $i => $line)
{
	if ( $count < 0 )
	{
		if ( strncmp($line, "127.0.0.", strlen("127.0.0.")) == 0 )
			++$count;
		continue;
	}
	
	$ip = trim($line);
	$output .= ip_to_5byte($ip, 0x00); // always Poor IP
}
file_put_contents("{$timestamp}.ips", $output);

function ip_to_5byte($ip, $flag)
{
	$octet = '';
	$arr = explode('.', $ip);
	for($i=0;$i<4;++$i)
		$octet .= chr(intval($arr[$i]));
	$octet .= chr($flag);
	
	return $octet;
}
?>