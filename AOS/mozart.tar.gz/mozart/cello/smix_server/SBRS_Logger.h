#ifndef _SBRS_LOGGER_H_
#define _SBRS_LOGGER_H_

#include "ace/OS.h"
#include "ace/Singleton.h"
#include "ace/Null_Mutex.h"

#include "aos/Logger.h"

class SBRS_Logger : public aos::Logger
{
public:
	SBRS_Logger() : aos::Logger(".", "smix_", "log", aos::Logger::Rotate::DAY, 30, 1000 * 1000 * 1024) {};
	virtual ~SBRS_Logger() {};
};

typedef ACE_Singleton< SBRS_Logger, ACE_Null_Mutex > The_SBRS_Logger;
#define SBRS_LOG (The_SBRS_Logger::instance())
//static inline SVM_Logger* SVM_LOGGER() { return The_SVM_Logger::instance(); };

#endif // _SBRS_LOGGER_H_


