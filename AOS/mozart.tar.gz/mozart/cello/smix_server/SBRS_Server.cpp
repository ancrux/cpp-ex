#include "SBRS_Server.h"

#include <set>

namespace asio {

const char*
SBRS_Server::SIP_CSV_FILE = "ws.csv";

SBRS_Server::SBRS_Server(io_service& ios, SBRS_MAPS& maps)
:
//stop_(0),
ios_(ios),
maps_(maps),
acceptor_(ios)
{
}

SBRS_Server::~SBRS_Server()
{
	this->stop();
}

int
SBRS_Server::svc()
{
	ACE_OS::printf("thr(%u) start...\n", ACE_OS::thr_self()); //@

	io_service::work work(ios_);

	//ACE_Time_Value sleep_tv; sleep_tv.set(0.001);
	while(1) // while( !stop_.value() )
	{
		ios_.run();
		break;

		//ACE_OS::sleep(sleep_tv);
		//ACE_OS::printf("====================\n");
	}

	ACE_OS::printf("thr(%u) stop...\n", ACE_OS::thr_self()); //@

	return 0;
}

error_code
SBRS_Server::start(unsigned short port, const char* ip_addr, int n_thread)
{
	error_code ec;

	ip::tcp::endpoint local_addr(ip::tcp::v4(), port);
	if ( ip_addr )
		local_addr.address(ip::address::from_string(ip_addr));

	acceptor_.open(local_addr.protocol(), ec); if ( ec ) return ec;
	acceptor_.set_option(ip::tcp::acceptor::reuse_address(true), ec); if ( ec ) return ec;
	acceptor_.bind(local_addr, ec); if ( ec ) return ec;
	int backlog = socket_base::max_connections;
	//ACE_OS::printf("backlog:%d\n", backlog); //@
	acceptor_.listen(backlog, ec); if ( ec ) return ec;

	// prepare connection for accept()
	SBRS_Server_Connection* conn = new (std::nothrow) SBRS_Server_Connection(this->ios_, this);
	acceptor_.async_accept(conn->socket(), boost::bind(
		&SBRS_Server::handle_accept,
		this,
		placeholders::error,
		conn)); //? no strand wrap for async_accept()?
	
	if ( n_thread < 1 )
		n_thread = ACE_OS::num_processors_online() * 4; //? * 4 for default

	this->activate(THR_NEW_LWP | THR_JOINABLE, n_thread);

	return ec;
}

void
SBRS_Server::stop()
{
	// get thread count
	//size_t n_thread = this->thr_count();

	// stop all io_service thread(s)
	//this->stop_ = 1;
	this->ios_.stop();

	// wait for thread(s) to terminate
	this->wait();
	//for(size_t i=0; i < n_thread; ++i) this->wait();
	
	// then, close all connections
	this->clear_all_connections();
}

void
SBRS_Server::handle_accept(const error_code& error, SBRS_Server_Connection* conn)
{
	if ( conn )
	{
		if ( error ) delete conn;

		// insert new connection
		std::string remote_addr(conn->socket().remote_endpoint().address().to_string());
		unsigned short remote_port = conn->socket().remote_endpoint().port();
		if ( this->create_connection(conn, remote_addr.c_str()) )
			conn->accept(remote_addr.c_str(), remote_port);
		else
			delete conn;

		// prepare connection for accept()
		conn = new (std::nothrow) SBRS_Server_Connection(this->ios_, this);
		acceptor_.async_accept(conn->socket(), boost::bind(
			&SBRS_Server::handle_accept,
			this,
			placeholders::error,
			conn));
	}
}

size_t
SBRS_Server::n_connection(const char* key)
{
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, lock_, 0);

	if ( !key ) return pool_.size();

	size_t n_conn = 0;
	CONNECTIONS::iterator iter = pool_.find(key);
	if ( iter != pool_.end() )
	{
		n_conn = 1;
		++iter;
		while( iter != pool_.end() )
		{
			if ( iter->first != key ) break;
			++n_conn;
			++iter;
		}
	}
	return n_conn;
}

int
SBRS_Server::is_connected_from(const char* key)
{
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, lock_, 0);

	return (pool_.find(key) == pool_.end())?0:1;
}

SBRS_Server_Connection*
SBRS_Server::create_connection(SBRS_Server_Connection* conn, const char* key)
{
	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, lock_, 0);

	// check max connection, 0 for no limit
	if ( MAX_CONNECTION && pool_.size() >= MAX_CONNECTION ) return 0;
	
	// insert connection
	pool_.insert(std::make_pair(key, conn));
	//ACE_OS::printf("create:%p\n", conn); //@

	return conn;
}

void
SBRS_Server::destroy_connection(SBRS_Server_Connection* conn)
{
	ACE_GUARD(ACE_Thread_Mutex, guard, lock_);

	// remove it from pool
	for(CONNECTIONS::iterator iter = pool_.begin();
		iter != pool_.end();
		++iter)
	{
		if ( conn == iter->second )
		{
			//ACE_OS::printf("destroy:%p\n", iter->second); //@
			pool_.erase(iter);
			break;
		}
	}
	// delete connection
	delete conn;
}

void
SBRS_Server::clear_all_connections()
{
	ACE_GUARD(ACE_Thread_Mutex, guard, lock_);

	for(CONNECTIONS::iterator iter = pool_.begin();
		iter != pool_.end();
		++iter)
	{
		delete iter->second;
	}
	pool_.clear();
}

size_t
SBRS_Server::sbrs_size()
{
	size_t count = 0;

	ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, this->lock(), count);
	size_t n_map = maps_.size();
	for(size_t i=0; i < n_map; ++i)
	{
		count += maps_[i]->size();
	}

	return count;
}

int
SBRS_Server::sip_reload(const char* path)
{
	int n_entry = -1;

	do
	{
		ACE_OS::printf("reload '%s'\n", path);
		FILE* fp = ACE_OS::fopen(path, "rb");
		if ( fp == NULL )
		{
			ACE_OS::printf("reload '%s' failed!\n", path);
			break;
		}

		sip_.clear();
		n_entry = 0;

		const int MAX_LINE = 4096;
		char line[MAX_LINE+1];
		while( ACE_OS::fgets(line, MAX_LINE, fp) != NULL )
		{
			aos::Multi_String ipstr;
			double score = -1.0;

			// get ip
			aos::Tokenizer toker;
			toker.c_str(line);
			toker.set_separator(".,\r\n");
			for(int i=0; i<4; ++i)
			{
				int ch = toker.next();
				ipstr.push_back(toker.token(), toker.size());
				if ( ch != '.' )
					break;
			}
			if ( ipstr.size() < 3 ) continue;
			// get score
			const char* strd_beg = toker.token_end()+1;
			char* strd_end;
			double strd = ACE_OS::strtod(strd_beg, &strd_end);
			if ( strd_beg != strd_end )
				score = strd;
			if ( score < 0 ) continue;

			int n_map = (int) maps_.size();
			unsigned char sco = (int) (score * 255);

			if ( ipstr.size() == 4 )
			{
				int ia = ACE_OS::atoi(ipstr[0]);
				int ib = ACE_OS::atoi(ipstr[1]);
				int ic = ACE_OS::atoi(ipstr[2]);
				int id = ACE_OS::atoi(ipstr[3]);

				ACE_UINT32 ip32 = ia * 16777216 + ib * 65536 + ic * 256 + id;
				int idx = id % n_map;
				
				ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, this->lock(), n_entry);
				sip_.insert(std::make_pair(ip32, sco));
				//(maps_[idx])->erase(ip32);
				//(maps_[idx])->insert(std::make_pair(ip32, sco));
				++n_entry;
			}
			else if ( ipstr.size() == 3 )
			{
				int ia = ACE_OS::atoi(ipstr[0]);
				int ib = ACE_OS::atoi(ipstr[1]);
				int ic = ACE_OS::atoi(ipstr[2]);

				ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, this->lock(), n_entry);
				for(int id=0; id < 256; ++id)
				{
					ACE_UINT32 ip32 = ia * 16777216 + ib * 65536 + ic * 256 + id;
					int idx = id % n_map;

					sip_.insert(std::make_pair(ip32, sco));
					//(maps_[idx])->erase(ip32);
					//(maps_[idx])->insert(std::make_pair(ip32, sco));
				}
				++n_entry;
			}
		}

		ACE_OS::fclose(fp);
	}
	while(0);

	return n_entry;
}

int
SBRS_Server::load_srl_file(const char* path)
{
	int rc = -1;

	do
	{
		ACE_HANDLE fh = ACE_OS::open(path, O_BINARY | O_RDONLY);
		if ( fh == ACE_INVALID_HANDLE )
		{
			ACE_OS::printf("load '%s' failed!\n", path);
			break;
		}

		rc = 0;

		const int BUF_SIZE = 20000;
		unsigned char buf[BUF_SIZE];

		while(1)
		{
			ssize_t n_read = ACE_OS::read(fh, buf, BUF_SIZE);
			if ( n_read <= 0 ) break;

			{
				//ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, server_.lock(), rc);

				for(int i=0; i < n_read; i += 5)
				{
					const unsigned char* item = buf + i;
					ACE_UINT32 ip32 = (*item) * 16777216 + (*(item+1)) * 65536 + (*(item+2)) * 256 + (*(item+3));
					unsigned char score = *(item+4);

					////? update or insert 
					//SBRS_MAP::iterator iter = (maps_[idx])->find(ip32);
					//if (  iter != (maps_[idx])->end() )
					//	(maps_[idx])->erase(ip32);
					(sip_).insert(std::make_pair(ip32, score));
					++rc;
					//ACE_OS::printf("ip=%u, score=%d\n", ip32, score);
				}
			}
		}

		ACE_OS::close(fh);
	}
	while(0);

	return rc;
}

int
SBRS_Server::srl_load()
{
	int rc = -1;

	typedef std::set< std::string, std::greater< std::string > > FILES;
	FILES srl_files;

	const char* dir_path = ".";
	do
	{
		ACE_DIRENT* d;
		ACE_Dirent dir;

		if ( dir.open(dir_path) != 0 )
		{
			ACE_OS::printf("open dir '%s' failed!\n", dir_path);
			break;
		}

		// get sorted srl files
		while( (d = dir.read()) != 0 )
		{
			std::string file(dir_path); file += ACE_DIRECTORY_SEPARATOR_CHAR; file += d->d_name;
			ACE_stat stat;
			if ( ACE_OS::lstat(file.c_str(), &stat) == -1 || (stat.st_mode & S_IFMT) == S_IFDIR )
				continue;

			if ( file.size() > 4 && ACE_OS::strcasecmp(file.c_str() + file.size() - 4, ".srl") == 0 )
				srl_files.insert(file);
		}
		dir.close();

		rc = 0;
		// load srl_files
		for(FILES::iterator iter = srl_files.begin(); iter != srl_files.end(); ++iter)
		{
			std::string file = *iter;

			size_t old_total = (sip_).size();

			ACE_OS::printf("thr(%u) srl is loading '%s'...\n", ACE_OS::thr_self(), file.c_str());
			int rc_load = this->load_srl_file(file.c_str());
			rc += rc_load;

			size_t new_total = (sip_).size();

			const int LOG_BUF_MAX = 2048;
			char LOG_BUF[LOG_BUF_MAX];
			int N_BUF = 0;

			if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "SRL loaded '%s'=%d, diff=%d, total=%u\n", file.c_str(), rc_load, (int) new_total-old_total, new_total)) > 0 )
				SBRS_LOG->log(LOG_BUF, N_BUF);
		}
	}
	while(0);

	return rc;
}





} // namespace asio

