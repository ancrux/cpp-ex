#include "SBRS_Updater.h"

namespace asio {

SBRS_Updater::SBRS_Updater(asio::SBRS_Server& server)
:
stop_(0),
server_(server)
{
}

SBRS_Updater::~SBRS_Updater()
{
	this->stop();
}

void
SBRS_Updater::start()
{
	this->stop_ = 0;
	this->activate(THR_NEW_LWP | THR_JOINABLE, 1);
}

void
SBRS_Updater::stop()
{
	this->stop_ = 1;
	this->wait();
}

int
SBRS_Updater::update_server_from_file(const char* path)
{
	int rc = -1;

	do
	{
		ACE_HANDLE fh = ACE_OS::open(path, O_BINARY | O_RDONLY);
		if ( fh == ACE_INVALID_HANDLE )
		{
			ACE_OS::printf("update '%s' failed!\n", path);
			break;
		}

		rc = 0;

		size_t n_map = server_.maps_.size();
		const int BUF_SIZE = 20000;
		unsigned char buf[BUF_SIZE];

		while(!stop_.value())
		{
			ssize_t n_read = ACE_OS::read(fh, buf, BUF_SIZE);
			if ( n_read <= 0 ) break;

			{
				ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, server_.lock(), rc);

				for(int i=0; i < n_read; i += 5)
				{
					const unsigned char* item = buf + i;
					ACE_UINT32 ip32 = (*item) * 16777216 + (*(item+1)) * 65536 + (*(item+2)) * 256 + (*(item+3));
					unsigned char score = *(item+4);
					int idx = int( (*(item+3)) % n_map );

					SBRS_MAP::iterator iter = (server_.maps_[idx])->find(ip32);
					if (  iter != (server_.maps_[idx])->end() )
						(server_.maps_[idx])->erase(ip32);
					(server_.maps_[idx])->insert(std::make_pair(ip32, score));
					++rc;
					//ACE_OS::printf("ip=%u, score=%d\n", ip32, score);
				}
			}
		}

		ACE_OS::close(fh);
	}
	while(0);

	return rc;
}

int
SBRS_Updater::svc()
{
	ACE_OS::printf("updater(%u) started...\n", ACE_OS::thr_self()); //@

	const char* dir_update = "update";
	const char* dir_recycle = "update_ok";

	ACE_OS::mkdir(dir_update);
	ACE_OS::mkdir(dir_recycle);

	ACE_Time_Value sleep_tv; sleep_tv.set(0.01);
	while( !stop_.value() )
	{
		do
		{
			ACE_DIRENT* d;
			ACE_Dirent dir;

			if ( dir.open(dir_update) != 0 )
			{
				ACE_OS::printf("open dir '%s' failed!\n", dir_update);
				break;
			}

			while( (d = dir.read()) != 0 )
			{
				std::string file(dir_update); file += ACE_DIRECTORY_SEPARATOR_CHAR; file += d->d_name;
				ACE_stat stat;
				if ( ACE_OS::lstat(file.c_str(), &stat) == -1 || (stat.st_mode & S_IFMT) == S_IFDIR )
					continue;
				if ( file.size() <= 4 || ACE_OS::strcasecmp(file.c_str() + file.size() - 4, ".ips") != 0 )
					continue;

				size_t old_total = server_.sbrs_size();

				ACE_OS::printf("updating '%s'...\n", file.c_str());
				int rc_update = this->update_server_from_file(file.c_str());

				size_t new_total = server_.sbrs_size();

				const int LOG_BUF_MAX = 2048;
				char LOG_BUF[LOG_BUF_MAX];
				int N_BUF = 0;

				if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "update '%s'=%d, diff=%d, total=%u\n", file.c_str(), rc_update, (int) new_total-old_total, new_total)) > 0 )
					SBRS_LOG->log(LOG_BUF, N_BUF);

				// move processed file
				std::string new_file(dir_recycle); new_file += ACE_DIRECTORY_SEPARATOR_CHAR; new_file += d->d_name; //ACE_OS::unlink(new_file.c_str());
				ACE_OS::rename(file.c_str(), new_file.c_str());
			}
			dir.close();
		}
		while(0);

		ACE_OS::sleep(sleep_tv);
	}

	ACE_OS::printf("updater(%u) stopped...\n", ACE_OS::thr_self()); //@

	return 0;
}

} // namespace asio

