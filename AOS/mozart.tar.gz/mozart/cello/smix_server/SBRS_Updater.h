#ifndef _ASIO_SBRS_UPDATER_H_
#define _ASIO_SBRS_UPDATER_H_

#include "ace/Atomic_Op.h"
#include "ace/Task_Ex_T.h"

#include "SBRS.h"
#include "SBRS_Server.h"

namespace asio {

class SBRS_Updater : public ACE_Task_Base
{
public:
	SBRS_Updater(SBRS_Server& server);
	~SBRS_Updater();

public:
	virtual int svc();

public:
	int update_server_from_file(const char* path);

public:
	void start();
	void stop();

protected:
	ACE_Atomic_Op<ACE_Thread_Mutex, long> stop_;

	SBRS_Server& server_;
};

} // namespace asio

#endif // _ASIO_SBRS_UPDATER_H_
