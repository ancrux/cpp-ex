#include "SBRS_Server_Connection.h"

#include "SBRS_Server.h" // friend class

namespace asio {

SBRS_Server_Connection::SBRS_Server_Connection(io_service& ios, SBRS_Server* server)
:
socket_(ios),
strand_(ios),
timer_(ios),
mb_(MAX_BUF),
server_(server),
state_(READY)
{
	timeout_ = server_->timeout();
	io_.open();
}

SBRS_Server_Connection::~SBRS_Server_Connection()
{
	io_.close();
	//ACE_OS::printf("%p:conn dtor()\n", this); //@
}

//-- open

void
SBRS_Server_Connection::accept(const char* ip_addr, unsigned short port)
{
	remote_addr_ = ip_addr;
	remote_port_ = port;

	ACE_OS::printf("client from:%s:%d\n", remote_addr_.c_str(), remote_port_); //@

	io_.read_reset(mb_);
	this->read(mb_, timeout_);

	const int LOG_BUF_MAX = 2048;
	char LOG_BUF[LOG_BUF_MAX];
	int N_BUF = 0;

	if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\tConnected!\n", remote_addr_.c_str(), remote_port_)) > 0 )
		SBRS_LOG->log(LOG_BUF, N_BUF);
}

//-- read/write

void
SBRS_Server_Connection::read(ACE_Message_Block& mb, long timeout)
{
	ACE_GUARD(ACE_Thread_Mutex, guard, lock_);

	socket_.async_read_some(buffer(mb.wr_ptr(), mb.space()), strand_.wrap(boost::bind(
		&SBRS_Server_Connection::handle_read,
		this,
		placeholders::error,
		placeholders::bytes_transferred)));

	if ( timeout > 0 )
	{
		timer_.expires_from_now(boost::posix_time::seconds(timeout));
		timer_.async_wait(strand_.wrap(boost::bind(
			&SBRS_Server_Connection::handle_socket_timeout,
			this,
			placeholders::error)));
	}
}

void
SBRS_Server_Connection::handle_read(const error_code& error, size_t bytes_transferred)
{
	this->cancel_timer();
	if ( error )
	{
		//ACE_OS::printf("read error:%s\n", error.message().c_str()); //@

		const int LOG_BUF_MAX = 2048;
		char LOG_BUF[LOG_BUF_MAX];
		int N_BUF = 0;

		if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\tRead Error!\t%s\n", remote_addr_.c_str(), remote_port_, error.message().c_str())) > 0 )
			SBRS_LOG->log(LOG_BUF, N_BUF);

		return this->close();
	}

	//ACE_OS::printf("read completed: %d\n", bytes_transferred); //@

	mb_.wr_ptr(bytes_transferred);
	// read greetings
	while( mb_.length() > 0 )
	{
		aos::bcstr data = io_.read_request(mb_);
	}
	// keep reading
	if ( io_.read_state() != SBRS_Server_IO::RD_OK )
	{
		mb_.reset();
		this->read(mb_, timeout_);
		return;
	}
	// read completed
	else
	{
		// write command
		//ACE_OS::printf("C:%s", io_.buf().c_str()); //@

		// parse command
		aos::Multi_String params;
		aos::Tokenizer toker(io_.buf().c_str(), io_.buf().size());
		toker.set_separator(" \t\r\n");
		int ch;
		do
		{
			ch = toker.next();
			if ( toker.size() )
				params.push_back(toker.token(), toker.size());
		}
		while( ch != aos::Tokenizer::End );

		size_t n_param = params.size();
		if ( !n_param ) // params[0] == 0
		{
			return this->close();
		}

		if ( ACE_OS::strcasecmp(params[0], "SBRS") == 0 )
		{
			// handle ip score
			if ( n_param >= 2 && *(params[1]) >= '0' && *(params[1]) <= '9' && n_param < 12 )
			{
				mb_.reset();
				int n_len = 0;			
				{
					ACE_GUARD(ACE_Thread_Mutex, guard, server_->lock());
					for(size_t i=1; i < n_param; ++i)
					{
						ACE_UINT32 ipv4 = IPv4::to_uint32(params[i]); ACE_OS::printf("ip_int:%u\n", ipv4); //@
						double score = -1.0;

						do
						{
							SBRS_MAP::iterator it = (server_->sip_).find(ipv4);
							if ( it != (server_->sip_).end() )
							{
								score = (double) it->second / 255;
								break;
							}

							size_t n_map = server_->maps_.size();
							int idx = ipv4 % n_map;
							SBRS_MAP::iterator iter = (server_->maps_[idx])->find(ipv4);
							if ( iter != (server_->maps_[idx])->end() )
								score = (double) iter->second / 255;
						}
						while(0);

						// save score
						n_len = ACE_OS::snprintf(mb_.wr_ptr(), mb_.space(), "%f ", score);
						if ( n_len <= 0 )
							break;
						mb_.wr_ptr(n_len);
					}
				}
				n_len = ACE_OS::snprintf(mb_.wr_ptr(), mb_.space(), "\r\n\r\n");
				if ( n_len > 0 ) mb_.wr_ptr(n_len);

				// write log
				const int LOG_BUF_MAX = 2048;
				char LOG_BUF[LOG_BUF_MAX];
				int N_BUF = 0;

				std::string ips;
				for(size_t i=1; i < n_param; ++i)
				{
					ips += params[i]; ips += " ";
				}
				std::string scores(mb_.base(), mb_.length()-4);
				if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\t%s\t%s= %s\n", remote_addr_.c_str(), remote_port_, params[0], ips.c_str(), scores.c_str())) > 0 )
					SBRS_LOG->log(LOG_BUF, N_BUF);

				//io_.write_score(mb_, score);
				this->write(mb_, timeout_);
			}
			// handle size
			else if ( n_param == 2 && ACE_OS::strcasecmp(params[1], "SIZE") == 0 )
			{
				double score = -1.0;
				score = server_->sbrs_size();

				io_.write_score(mb_, score);
				this->write(mb_, timeout_);

				const int LOG_BUF_MAX = 2048;
				char LOG_BUF[LOG_BUF_MAX];
				int N_BUF = 0;

				if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\t%s\t%s\t%f\n", remote_addr_.c_str(), remote_port_, params[0], params[1], score)) > 0 )
					SBRS_LOG->log(LOG_BUF, N_BUF);
			}
			// handle dump
			else if ( n_param == 3 && ACE_OS::strcasecmp(params[1], "DUMP") == 0 )
			{
				int rc = -1;

				ACE_HANDLE fh = ACE_OS::open(params[2], O_CREAT | O_TRUNC | O_BINARY | O_WRONLY);
				do
				{
					if ( fh == ACE_INVALID_HANDLE )
						break;

					size_t n_map = server_->maps_.size();
					for(size_t i=0; i<n_map; ++i)
					{
						ACE_GUARD(ACE_Thread_Mutex, guard, server_->lock());

						std::string block;
						SBRS_MAP::iterator iter = (server_->maps_[i])->begin();
						while( iter != (server_->maps_[i])->end() )
						{
							ACE_UINT32 ip32 = iter->first;

							unsigned char ip[5];
							ip[0] = (ip32 >> 24);
							ip[1] = (ip32 >> 16) % 256;
							ip[2] = (ip32 >> 8) % 256;
							ip[3] = ip32 % 256;
							ip[4] = iter->second;

							block.append((const char*) ip, 5);
							if ( block.size() > 100 * 1000 )
							{
								// write to file
								ACE_OS::write(fh, (void*) block.c_str(), block.size());
								block.resize(0);
							}

							++iter;
						}
						// write to file
						ACE_OS::write(fh, (void*) block.c_str(), block.size());
						block.resize(0);
					}
					ACE_OS::close(fh);
					rc = 0;
				}
				while(0);

				io_.write_score(mb_, (double) rc);
				this->write(mb_, timeout_);
			}
			// handle error
			else
			{
				const int LOG_BUF_MAX = 2048;
				char LOG_BUF[LOG_BUF_MAX];
				int N_BUF = 0;

				if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\t%s Error Command!\n", remote_addr_.c_str(), remote_port_, params[0])) > 0 )
					SBRS_LOG->log(LOG_BUF, N_BUF);

				return this->close();
			}
		}
		else if ( ACE_OS::strcasecmp(params[0], "SIP") == 0 && n_param == 2 )
		{
			if ( ACE_OS::strcasecmp(params[1], "RELOAD") != 0 )
				return this->close();
			
			double score = -1.0;

			// reload SIP here
			score = server_->sip_reload(SBRS_Server::SIP_CSV_FILE);

			io_.write_score(mb_, score);
			this->write(mb_, timeout_);

			const int LOG_BUF_MAX = 2048;
			char LOG_BUF[LOG_BUF_MAX];
			int N_BUF = 0;

			if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\t%s\t%s\n", remote_addr_.c_str(), remote_port_, params[0], params[1])) > 0 )
				SBRS_LOG->log(LOG_BUF, N_BUF);
		}
		else
		{
			const int LOG_BUF_MAX = 2048;
			char LOG_BUF[LOG_BUF_MAX];
			int N_BUF = 0;

			if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\tUnknown Command!\n", remote_addr_.c_str(), remote_port_)) > 0 )
				SBRS_LOG->log(LOG_BUF, N_BUF);

			return this->close();
		}
	}
}

void
SBRS_Server_Connection::write(ACE_Message_Block& mb, long timeout)
{
	ACE_GUARD(ACE_Thread_Mutex, guard, lock_);

	socket_.async_write_some(buffer(mb.rd_ptr(), mb.length()), strand_.wrap(boost::bind(
		&SBRS_Server_Connection::handle_write,
		this,
		placeholders::error,
		placeholders::bytes_transferred)));

	if ( timeout > 0 )
	{
		timer_.expires_from_now(boost::posix_time::seconds(timeout));
		timer_.async_wait(strand_.wrap(boost::bind(
			&SBRS_Server_Connection::handle_socket_timeout,
			this,
			placeholders::error)));
	}
}

void
SBRS_Server_Connection::handle_write(const error_code& error, size_t bytes_transferred)
{
	this->cancel_timer();
	if ( error )
	{
		//ACE_OS::printf("write error:%s\n", error.message().c_str()); //@

		const int LOG_BUF_MAX = 2048;
		char LOG_BUF[LOG_BUF_MAX];
		int N_BUF = 0;

		if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\tWrite Error!\t%s\n", remote_addr_.c_str(), remote_port_, error.message().c_str())) > 0 )
			SBRS_LOG->log(LOG_BUF, N_BUF);

		return this->close();
	}

	//ACE_OS::printf("write completed: %d\n", bytes_transferred); //@

	mb_.rd_ptr(bytes_transferred);
	// keep writing
	if ( mb_.length() > 0 )
	{
		this->write(mb_, timeout_);
		return;
	}
	// write completed
	else
	{
		io_.read_reset(mb_);
		this->read(mb_, timeout_);
	}	
}

void
SBRS_Server_Connection::handle_socket_timeout(const error_code& error)
{
	if ( !error )
	{
		//ACE_OS::printf("socket timeout!\n");
		ACE_GUARD(ACE_Thread_Mutex, guard, lock_);
		socket_.close(); // don't call this->close();

		const int LOG_BUF_MAX = 2048;
		char LOG_BUF[LOG_BUF_MAX];
		int N_BUF = 0;

		if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\tTimeouted!\n", remote_addr_.c_str(), remote_port_)) > 0 )
			SBRS_LOG->log(LOG_BUF, N_BUF);
	}
}

void
SBRS_Server_Connection::cancel_timer()
{
	ACE_GUARD(ACE_Thread_Mutex, guard, lock_);
	timer_.cancel();
}

void
SBRS_Server_Connection::close()
{
	ACE_GUARD(ACE_Thread_Mutex, guard, lock_);

	timer_.expires_from_now(boost::posix_time::seconds(0));
	timer_.async_wait(strand_.wrap(boost::bind(
		&SBRS_Server_Connection::handle_close,
		this,
		placeholders::error)));

	const int LOG_BUF_MAX = 2048;
	char LOG_BUF[LOG_BUF_MAX];
	int N_BUF = 0;

	if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "%s:%u\tDisconnected!\n", remote_addr_.c_str(), remote_port_)) > 0 )
		SBRS_LOG->log(LOG_BUF, N_BUF);
}

void
SBRS_Server_Connection::handle_close(const error_code& error)
{
	if ( server_ )
		server_->destroy_connection(this);
	else
		socket_.close();
}

} // namespace asio

