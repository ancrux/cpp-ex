#include "SBRS_Loader.h"

#include <set>

SBRS_Loader::SBRS_Loader(SBRS_MAPS& maps)
:
stop_(0),
maps_(maps),
index_(0)
{
}

SBRS_Loader::~SBRS_Loader()
{
	this->stop();
}

void
SBRS_Loader::start(int n_thread)
{
	this->index_ = 0;
	this->stop_ = 0;
	this->activate(THR_NEW_LWP | THR_JOINABLE, n_thread);
}

void
SBRS_Loader::stop()
{
	this->stop_ = 1;
	this->wait();
	this->index_ = 0;
}

int
SBRS_Loader::load_ips_file(const char* path, int index)
{
	int rc = -1;

	do
	{
		ACE_HANDLE fh = ACE_OS::open(path, O_BINARY | O_RDONLY);
		if ( fh == ACE_INVALID_HANDLE )
		{
			ACE_OS::printf("load '%s' failed!\n", path);
			break;
		}

		rc = 0;

		size_t n_map = maps_.size();
		const int BUF_SIZE = 20000;
		unsigned char buf[BUF_SIZE];

		while(!stop_.value())
		{
			ssize_t n_read = ACE_OS::read(fh, buf, BUF_SIZE);
			if ( n_read <= 0 ) break;

			{
				//ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, server_.lock(), rc);

				for(int i=0; i < n_read; i += 5)
				{
					const unsigned char* item = buf + i;
					ACE_UINT32 ip32 = (*item) * 16777216 + (*(item+1)) * 65536 + (*(item+2)) * 256 + (*(item+3));
					unsigned char score = *(item+4);
					int idx = int( (*(item+3)) % n_map );

					if ( idx == index )
					{
						////? update or insert 
						//SBRS_MAP::iterator iter = (maps_[idx])->find(ip32);
						//if (  iter != (maps_[idx])->end() )
						//	(maps_[idx])->erase(ip32);
						(maps_[idx])->insert(std::make_pair(ip32, score));
						++rc;
						//ACE_OS::printf("ip=%u, score=%d\n", ip32, score);
					}
				}
			}
		}

		ACE_OS::close(fh);
	}
	while(0);

	return rc;
}

int
SBRS_Loader::svc()
{
	int idx = -1;
	{
		ACE_GUARD_RETURN(ACE_Thread_Mutex, guard, lock_, -1);
		idx = index_;
		++index_;
	}
	if ( idx < 0 ) return -1;

	ACE_OS::printf("thr(%u) start with idx/size=%d/%d...\n", ACE_OS::thr_self(), idx, maps_.size()); //@


	typedef std::set< std::string, std::greater< std::string > > FILES;
	FILES files;

	const char* dir_path = ".";
	do
	{
		ACE_DIRENT* d;
		ACE_Dirent dir;

		if ( dir.open(dir_path) != 0 )
		{
			ACE_OS::printf("open dir '%s' failed!\n", dir_path);
			break;
		}

		// get sorted ips files
		while( (d = dir.read()) != 0 )
		{
			std::string file(dir_path); file += ACE_DIRECTORY_SEPARATOR_CHAR; file += d->d_name;
			ACE_stat stat;
			if ( ACE_OS::lstat(file.c_str(), &stat) == -1 || (stat.st_mode & S_IFMT) == S_IFDIR )
				continue;
			if ( file.size() <= 4 || ACE_OS::strcasecmp(file.c_str() + file.size() - 4, ".ips") != 0 )
				continue;

			files.insert(file);
		}
		dir.close();

		// load ips files
		for(FILES::iterator iter = files.begin(); iter != files.end(); ++iter)
		{
			std::string file = *iter;

			size_t old_total = (maps_[idx])->size();

			ACE_OS::printf("thr(%u) idx=%d is loading '%s'...\n", ACE_OS::thr_self(), idx, file.c_str());
			int rc_load = this->load_ips_file(file.c_str(), idx);

			size_t new_total = (maps_[idx])->size();

			const int LOG_BUF_MAX = 2048;
			char LOG_BUF[LOG_BUF_MAX];
			int N_BUF = 0;

			if ( (N_BUF = ACE_OS::snprintf(LOG_BUF, LOG_BUF_MAX, "loaded '%s'=%d, diff=%d, total=%u\n", file.c_str(), rc_load, (int) new_total-old_total, new_total)) > 0 )
				SBRS_LOG->log(LOG_BUF, N_BUF);
		}
	}
	while(0);

	ACE_OS::printf("thr(%u) stop...\n", ACE_OS::thr_self()); //@

	return 0;
}
