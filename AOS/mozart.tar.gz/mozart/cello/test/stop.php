<?php

system('echo "STOP!" > stop.txt');

exit(64);

?>