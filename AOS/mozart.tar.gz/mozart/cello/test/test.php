<?php

$c = 0;
while(1)
{
	echo "$c\n";
	sleep(1);
	
	++$c;
}

?>