
int test()
{
	ACE_OS::printf("Hello!\n");

	return 0;
}

/*
class A
{
public:
	int c;
};

class B : public A
{
public:
	int c;
};
//*/

// main.h
