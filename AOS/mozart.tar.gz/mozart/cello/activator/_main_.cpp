#include "ace/OS.h"
#include "ace/Get_Opt.h"
#include "ace/Configuration_Import_Export.h"
#include "ace/Task.h"
#include "ace/Process_Manager.h"
#include "ace/Process_Mutex.h"

#include <vector>
#include <iostream>
using namespace std;

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	//return test();

	// make sure only one instance
	static const ACE_TCHAR* uniqueName = "theOnlyActivator";
	ACE_Process_Mutex mutex(uniqueName);
	if ( mutex.tryacquire() != 0 )
	{
		ACE_OS::printf("[%s] is already running...\n", ACE::basename(argv[0]));
		return 0;
	}

	// process
	std::vector< ACE_Process* > processes;
	std::vector< ACE_Process_Options* > options;
	std::vector< pid_t > pids;
	std::vector< int > intervals;

	// get console parameters
	ACE_Get_Opt cmdline(argc, argv, ACE_TEXT(""));

	// get configuration filename
	std::string cfg_file(ACE::basename(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
	if ( cfg_file.rfind('.') != std::string::npos ) cfg_file = ACE::dirname(cfg_file.c_str(), '.');
	cfg_file.insert(0, 1, ACE_DIRECTORY_SEPARATOR_CHAR);
	cfg_file.insert(0, ACE::dirname(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
	cfg_file += ".ini";
	ACE_OS::printf("cfg_file:%s\n", cfg_file.c_str());

	// read configurattion
	ACE_Configuration_Heap config;
	config.open();

	ACE_Ini_ImpExp iniIO(config);
	iniIO.import_config(cfg_file.c_str());

	// iterate through entire file (not including sub-section iteration)
	ACE_Configuration_Section_Key sec;
	sec = config.root_section();
	ACE_TString sec_name;
	for(int sec_index = 0;
		config.enumerate_sections(sec, sec_index, sec_name) == 0;
		++sec_index)
	{
		ACE_Configuration_Section_Key sub_sec;
		config.open_section(sec, sec_name.c_str(), 0, sub_sec); 
		ACE_TString value;

		ACE_OS::printf("sec: %s\n", sec_name.c_str());

		ACE_Process* process = new ACE_Process;
		ACE_Process_Options*  option = new ACE_Process_Options;
		pid_t pid = ACE_INVALID_PID;
		int interval = 0;

		config.get_string_value(sub_sec, ACE_TEXT("Command"), value);
		option->command_line(value.c_str());
		//option->avoid_zombies(1); // always cause return pid = 1
		ACE_OS::printf("value: %s\n", value.c_str());
		value.resize(0);

		config.get_string_value(sub_sec, ACE_TEXT("KeepAliveInterval"), value);
		interval = (int) ACE_OS::atoi(value.c_str());
		ACE_OS::printf("value: %d\n", interval);
		value.resize(0);

		processes.push_back(process);
		options.push_back(option);
		pids.push_back(pid);
		intervals.push_back(interval);
	}

	// execute startup script here
	// ACE_OS::system(startup_script);

	// processes initialization
	for(size_t i=0; i < processes.size(); ++i)
	{
		pids[i] = processes[i]->spawn(*(options[i]));
		//ACE_OS::printf("pid: %d, cmd: %s\n", pids[i], options[i]->process_name());
	}
	ACE_OS::sleep(1);

	// spawn processes loop
	while(true)
	{
		ACE_Time_Value now = ACE_OS::gettimeofday();
		for(size_t i=0; i < processes.size(); ++i)
		{
			if ( intervals[i] == 0 && pids[i] == ACE_INVALID_PID ) continue;

			pids[i] = processes[i]->wait(ACE_Time_Value::zero);
			
			if ( intervals[i] != 0 &&
				now.sec() % intervals[i] == 0 &&
				!processes[i]->running() )
			{
				pids[i] = processes[i]->spawn(*(options[i]));
				//ACE_OS::printf("pid: %d, cmd: %s\n", pids[i], options[i]->process_name());
			}
		}

		ACE_OS::sleep(1);
	}

	// clear processes
	for(size_t i=0; i < processes.size(); ++i)
	{
		delete processes[i];
	}
	processes.clear();
	// clear options
	for(size_t i=0; i < options.size(); ++i)
	{
		delete options[i];
	}
	options.clear();


	/*
	// old code
	char cmd[PATH_MAX+1];
	ACE_OS::snprintf(cmd, PATH_MAX, "/usr/local/mozart/activator/journal");

	// prepare for script execution
	ACE_Process_Manager* pm = ACE_Process_Manager::instance();
	ACE_Process_Options opt;
	opt.command_line(cmd);

	// run command
	ACE_Process p;
	pid_t pid = ACE_INVALID_PID;
	while(true)
	{
		pid = pm->wait(pid, ACE_Time_Value::zero);
		if ( p.running() )
		{
			// do nothing, if still running
			ACE_OS::printf("still running...\n");
		}
		else
		{
			ACE_OS::printf("cmd:%s\n", cmd);
			pid = pm->spawn(&p, opt);
			ACE_OS::printf("re-spawn(): %d\n", pid);
		}

		ACE_OS::sleep(1);
	}
	//*/

	mutex.release();

	return 0;
}
