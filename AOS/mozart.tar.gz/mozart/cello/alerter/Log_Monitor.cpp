#include "Log_Monitor.h"

#include <cassert>

namespace mozart {

int
Log_Monitor::svc()
{
	ACE_DEBUG((LM_DEBUG, ACE_TEXT ("(%t) Monitor starting up \n"))); //@

	Log_Message* mb;

	int i = 0;
	while(this->msg_queue()->dequeue_head(mb) != -1)
	{
		//if ( ACE_OS::strlen(mb->base()) == 0 )
		if ( mb->facility == -1 )
		{
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) Monitor shutting down\n"))); //@
			break;
		}

		// process message

		
		// delete log message after processing
		delete mb;
		++i;
		if ( i % 1000000 == 0 )
			ACE_OS::printf("d:%d\n", i);
	}

	return 0;
}

} // namespace mozart
