#include "Message_Forwarder.h"

#include <cassert>

namespace mozart {

Message_Forwarder::Message_Forwarder(const ACE_Addr& local, int protocol_family, int protocol, int reuse_addr)
:
Log_Action(),
udp_(local, protocol_family, protocol, reuse_addr)
{
	//udp_.open(local, protocol_family, protocol, reuse_addr);
}

Message_Forwarder::~Message_Forwarder()
{
	udp_.close();
}

int
Message_Forwarder::exec(Log_Message& m, void* param)
{
	// check suppress time
	if ( this->suppress_time_ && this->suppress_time_ > (m.time.sec() - this->time_.sec()) ) return -1;

	ssize_t n_size = forward(m);

	return (int) n_size;
}

} // namespace mozart
