#include "Script_Executor.h"

#include "ace/Process_Manager.h"

#include <cassert>

namespace mozart {

Script_Executor::Script_Executor()
:
Log_Action()
{
}

Script_Executor::~Script_Executor()
{
}

int
Script_Executor::exec(Log_Message& m, void* param)
{
	// check suppress time
	if ( this->suppress_time_ && this->suppress_time_ > (m.time.sec() - this->time_.sec()) ) return -1;

	// prepare for script execution
	ACE_Process_Manager* pm = ACE_Process_Manager::instance();
	ACE_Process_Options opt;
	opt.command_line(this->cmd_.c_str());

	// run command
	ACE_Process p;
	pid_t pid = pm->spawn(&p, opt); // use ACE_Process_Manager to spawn()
	//pid_t pid = p.spawn(opt); // use ACE_Process to spawn()

	//// wait process to terminated
	//ACE_Time_Value time_to_wait(10);
	//pm->wait(pid, time_to_wait);

	// update last exec time, if spawn() successfully
	if ( pid != -1 ) this->time_ = m.time;

	return (int) pid;
}

} // namespace mozart
