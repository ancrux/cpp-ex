#include "Log_Action.h"

#include <cassert>

namespace mozart {

Log_Action::Log_Action()
:
time_(ACE_Time_Value::zero),
suppress_time_(0)
{
}

Log_Action::~Log_Action()
{
}

int
Log_Action::exec(Log_Message& m, void* param)
{
	// if failed, return -1;

	return 0;
}

} // namespace mozart
