
#include "Script_Executor.h"

int test4()
{
	mozart::Script_Executor script;
	mozart::Log_Message m;
	script.cmd("D:/php5/php.exe D:/php5/send.php");
	script.cmd("D:/angus/AOS/mozart/crasher/crasher.exe");
	script.exec(m);

	ACE_OS::printf("exec() completed!\n");
	for(int i=0; i < 10; ++i)
	{
		ACE_OS::sleep(1);
		ACE_OS::printf("sec: %d\n", i);
	}

	return 0;
}

int test()
{
	//ACE_OS::printf("%d\n", sizeof(ACE_Time_Value));

	ACE_Time_Value t1 = ACE_OS::gettimeofday();
	for(int i = 0; i < 1000000; ++i)
	{
		//ACE_Time_Value tv = ACE_OS::gettimeofday();
		//time_t tt = ACE_OS::time();

		//ACE_Message_Block* mb = new ACE_Message_Block(128);
		
		//char* cstr = new char[40];
		
		//std::string* str = new std::string;
		//str->reserve(128);
		//delete str;
		
		mozart::Log_Message* m = new mozart::Log_Message();
		m->msg.reserve(128);
		delete m;

		//ACE_Message_Block* mb;// = recycler.get_mb();
		////if ( mb == 0 ) 
		//	mb = new ACE_Message_Block(10);
		//recycler.msg_queue()->enqueue_tail(mb);

		//ACE_GUARD_RETURN(ACE_Thread_Mutex, ace_mon, mtx, -1);
		//ACE_GUARD(ACE_Thread_Mutex, ace_mon, mtx);

		//q.enqueue(0);
	}
	ACE_Time_Value t2 = ACE_OS::gettimeofday();

	ACE_OS::printf("elaspe: %d\n", t2.msec() - t1.msec());

	getchar();

	return 0;
}

int test2()
{
	///*
	// udp log server
	ACE_INET_Addr local_addr(16800);
	ACE_INET_Addr remote_addr;
	ACE_SOCK_Dgram udp(local_addr);

	static const int BUFSIZE = 4096;
	char buf[BUFSIZE];

	ssize_t n_recv = 0;
	do
	{
		n_recv = udp.recv(buf, BUFSIZE, remote_addr);
		::printf("%s\n", buf);
	}
	while( n_recv > 0 );

	udp.close();
	//*/

	return 0;
}

int test3()
{
	using namespace mozart;
	Log_Store store(".", "abc", "log",
		Log_Store::Rotate::DAY,
		2,
		(ACE_UINT64) 10 * 1000 * 1000 * 1000,
		(ACE_UINT64) 3 * 1000 * 1000 * 1000);
	std::string msg("123456789");
	msg.append(490, '_');
	msg.append(1, '\n');

	for(int i = 0; i < 80000000; ++i)
	{
		ACE_OS::itoa(i+1, &msg[0], 10);

		Log_Message* m = new mozart::Log_Message;
		if ( i % 1000000 == 0 )
			ACE_OS::printf("c:%d\n", i);

		m->msg.assign(msg);
		store.log(m->msg); delete m;

		//worker.msg_queue()->enqueue_tail(m);
		//store.log(m->msg); monitor.msg_queue()->enqueue_tail(m);
	}

	return 0;
}

// main.h
