#include "ace/OS.h"
#include "ace/Get_Opt.h"
#include "ace/Configuration_Import_Export.h"
#include "ace/Log_Msg.h"
#include "ace/INET_Addr.h"
#include "ace/SOCK_Dgram.h"

#include <iostream>
using namespace std;

#include "Log_Store_Manager.h"
#include "Log_Message.h"
#include "Log_Worker.h"
#include "Log_Monitor.h"
#include "Log_Recycler.h"

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	// get console parameters
	ACE_Get_Opt cmd(argc, argv, ACE_TEXT(""));

	// get configuration filename
	std::string cfg_file;
	cfg_file = ACE::basename(cmd.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR);
	cfg_file = ACE::dirname(cfg_file.c_str(), '.');
	cfg_file += ".ini";
	cfg_file.insert(0, 1, ACE_DIRECTORY_SEPARATOR_CHAR);
	cfg_file.insert(0, 1, '.');
	ACE_OS::printf("cfg_file:%s\n", cfg_file.c_str());

	// create log store here
	mozart::Log_Store_Manager stores;
	stores.import_ini(cfg_file.c_str()); //stores.create(15, ".", "mgr");
	
	// start recycler
	mozart::Log_Monitor recycler;
	recycler.activate();

	//// start worker
	//mozart::Log_Worker worker;
	//worker.log_store(&store);
	//worker.log_monitor(&monitor);
	//worker.activate();
	//worker.activate(THR_NEW_LWP | THR_JOINABLE, 1); //ACE_OS::num_processors_online());

	///*
	// udp log server

	// read server config
	ACE_Configuration_Heap config;
	config.open();

	ACE_Ini_ImpExp iniIO(config);
	iniIO.import_config(cfg_file.c_str());

	ACE_Configuration_Section_Key sec;
	ACE_TString val;

	config.expand_path(config.root_section(), ACE_TEXT("UDP"), sec);
	config.get_string_value(sec, ACE_TEXT("Port"), val);

	// start udp log server
	short port = (short) ACE_OS::atoi(val.c_str());
	if ( port > 0 )
	{
		ACE_OS::printf("udp port: %d\n", port);

		ACE_INET_Addr local_addr(port);
		ACE_INET_Addr remote_addr;
		ACE_SOCK_Dgram udp(local_addr);

		static const int BUFSIZE = 4096;
		char buf[BUFSIZE];

		bool run = true;
		while(run)
		{
			ssize_t n_recv = udp.recv(buf, BUFSIZE, remote_addr);
			int pri = mozart::Log_Message::get_pri(buf, n_recv);
			if ( pri > -1 )
			{
				int fid = pri >> 3;
				if ( stores[fid] )
				{
					mozart::Log_Message* m = new mozart::Log_Message;
					m->facility = fid;
					m->severity = pri & 0x07;
					m->msg.assign(buf, n_recv);

					ACE_OS::printf("%s", m->msg.c_str());

					// write log
					stores[fid]->log(m->msg);

					// recycle log
					recycler.msg_queue()->enqueue_tail(m);
				}
			}
		}
		udp.close();
	}
	//*/

	//// stop worker
	//worker.msg_queue()->enqueue_tail(new mozart::Log_Message);
	//worker.wait();
	
	// stop recycler
	recycler.msg_queue()->enqueue_tail(new mozart::Log_Message);
	recycler.wait();

	// delete log store here
	// mozart::Log_Store_Manager stores;

	return 0;
}
