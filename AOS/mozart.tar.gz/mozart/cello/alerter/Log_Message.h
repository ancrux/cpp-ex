#ifndef _LOG_MESSAGE_H_
#define _LOG_MESSAGE_H_

#include "ace/OS.h"
#include <string>

namespace mozart {

class Log_Message
{
public:
	static int get_pri(const char* buf, size_t len);
	static int get_facility(int pri);
	static int get_severity(int pri);

public:
	enum
	{
		Emergecy = 0, // system is unusable
		Alert, // action must be taken immediately
		Critical, // critical conditions
		Error, // error conditions
		Warning, // warning conditions
		Notice, // normal but significant condition 
		Informational, // informational messages
		Debug // debug-level messages
	};

public:
	Log_Message();
	~Log_Message();

public:
	std::string msg;
	int facility;
	int severity;
	ACE_Time_Value time;
};

} // namepsace mozart

#endif // _LOG_MESSAGE_H_
