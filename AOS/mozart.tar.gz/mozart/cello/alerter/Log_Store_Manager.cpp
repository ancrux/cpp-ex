#include "Log_Store_Manager.h"

#include "ace/Configuration_Import_Export.h"
#include <set>

#include <cassert>
#include <iostream>
using namespace std;

namespace mozart {

Log_Store_Manager::Log_Store_Manager()
{
	::memset(stores_, 0, sizeof(stores_));
}

Log_Store_Manager::~Log_Store_Manager()
{
	for(int i = 0; i < MAX_STORE; ++i)
	{
		delete stores_[i];
	}
}

void
Log_Store_Manager::create(
	int idx,
	const char* dir,
	const char* prefix,
	const char* suffix,
	int rotate_time,
	size_t rotate_size,
	ACE_UINT64 store_max_size,
	ACE_UINT64 file_max_size
	)
{
	if ( idx >= 0 && idx < MAX_STORE )
	{
		delete stores_[idx];
		stores_[idx] = new mozart::Log_Store(dir, prefix, suffix, rotate_time, rotate_size, store_max_size, file_max_size);
	}
}

int
Log_Store_Manager::import_ini(const char* filename)
{
	ACE_Configuration_Heap config;
	config.open();

	ACE_Ini_ImpExp iniIO(config);
	iniIO.import_config(filename);

	// use store_paths as store identifier
	// so two stores won't conflict with each other.
	std::set< std::string > store_paths;

	// iterate through entire file (not including sub-section iteration)
	ACE_Configuration_Section_Key sec;
	sec = config.root_section();
	ACE_TString sec_name;
	for(int sec_index = 0;
		config.enumerate_sections(sec, sec_index, sec_name) == 0;
		++sec_index)
	{
		int facility = ACE_OS::atoi(sec_name.c_str());
		if ( facility < 1 || facility >= MAX_STORE || stores_[facility] ) continue;

		ACE_OS::printf("[%d]\n", facility);

		ACE_Configuration_Section_Key sub_sec;
		config.open_section(sec, sec_name.c_str(), 0, sub_sec); 
		ACE_TString value;

		std::string path, dir, prefix, suffix;
		config.get_string_value(sub_sec, ACE_TEXT("Dir"), value);
		dir = value.c_str();
		path += value.c_str();
		value.resize(0);

		config.get_string_value(sub_sec, ACE_TEXT("Prefix"), value);
		prefix = value.c_str();
		path += value.c_str();
		value.resize(0);

		config.get_string_value(sub_sec, ACE_TEXT("Suffix"), value);
		suffix = value.c_str();
		path += value.c_str();
		value.resize(0);

		if ( path.empty() || store_paths.find(path) != store_paths.end() )
		{
			// same store path found, report error here!
			continue;
		}
		store_paths.insert(path);

		config.get_string_value(sub_sec, ACE_TEXT("RotateType"), value);
		int rotate_time = Log_Store::str_to_rotate_time(value.c_str());
		value.resize(0);

		config.get_string_value(sub_sec, ACE_TEXT("RotateSize"), value);
		size_t rotate_size = (size_t) ACE_OS::atoi(value.c_str());
		value.resize(0);

		config.get_string_value(sub_sec, ACE_TEXT("StoreMaxSize"), value);
		ACE_UINT64 store_max_size = (ACE_UINT64) ACE_OS::atoi(value.c_str());
		value.resize(0);

		config.get_string_value(sub_sec, ACE_TEXT("FileMaxSize"), value);
		ACE_UINT64 file_max_size = (ACE_UINT64) ACE_OS::atoi(value.c_str());
		value.resize(0);

		ACE_OS::printf("dir: %s, prefix: %s, suffix: %s\n", dir.c_str(), prefix.c_str(), suffix.c_str());
		ACE_OS::printf("rotate: %d, size: %d, store_max: %d, file_max: %d\n", rotate_time, rotate_size, store_max_size, file_max_size);

		this->create(facility, dir.c_str(), prefix.c_str(), suffix.c_str(), rotate_time, rotate_size, store_max_size, file_max_size);
	}

	return 0;
}

int
Log_Store_Manager::import_xml(const char* filename)
{
	return -1;
}

} // namespace mozart
