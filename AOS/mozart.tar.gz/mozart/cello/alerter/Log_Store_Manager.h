#ifndef _LOG_STORE_MANAGER_H_
#define _LOG_STORE_MANAGER_H_

#include "Log_Store.h"

namespace mozart {

class Log_Store_Manager
{
public:
	static const int MAX_STORE = 128;

public:
	Log_Store_Manager();
	~Log_Store_Manager();

public:
	void create(
		int idx,
		const char* dir,
		const char* prefix = "",
		const char* suffix = "log",
		int rotate_time = Log_Store::Rotate::NONE,
		size_t rotate_size = 0,
		ACE_UINT64 store_max_size = 0,
		ACE_UINT64 file_max_size = 0
		);
	Log_Store* operator[](int idx)
	{
		return stores_[idx];
	};

public:
	int import_ini(const char* filename);
	int import_xml(const char* filename);

protected:
	Log_Store* stores_[MAX_STORE];
};

} // namepsace mozart

#endif // _LOG_STORE_MANAGER_H_
