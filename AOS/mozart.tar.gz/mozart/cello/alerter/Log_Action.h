#ifndef _LOG_ACTION_H_
#define _LOG_ACTION_H_

#include "ace/OS.h"

#include "Log_Message.h"

#include <iostream>
using namespace std;

namespace mozart {

class Log_Action
{
public:
	Log_Action();
	virtual ~Log_Action();

public:
	virtual int exec(Log_Message& m, void* param = 0);
	inline void suppress_time(int suppress_time)
	{
		suppress_time_ = suppress_time;
	};
	inline int suppress_time()
	{
		return suppress_time_;
	};

protected:
	ACE_Time_Value time_; // last exec time
	int suppress_time_; // suppress time in seconds, 0 for no suppression
	//? int count_; // count since last exec
	//? int suppress_count_;
};

} // namepsace mozart

#endif // _LOG_ACTION_H_
