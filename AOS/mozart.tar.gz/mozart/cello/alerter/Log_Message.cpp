#include "Log_Message.h"

#include <cassert>

namespace mozart {

Log_Message::Log_Message()
:
facility(-1),
severity(Log_Message::Debug)
{
}

Log_Message::~Log_Message()
{
}

int
Log_Message::get_pri(const char* buf, size_t len)
{
	ACE_ASSERT(buf); //::assert(buf);

	if ( len > 2 && buf[0] == '<' )
	{
		const char* ptr = buf + 1;
		const char* ptr_end = buf + ((len > 4)? 4 : len);

		int pri = 0;
		while( ptr < ptr_end )
		{
			if ( *ptr < '0' || *ptr > '9' ) break;
			pri *= 10;
			pri += int(*ptr - '0');
			if ( pri > 999 ) break;

			++ptr;
		}

		if ( *ptr == '>' && ptr > buf + 1 ) return pri;
	}
	
	return -1;
}

int
Log_Message::get_facility(int pri)
{
	return pri >> 3; 
}

int
Log_Message::get_severity(int pri)
{
	return pri & 0x07;
}

} // namespace mozart
