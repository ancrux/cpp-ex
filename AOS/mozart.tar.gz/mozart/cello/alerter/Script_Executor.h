#ifndef _SCRIPT_EXECUTOR_H_
#define _SCRIPT_EXECUTOR_H_

#include "Log_Action.h"

#include <iostream>
using namespace std;

namespace mozart {

class Script_Executor : public Log_Action
{
public:
	Script_Executor();
	virtual ~Script_Executor();

public:
	virtual int exec(Log_Message& m, void* param = 0);
	inline void cmd(const char* cmd)
	{
		cmd_.assign(cmd);
	};
	inline const char* cmd()
	{
		return cmd_.c_str();
	}

protected:
	std::string cmd_;
};

} // namepsace mozart

#endif // _SCRIPT_EXECUTOR_H_
