#ifndef _LOG_MONITOR_H_
#define _LOG_MONITOR_H_

#include "ace/OS.h"
#include "ace/Task_Ex_T.h"

#include "Log_Message.h"

#include <iostream>
using namespace std;

namespace mozart {

class Log_Monitor : public ACE_Task_Ex< ACE_MT_SYNCH, Log_Message >
{
public:
	virtual int svc();
};

} // namepsace mozart

#endif // _LOG_MONITOR_H_
