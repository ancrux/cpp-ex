#include "Log_Recycler.h"

#include <cassert>

namespace mozart {

int
Log_Recycler::svc()
{
	ACE_DEBUG((LM_DEBUG, ACE_TEXT ("(%t) Recycler starting up \n"))); //@

	Log_Message* mb;
	while(this->msg_queue()->dequeue_head(mb) != -1)
	{
		//if ( ACE_OS::strlen(mb->base()) == 0 )
		if ( mb->facility == -1 )
		{
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) Recycler shutting down\n"))); //@
			break;
		}
		// delete log message after processing
		delete mb;
	}

	return 0;
}

} // namespace mozart
