#ifndef _LOG_RECYCLER_H_
#define _LOG_RECYCLER_H_

#include "ace/OS.h"
#include "ace/Task_Ex_T.h"

#include "Log_Message.h"

#include <iostream>
using namespace std;

namespace mozart {

class Log_Recycler : public ACE_Task_Ex< ACE_MT_SYNCH, Log_Message >
{
public:
	virtual int svc();
};

} // namepsace mozart

#endif // _LOG_RECYCLER_H_
