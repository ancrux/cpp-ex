#ifndef _MESSAGE_FORWARDER_H_
#define _MESSAGE_FORWARDER_H_

#include "Log_Action.h"

#include "ace/INET_Addr.h"
#include "ace/SOCK_Dgram.h"

#include <iostream>
using namespace std;

namespace mozart {

class Message_Forwarder : public Log_Action
{
public:
	Message_Forwarder(const ACE_Addr& local = ACE_Addr::sap_any, int protocol_family = ACE_PROTOCOL_FAMILY_INET, int protocol = 0, int reuse_addr = 0);
	virtual ~Message_Forwarder();

	inline void target(const ACE_INET_Addr& addr)
	{
		target_ = addr;
	};
	inline ssize_t forward(Log_Message& m) 
	{
		return udp_.send(m.msg.c_str(), m.msg.size(), target_);
	};
	

public:
	virtual int exec(Log_Message& m, void* param = 0);

protected:
	ACE_SOCK_Dgram udp_;
	ACE_INET_Addr target_;
};

} // namepsace mozart

#endif // _MESSAGE_FORWARDER_H_
