#define __SVC_VER__ "0.1.0"

int run_logger_service(int argc, ACE_TCHAR* argv[])
{
	int rc = 0;

	Service_Process svc(argc, argv, __SVC_VER__, __DATE__ " " __TIME__);
	ACE_OS::printf("service: %s\n", svc.name());

	// start local_acceptor
	aos::ipc::Local_Acceptor acceptor;
	ACE_Time_Value timeout(1);

	if ( acceptor.open(svc.name()) == -1 )
	{
		ACE_OS::printf("open() failed: %s\n", ACE_OS::strerror(ACE_OS::last_error())); // ACE_OS::perror("open()");
		return -1;
	}

	//+ start service
	Syslog_Worker syslog_worker;
	UDP_Receiver udp_receiver(syslog_worker);

	syslog_worker.start();
	udp_receiver.start();

	aos::Multi_String params;
	int stop = 0;
	while(!stop)
	{
		aos::ipc::Local_Stream stream;
		if ( acceptor.accept(stream) == -1 )
		{
			//ACE_OS::printf("accept() == -1\n"); //@
			continue;
		}

		//ACE_OS::printf("client accepted!\n"); //@

		ssize_t n_recv = -1;
		ssize_t n_send = -1;

		n_recv = stream.recv_cstr();
		//ACE_OS::printf("command: %s\n", stream.buf().c_str()); //@

		params.clear();
		aos::Tokenizer toker(stream.buf().c_str(), stream.buf().size());
		toker.set_separator("\t");
		while( toker.next() > aos::Tokenizer::End )
			params.push_back(toker.token(), toker.size());

		if ( (n_send = svc.handle_predefined_command(stream)) > 0 )
		{
			// do nothing
		}
		// read "stop" command, stop service.
		else if ( ACE_OS::strcasecmp(stream.buf().c_str(), "stop") == 0 )
		{
			char buf[256];
			int n = ACE_OS::snprintf(buf, 255, "+%d\t[%s]\tservice is stopping...", svc.pid(), svc.name());
			n_send = stream.send_cstr(buf, n+1); // include '\0'
			
			stop = 1;
			//+ send stop signal, and wait for service to stop
			udp_receiver.stop();
			syslog_worker.stop();
		}
		else
		{
			n_send = svc.handle_unknown_command(stream);
		}
		stream.close();
	}
	acceptor.close();

	return rc;
}

