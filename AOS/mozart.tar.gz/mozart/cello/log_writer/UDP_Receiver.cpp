#include "UDP_Receiver.h"

#include "ace/INET_Addr.h"
#include "ace/SOCK_Dgram.h"

#include <string>

//namespace aos {

UDP_Receiver::UDP_Receiver(Syslog_Worker& syslog_worker)
:
stop_(0),
syslog_worker_(syslog_worker)
{
}

UDP_Receiver::~UDP_Receiver()
{
}

void
UDP_Receiver::start()
{
	stop_ = 0;
	this->activate(THR_NEW_LWP | THR_JOINABLE, 1);
}

void
UDP_Receiver::stop()
{
	stop_ = 1;
	this->wait();
}

int
UDP_Receiver::svc()
{
	ACE_INET_Addr local_addr(16800);
	ACE_INET_Addr remote_addr;
	ACE_SOCK_Dgram udp(local_addr);
	ACE_Time_Value timeout; timeout.set(0.01);

	static const int BUFSIZE = 4096;
	char buf[BUFSIZE];

	ssize_t n_recv = -1;
	do
	{
		n_recv = udp.recv(buf, BUFSIZE, remote_addr, 0, &timeout);
		if ( n_recv > 0 )
		{
			std::string* str = new (std::nothrow) std::string(buf, n_recv);
			if ( str ) syslog_worker_.msg_queue()->enqueue_tail(str);
		}
	}
	while( !stop_.value() );

	udp.close();

	return 0;
}

//} // namepsace aos
