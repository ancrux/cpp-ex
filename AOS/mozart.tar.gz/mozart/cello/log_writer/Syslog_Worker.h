#ifndef _SYSLOG_WORKER_H_
#define _SYSLOG_WORKER_H_

#include "ace/OS.h"
#include "ace/Atomic_Op.h"
#include "ace/Task_Ex_T.h"

#include "aos/Logger.h"
#include <vector>

//namespace aos {

class Syslog_Worker : public ACE_Task_Ex<ACE_MT_SYNCH, std::string>
{
public:
	typedef std::vector< aos::Logger * > LOGGERS;

public:
	static const int MAX_FACILITY = 128;

public:
	Syslog_Worker();
	~Syslog_Worker();

public:
	void start();
	void stop();

public:
	virtual int svc();

protected:
	ACE_Atomic_Op<ACE_Thread_Mutex, long> stop_;
	ACE_Thread_Mutex locks_[MAX_FACILITY];
	aos::Logger* loggers_[MAX_FACILITY];
};

//} // namepsace aos

#endif // _SYSLOG_WORKER_H_