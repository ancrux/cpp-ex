#include "Syslog_Worker.h"

//namespace aos {

Syslog_Worker::Syslog_Worker()
:
stop_(0)
{
	loggers_[0] = new aos::Logger(".", "sys");
}

Syslog_Worker::~Syslog_Worker()
{
	delete loggers_[0];
}

void
Syslog_Worker::start()
{
	stop_ = 0;
	this->msg_queue()->high_water_mark(-1);
	this->activate(THR_NEW_LWP | THR_JOINABLE, 1);
}

void
Syslog_Worker::stop()
{
	this->msg_queue()->enqueue_tail(new std::string());
	this->wait();
}

int
Syslog_Worker::svc()
{
	ACE_DEBUG((LM_DEBUG, ACE_TEXT ("(%t) Worker starting up \n"))); //@

	std::string* mb;

	while(this->msg_queue()->dequeue_head(mb) != -1)
	{
		if ( mb->size() == 0 )
		{
			delete mb;
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) Worker shutting down\n"))); //@
			break;
		}

		int i = 0;
		// write to loggers
		if ( i < MAX_FACILITY && loggers_[i] )
		{
			loggers_[i]->log(*mb, 0, 0); // don't add time
			::printf("%s", mb->c_str());
		}
		delete mb;
	}

	return 0;
}

//} // namepsace aos
