#ifndef _UDP_RECEIVER_H_
#define _UDP_RECEIVER_H_

#include "ace/OS.h"
#include "ace/Atomic_Op.h"
#include "ace/Task_Ex_T.h"

#include "Syslog_Worker.h"

//namespace aos {

class UDP_Receiver : public ACE_Task_Base
{
public:
	UDP_Receiver(Syslog_Worker& syslog_worker);
	~UDP_Receiver();

public:
	void start();
	void stop();

public:
	virtual int svc();

protected:
	ACE_Atomic_Op<ACE_Thread_Mutex, long> stop_;
	Syslog_Worker& syslog_worker_;
};

//} // namepsace aos

#endif // _UDP_RECEIVER_H_