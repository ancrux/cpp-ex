#include "ace/OS.h"
#include "ace/Log_Msg.h"
#include "ace/INET_Addr.h"
#include "ace/SOCK_Dgram.h"

#include <iostream>
using namespace std;

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	//return test();

	// UDP client
	ACE_INET_Addr remote_addr(16800, ACE_LOCALHOST);
	ACE_SOCK_Dgram udp(ACE_Addr::sap_any);

	const char* msg_fmt = "<%d> msg_id: %d\n";
	static const int MSG_MAX_SIZE = 1024;
	char msg[MSG_MAX_SIZE+1];
	for(int i=0; i < 1000; ++i)
	{
		ACE_OS::snprintf(msg, MSG_MAX_SIZE, msg_fmt, 124, i);
		ssize_t sent = udp.send(msg,
			ACE_OS::strlen(msg),
			remote_addr);

		if ( sent == -1 )
		{
			ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("%p\n"), ACE_TEXT("send")), -1);
		}
	}
	udp.close ();

	return 0;
}