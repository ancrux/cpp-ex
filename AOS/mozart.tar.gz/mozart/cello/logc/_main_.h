
int test()
{
	ACE_OS::printf("Hello!\n");

	return 0;
}

// main.h