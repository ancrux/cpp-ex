
int test()
{
	printf("Hello! C++\n");
	//ACE_OS::printf("Hello! ACE\n");

	return 0;
}

// main.h
