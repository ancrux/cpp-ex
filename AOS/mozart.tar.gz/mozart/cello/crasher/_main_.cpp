//#include "ace/OS.h"

#include <iostream>
using namespace std;

#include "_main_.h"

//int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
int main(int argc, char* argv[])
{
	//return test();
	test();

	std::string* pstr = new std::string();
	pstr = 0;
	pstr->resize(1024);

	return 0;
}
