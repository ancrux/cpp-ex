#include "Journal_Worker.h"

#include "ace/Process_Manager.h"

#include <cassert>

namespace mozart {

Journal_Worker::Journal_Worker(int index)
{
	if ( index < 0 || index >= Journal_Worker::MAX_INDEX )
		index_ = 0;
	else
		index_ = index;
}

Journal_Worker::~Journal_Worker()
{
}

int
Journal_Worker::svc()
{
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) Worker starting up \n"))); //@

	char cmd[PATH_MAX+1];
	ACE_OS::snprintf(cmd, PATH_MAX, "d:/php5/php d:/php5/journal_imap4.php %d", this->index_);

#ifndef WIN32 // not ACE_WIN32 (Linux)
	ACE_OS::snprintf(cmd, PATH_MAX, "/usr/bin/php /usr/local/mozart/scripts/journal_imap.php %d", this->index_);
#endif

	// prepare for script execution
	ACE_Process_Manager* pm = ACE_Process_Manager::instance();
	ACE_Process_Options opt;
	opt.command_line(cmd);

	// run command
	ACE_Process p;

	int count = 0;
	while(true)
	{
		pid_t pid = pm->spawn(&p, opt); // use ACE_Process_Manager to spawn()
		if ( pid != -1 )
			pm->wait(pid);

		++count;
		ACE_OS::printf("index: %d, count: %d\n", index_, count);
		//ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) Worker restart... \n"))); //@
	}

	ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) Worker shutting down \n"))); //@

	return 0;
}

} // namespace mozart
