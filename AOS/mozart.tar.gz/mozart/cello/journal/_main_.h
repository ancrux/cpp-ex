
int test()
{
	ACE_OS::printf("Hello!\n");

	return 0;
}

int 
disable_signal(int sigmin, int sigmax)
{
#ifndef ACE_WIN32

	sigset_t signal_set;
	if (sigemptyset (&signal_set) == - 1)
		ACE_ERROR ((LM_ERROR,
		ACE_TEXT ("Error: (%P|%t):%p\n"),
		ACE_TEXT ("sigemptyset failed")));

	for (int i = sigmin; i <= sigmax; i++)
		sigaddset (&signal_set, i);

	//  Put the <signal_set>.
	if (ACE_OS::pthread_sigmask (SIG_BLOCK, &signal_set, 0) != 0)
		ACE_ERROR ((LM_ERROR,
		ACE_TEXT ("Error: (%P|%t):%p\n"),
		ACE_TEXT ("pthread_sigmask failed")));
#else
	ACE_UNUSED_ARG (sigmin);
	ACE_UNUSED_ARG (sigmax);
#endif /* ACE_WIN32 */

	return 1;
}

// main.h
