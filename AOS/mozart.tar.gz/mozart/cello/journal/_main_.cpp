#include "ace/OS.h"
#include "ace/Task.h"
#include "ace/Process_Mutex.h"
//#include "ace/Process_Manager.h"

#include <iostream>
using namespace std;

#include "Journal_Worker.h"

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	//return test();
	
	static const int MAX_INDEX = 8;
	int idx = 1;
	if ( argc > 1 ) idx = ACE_OS::atoi(argv[1]);
	if ( idx < 1 || idx > MAX_INDEX )
	{
		ACE_OS::printf("Invalid index: %d\n", idx);
		return -1;
	}

	// make sure only one instance
	static const ACE_TCHAR* uniqueNameFmt = "theOnlyJournal-%d";
	static ACE_TCHAR uniqueName[PATH_MAX+1];
	ACE_OS::snprintf(uniqueName, PATH_MAX, uniqueNameFmt, idx);
	ACE_Process_Mutex mutex(uniqueName);
	if ( mutex.tryacquire() != 0 )
	{
		ACE_OS::printf("[%s %d] is already running...\n", ACE::basename(argv[0]), idx);
		return 1;
	}

	//disable_signal(ACE_SIGRTMIN, ACE_SIGRTMAX);
	//disable_signal(SIGPIPE, SIGPIPE);
	//disable_signal(SIGIO, SIGIO);
	//disable_signal(SIGKILL, SIGKILL);

	///*
	char cmd[PATH_MAX+1];
	ACE_OS::snprintf(cmd, PATH_MAX, "d:/php5/php d:/php5/journal_imap4.php %d", idx);

#ifndef WIN32 // not ACE_WIN32 (Linux)
	ACE_OS::snprintf(cmd, PATH_MAX, "/usr/bin/php /usr/local/mozart/scripts/journal_imap.php %d", idx);
#endif

	while(true)
	{
		//ACE_Process p;
		//ACE_Process_Options opt;
		//opt.command_line(cmd);

		//pid_t pid = p.spawn(opt);
		//if ( pid != ACE_INVALID_PID )
		//	pid = p.wait();

		ACE_OS::system(cmd);
		ACE_OS::sleep(10);
	}
	//*/

	/*
	static const int N_JOURNAL = 1;
	ACE_Task_Base* worker[N_JOURNAL+1];

	// startup journal workers
	for(int i = 1; i <= N_JOURNAL; ++i)
	{
		worker[i] = new mozart::Journal_Worker(i);
		worker[i]->activate();
	}

	//// second counter
	//for(int i = 0; i < 1000; ++i)
	//{
	//	ACE_OS::printf("sec: %d\n", i);
	//	ACE_OS::sleep(1);
	//}

	// shut down journal workers
	for(int i = 1; i <= N_JOURNAL; ++i)
	{
		worker[i]->wait();
	}
	//*/

	mutex.release();

	return 0;
}
