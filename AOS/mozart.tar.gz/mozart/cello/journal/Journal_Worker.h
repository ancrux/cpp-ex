#ifndef _JOURNAL_WORKER_H_
#define _JOURNAL_WORKER_H_

#include "ace/OS.h"
#include "ace/Task.h"

#include <iostream>
using namespace std;

namespace mozart {

class Journal_Worker : public ACE_Task_Base
{
public:
	static const int MAX_INDEX = 12;

public:
	Journal_Worker(int index = 0);
	virtual ~Journal_Worker();

public:
	virtual int svc();

protected:
	int index_;
};

} // namepsace mozart

#endif // _JOURNAL_WORKER_H_
