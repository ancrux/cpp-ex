#ifndef _LOG_MATCHER_H_
#define _LOG_MATCHER_H_

#include "I_Matcher.h"
#include "Log_Parser.h"

#include <vector>

namespace mozart {

class Log_Matcher : public I_Matcher
{
public:
	Log_Matcher();
	virtual ~Log_Matcher();

public:
	virtual int match(const char* cstr, size_t len) = 0;

public:
	size_t matcher_count() const { return matchers_.size(); };
	I_Matcher* get_matcher(size_t idx) const { return (idx<matcher_count())?matchers_[idx]:0; };
	I_Matcher* detach_matcher(size_t idx)
	{
		I_Matcher* matcher = get_matcher(idx);
		if ( matcher )
			matchers_[idx] = 0;

		return matcher;
	}
	void set_matcher(size_t idx, I_Matcher* matcher);
	void clear_matchers();

public:
	void reset() { parser_.reset(); clear_matchers(); };

protected:
	Log_Parser parser_;
	std::vector< I_Matcher* > matchers_;
};

class BLK_Log_Matcher : public Log_Matcher
{
public:
	virtual int match(const char* cstr, size_t len)
	{
		int matched = I_Matcher::MATCHED;
		parser_.assign(cstr, len);

		static const size_t TOKEN_MAX = 2048;
		char token[TOKEN_MAX+1];

		aos::bcstr bstr;
		for(size_t i = 0; i < matcher_count(); ++i)
		{
			// no such item, return false
			if ( parser_.is_end() )
			{
				matched = I_Matcher::NOT_MATCHED;
				break;
			}
			
			if ( i == 0 )
				parser_.separator(']');
			else
				parser_.separator(',');

			// get next item
			bstr = parser_.next(0); // not included separator
			if ( bstr.len > TOKEN_MAX )
			{
				matched = I_Matcher::NOT_MATCHED;
				break;
			}

			I_Matcher* matcher = get_matcher(i);
			if ( matcher )
			{
				if ( i == 6 )
				{
					if ( bstr.len && bstr.buf[0] >= 'A' && bstr.buf[0] <= 'Z' )
					{
					}
					else
					{
						--i;
						continue;
					}
				}

				ACE_OS::memcpy(token, bstr.buf, bstr.len); token[bstr.len] = '\0'; //@
				matched = matcher->match(token, bstr.len);
				if ( matched != I_Matcher::MATCHED )
					break;
			}
		}
		
		return matched;
	};
};

class DLV_Log_Matcher : public Log_Matcher
{
public:
	virtual int match(const char* cstr, size_t len)
	{
		int matched = I_Matcher::MATCHED;
		parser_.assign(cstr, len);

		static const size_t TOKEN_MAX = 2048;
		char token[TOKEN_MAX+1];

		aos::bcstr bstr;
		for(size_t i = 0; i < matcher_count(); ++i)
		{
			// no such item, return false
			if ( parser_.is_end() )
			{
				matched = I_Matcher::NOT_MATCHED;
				break;
			}
			// get next item
			bstr = parser_.next(0); // not included separator
			if ( bstr.len > TOKEN_MAX )
			{
				matched = I_Matcher::NOT_MATCHED;
				break;
			}

			I_Matcher* matcher = get_matcher(i);
			if ( matcher )
			{
				if ( i == 8 )
				{
					std::string reason;
					reason.assign(token);
					reason += ' ';
					reason.append(bstr.buf, bstr.len);
					matched = matcher->match(reason.c_str(), reason.size());
					if ( matched != I_Matcher::MATCHED )
						break;
				}
				else
				{
					ACE_OS::memcpy(token, bstr.buf, bstr.len); token[bstr.len] = '\0'; //@
					matched = matcher->match(token, bstr.len);
					if ( matched != I_Matcher::MATCHED )
						break;
				}
			}
			if ( i == 7 )
				ACE_OS::memcpy(token, bstr.buf, bstr.len); token[bstr.len] = '\0'; //@
		}
		
		return matched;
	};
};

} // namespace mozart

#endif // _LOG_MATCHER_H_

