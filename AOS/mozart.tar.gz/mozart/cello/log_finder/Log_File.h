#ifndef _LOG_FILE_H_
#define _LOG_FILE_H_

#include "ace/SSL/SSL_SOCK_Stream.h" //#include "ace/SOCK_Stream.h"

#include "Log_Matcher.h"

namespace mozart {

class Log_File
{
public:
	Log_File();
	Log_File(const char* filename);
	virtual ~Log_File();

public:
	int open(const char* filename, ACE_SOCK_Stream* stream = 0);
	int close();
	int n_match() const { return n_match_; };
	void n_match(int n_match) { n_match_ = n_match; };
	int n_record() const { return n_record_; };
	void n_record(int n_record) { n_record_ = n_record; };

public:
	virtual int search(Log_Matcher& matcher, int* n_total = 0, int max_match = 0, int max_record = 0) = 0;
	virtual void on_matched(const char* log, int n_start_match, int n_start_record, int max_match = 0, int max_record = 0) = 0;

protected:
	ACE_HANDLE fh_;
	time_t date_; // YYYY-mm-dd
	int n_match_;
	int n_record_;

protected:
	ACE_SOCK_Stream* stream_;
};

class BLK_Log_File : public Log_File
{
public:
	virtual int search(Log_Matcher& matcher, int* n_total = 0, int max_match = 0, int max_record = 0);
	virtual void on_matched(const char* log, int n_start_match, int n_start_record, int max_match, int max_record);
};

class DLV_Log_File : public Log_File
{
public:
	virtual int search(Log_Matcher& matcher, int* n_total = 0, int max_match = 0, int max_record = 0);
	virtual void on_matched(const char* log, int n_start_match, int n_start_record, int max_match, int max_record);
};

} // namespace mozart

#endif // _LOG_FILE_H_

