#include "Log_Parser.h"

namespace mozart {

const char Log_Parser::DEFAULT_SEPARATOR_CHAR = ',';

Log_Parser::Log_Parser(char sep)
{
	assign(0, 0, sep);
	//ACE_OS::memset(this, 0, sizeof(*this));
}

Log_Parser::Log_Parser(const char* log, size_t len, char sep)
{
	assign(log, len, sep);
}

Log_Parser::~Log_Parser()
{
}

void
Log_Parser::assign(const char* log, size_t len, char sep)
{
	beg_ = log;
	end_ = log+len;
	cur_ = beg_;
	sep_ = sep;
	count_ = -1;
}

aos::bcstr
Log_Parser::next(int keep_separator)
{
	aos::bcstr bstr;
	bstr.buf = cur_;

	register const char* ptr = cur_;

	while( ptr < end_ )
	{
		if ( *ptr == sep_ )
		{
			bstr.len = ptr-bstr.buf;
			if ( keep_separator )
				bstr.len += 1;
			++count_;

			cur_ = ptr+1;
			return bstr;
		}
		++ptr;
	}

	bstr.len = ptr-bstr.buf;
	++count_;

	cur_ = ptr;
	return bstr;
}

} // namespace mozart
