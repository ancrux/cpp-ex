
using namespace mozart;

#define __SVC_VER__ "0.1 (alpha)"

int run_service_test(int argc, ACE_TCHAR* argv[])
{
	Service_Process svc(argc, argv, __SVC_VER__, __DATE__ " " __TIME__);
	ACE_OS::printf("svc_name: %s\n", svc.name());

	unsigned short server_port = 0;

	ACE_Get_Opt cmd(argc, argv);
	cmd.long_option(ACE_TEXT("port"), 'p', ACE_Get_Opt::ARG_REQUIRED);
	int ch;
	while( (ch = cmd()) != EOF )
	{
		switch(ch)
		{
		case 'p':
			server_port = ACE_OS::atoi(cmd.opt_arg());	
			break;
		}
	}

	// start local_acceptor
	aos::ipc::Local_Acceptor acceptor;
	ACE_Time_Value timeout(1);
	if ( acceptor.open(svc.name()) == -1 )
	{
		ACE_OS::printf("open() failed: %s\n", ACE_OS::strerror(ACE_OS::last_error())); // ACE_OS::perror("open()");
		return -1;
	}
	//*/

	//// service starts here
	//Service service;
	//service.activate(THR_NEW_LWP | THR_DETACHED, 1, 0); //! must activate detached for waiting http_server's detached threads

	// start http server
	HTTP_Server server;

	// SSL Context must be created before ACE_SSL_SOCK_Acceptor to take effect
	ACE_SSL_Context* context = ACE_SSL_Context::instance();
	context->set_mode(ACE_SSL_Context::SSLv23);
	context->certificate("dummy.pem", SSL_FILETYPE_PEM);
	context->private_key("key.pem", SSL_FILETYPE_PEM);

	int port = 80;
#if USE_SSL == 1
	port = 443;
#else
	port = 80;
#endif
	port = (server_port > 0 && server_port < 65535)?server_port:18000;
  ACE_INET_Addr server_addr(port);
	//ACE_INET_Addr server_addr(port, ACE_LOCALHOST);

	if ( server.open(server_addr) != 0 )
	{
		ACE_OS::printf("server_.open() failed: %s\n", ACE_OS::strerror(ACE_OS::last_error()));
		server.close();
		
		return -1;
	}

	server.start();

	///*
	// service started completedly, enters IPC loop
	int stop = 0;
	while(!stop)
	{
		aos::ipc::Local_Stream stream;
		if ( acceptor.accept(stream) == -1 )
		{
			ACE_OS::printf("accept() == -1\n");
			continue;
		}

		//ACE_OS::printf("client accepted!\n"); //@
		ssize_t n_recv = -1;
		ssize_t n_send = -1;

		int stop = 0;

		n_recv = stream.recv_cstr();
		//ACE_OS::printf("command: %s\n", stream.buf().c_str()); //@

		if ( (n_send = svc.handle_predefined_command(stream)) > 0 )
		{
			// do nothing
		}
		// read "stop" command, stop service.
		else if ( ACE_OS::strcasecmp(stream.buf().c_str(), "stop") == 0 )
		{
			char buf[256];
			int n = ACE_OS::snprintf(buf, 255, "+%d\t[%s]\tservice is stopping...", svc.pid(), svc.name());
			n_send = stream.send_cstr(buf, n+1); // include '\0'
			
			stop = 1;

			server.stop();
			ACE_OS::printf("service stopped!\n");

			break;
		}
		else if ( ACE_OS::strcasecmp(stream.buf().c_str(), "status") == 0 )
		{
			char buf[256];
			int n_conn = server.n_conn();
			int n = 0;
			if ( n_conn < 0 )
				n = ACE_OS::snprintf(buf, 255, "%d\tlistener is not up!", n_conn);
			else
				n = ACE_OS::snprintf(buf, 255, "+%d\tconnection(s).", n_conn);
			n_send = stream.send_cstr(buf, n+1); // include '\0'
		}
		else if ( ACE_OS::strcasecmp(stream.buf().c_str(), "port") == 0 )
		{
			char buf[256];
			int n = 0;
			n = ACE_OS::snprintf(buf, 255, "+%d\t[%s]", port, svc.name());
			n_send = stream.send_cstr(buf, n+1); // include '\0'
		}
		else
		{
			n_send = svc.handle_unknown_command(stream);
		}
		stream.close();
	}
	acceptor.close();
	//*/

	ACE_OS::printf("service terminated!\n");

	//ACE_OS::printf("sleep(3)\n");
	//ACE_OS::sleep(3);

	return 0;
}

int run_http_test(int argc, ACE_TCHAR* argv[])
{
	// SSL Context must be created before ACE_SSL_SOCK_Acceptor to take effect
	ACE_SSL_Context* context = ACE_SSL_Context::instance();
	context->set_mode(ACE_SSL_Context::SSLv23);
	context->certificate("dummy.pem", SSL_FILETYPE_PEM);
	context->private_key("key.pem", SSL_FILETYPE_PEM);

	int port = 80;
#if USE_SSL == 1
	port = 443;
#else
	port = 80;
#endif
	ACE_INET_Addr server_addr(port, ACE_LOCALHOST); //ACE_INET_Addr server_addr(port);

	HTTP_Server server;
	if ( server.open(server_addr) == 0 )
	{
		///*
		server.start();

		ACE_OS::printf("press any key to stop...\n");
		getchar();
		server.stop();

		server.thr_mgr()->wait(); // don't use http.wait();
		//*/

		/*
		while(1)
		{
			server.start();

			ACE_OS::sleep(5);
			ACE_OS::printf("disable()...\n");
			server.disable();

			server.thr_mgr()->wait(); // don't use http.wait();
			//ACE_OS::sleep(5);
		}
		//*/
	}
	ACE_OS::printf("server terminated!\n");

	return 0;
}

int run_filter_test(int argc, ACE_TCHAR* argv[])
{
	std::string filter = 
		"act='0';"
		//"time_min='1238428800'; time_max='1249292800';"
		"sndr_ip='124.130.59.73';" \
		//"size_min='9750000';size_max='0';" 
		;

	Finder_Worker finder;
	finder.filter(filter);
	//finder.activate(THR_NEW_LWP | THR_JOINABLE, ACE_OS::num_processors_online(), 0);
	//finder.activate(THR_NEW_LWP | THR_JOINABLE, 1, 1); // append
	finder.activate(THR_NEW_LWP | THR_JOINABLE, 1, 0); // create

	ACE_TCHAR buf[PATH_MAX+1];
	std::string log_dir(ACE_OS::realpath("c:/log", buf));

	ACE_Dirent dir;
	ACE_DIRENT* d;
	std::string path;

	dir.open(log_dir.c_str());
	while( (d = dir.read()) != 0 )
	{
		path = log_dir;
		path += ACE_DIRECTORY_SEPARATOR_CHAR;
		path.append(d->d_name);

		ACE_stat stat;
		if ( ACE_OS::lstat(path.c_str(), &stat) != -1 && (stat.st_mode & S_IFMT) == S_IFREG ) 
		{
			if ( ACE_OS::strncasecmp(d->d_name, "blk", 3) == 0 )
			{
				//ACE_OS::printf("BLK:%s\n", path.c_str()); //@

				Finder_Message* msg = new Finder_Message(path, Finder_Message::BLK);
				finder.msg_queue()->enqueue_tail(msg);
			}
			else if ( ACE_OS::strncasecmp(d->d_name, "dlv", 3) == 0 )
			{
				//ACE_OS::printf("DLV:%s\n", path.c_str()); //@

				Finder_Message* msg = new Finder_Message(path, Finder_Message::DLV);
				finder.msg_queue()->enqueue_tail(msg);
			}
			else
			{
				//ACE_OS::printf("---:%s\n", path.c_str()); //@
			}
		}
	}
	dir.close();

	ACE_OS::sleep(5);
	ACE_OS::printf("cancelling...\n");
	finder.cancel();
	finder.wait();

	// send stop signal
	for(size_t i = 0, c = finder.thr_count(); i < c; ++i)
	{
		int n_msg = finder.msg_queue()->enqueue_tail(new Finder_Message());
		continue;
	}
	finder.wait();

	return 0;
}

int run_blk_test(int argc, ACE_TCHAR* argv[])
{
	BLK_Log_Matcher matcher;
	matcher.set_matcher(0, new Time_Matcher(1240156800, 1240156800+864000-0)); // Time
	//matcher.set_matcher(1, new Substring_Matcher("11312")); // Reason
	matcher.set_matcher(6, new Direction_Matcher(Direction_Matcher::INBOUND | Direction_Matcher::OUTBOUND)); // Direction
	//matcher.set_matcher(2, new Substring_Matcher("124.130.59.73", 0)); // Sndr IP
	//matcher.set_matcher(3, new Substring_Matcher("203.66.210.82", 0)); // Rcpt IP
	//matcher.set_matcher(4, new Substring_Matcher("gary_mei@xuite.net")); // Sndr Addr
	//matcher.set_matcher(5, new Substring_Matcher("ccy_piggy@so-net.net.tw")); // Rcpt Addr

	int n_match, n_total;

	BLK_Log_File log;
	log.open("c:/log/blk20090420.log");
	n_match = log.search(matcher, &n_total);
	log.close();

	ACE_OS::printf("n_match: %d/%d\n", n_match, n_total);

	return 0;
}

int run_dlv_test(int argc, ACE_TCHAR* argv[])
{
	DLV_Log_Matcher matcher;
	matcher.set_matcher(0, new Time_Matcher(1228492800, 1228492800+86400-0)); // Time
	matcher.set_matcher(1, new Direction_Matcher(Direction_Matcher::OUTBOUND)); // Direction
	//matcher.set_matcher(6, new Action_Matcher(Action_Matcher::DELIVERED)); // Action
	//matcher.set_matcher(4, new UINT32_Matcher(25350984)); // Mail ID
	//matcher.set_matcher(5, new UINT32_Matcher(536838)); // Mail Size
	//matcher.set_matcher(9, new Substring_Matcher("gucci")); // Mail Subject
	//matcher.set_matcher(2, new Sender_Matcher("@yahoo.com", "222.35.156.62")); // Sndr
	//matcher.set_matcher(2, new Sender_Matcher("", "", "inquiry")); // Sndr
	matcher.set_matcher(3, new Recipient_Matcher("xinger0937@gmail.com")); // Rcpt
	//matcher.set_matcher(3, new Recipient_Matcher("", "209.85.143.27", "gmail-smtp-in.l.google.com")); // Rcpt
	//matcher.set_matcher(8, new Substring_Matcher("451")); // Reason

	int n_match, n_total;

	DLV_Log_File log;
	log.open("c:/log/dlv20081206.log");
	//log.open("c:/log/dlv20090103.log");
	//log.open("c:/log/dlv20090423.log");
	n_match = log.search(matcher, &n_total);
	log.close();

	ACE_OS::printf("n_match: %d/%d\n", n_match, n_total);

	return 0;
}

// main.h
