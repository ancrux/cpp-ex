#ifndef _LOG_PARSER_H_
#define _LOG_PARSER_H_

#include "ace/OS.h"

#include "aos/String.h"

namespace mozart {

class Log_Parser
{
public:
	static const char DEFAULT_SEPARATOR_CHAR;

public:
	Log_Parser(char sep = DEFAULT_SEPARATOR_CHAR);
	Log_Parser(const char* log, size_t len, char sep = DEFAULT_SEPARATOR_CHAR);
	virtual ~Log_Parser();

public:
	void assign(const char* log, size_t len, char sep = DEFAULT_SEPARATOR_CHAR);
	void reset() { assign(0, 0); };
	char separator() { return sep_; };
	void separator(char sep) { sep_ = sep; };
	// token/field count
	int count() { return count_; };
	// test if parsing is done
	int is_end() { return (cur_ == end_); };

public:
	// get next token/field string
	aos::bcstr next(int keep_separator = 0);
	// get full log string
	aos::bcstr full()
	{
		aos::bcstr bstr;
		bstr.buf = beg_;
		bstr.len = end_ - beg_;
		return bstr;
	};
	// get remainder of un-processed log string
	aos::bcstr left()
	{
		aos::bcstr bstr;
		bstr.buf = cur_;
		bstr.len = end_ - cur_;
		return bstr;
	};

public:
	inline void dump_token(const char* cstr)
	{
		//ACE_OS::printf("[%d]=%s\n", count(), cstr);
	}
	inline void dump()
	{
		static const size_t BUF_SIZE = 2048;
		char sbuf[BUF_SIZE+1]; // stack buffer;
		
		aos::bcstr bstr;
		while(1)
		{
			bstr = next(0);
			char* buf;
			if ( bstr.len > BUF_SIZE )
			{
				buf = new char[bstr.len+1];
				ACE_OS::memcpy(buf, bstr.buf, bstr.len); buf[bstr.len] = '\0';
				dump_token(buf);
				delete buf;
			}
			else
			{
				buf = sbuf;
				ACE_OS::memcpy(buf, bstr.buf, bstr.len); buf[bstr.len] = '\0';
				dump_token(buf);
			}

			if ( is_end() )
			{
				break;
			}
		}
	};
	
protected:
	const char* beg_;
	const char* cur_;
	const char* end_;
	char sep_; // separator
	int count_; // token count
};

} // namespace mozart

#endif // _LOG_PARSER_H_

