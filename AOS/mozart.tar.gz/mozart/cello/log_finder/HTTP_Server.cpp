#include "HTTP_Server.h"

#include "aos/net/http/HTTP_Server_IO.h"

//namespace aos {

void
HTTP_Server::urldecode(char *p)
{
	register int i=0;
	while(*(p+i))
	{
		if ((*p=*(p+i)) == '%')
		{
			*p=*(p+i+1) >= 'A' ? ((*(p+i+1) & 0xDF) - 'A') + 10 : (*(p+i+1) - '0');
			*p=(*p) * 16;
			*p+=*(p+i+2) >= 'A' ? ((*(p+i+2) & 0xDF) - 'A') + 10 : (*(p+i+2) - '0');
			i+=2;
		}
		else if (*(p+i)=='+')
		{
			*p=' ';
		}
		p++;
	}
	*p='\0';
}

HTTP_Server::HTTP_Server()
:
max_conn_(MAX_CONN+1),
shutdown_(0)
{
}

HTTP_Server::~HTTP_Server()
{
	this->close();
}

int
HTTP_Server::open(const ACE_Addr& addr)
{
	this->enable();
	if ( acceptor_.open(addr) == -1 )
		return -1; // cannot bind on the server_addr

	return 0;
}

int
HTTP_Server::close()
{
	this->disable();
	acceptor_.close();

	return 0;
}

int
HTTP_Server::start()
{
	this->enable();
	// must be activated by main thread
	this->activate(THR_NEW_LWP | THR_DETACHED, 1, 0); // create detached 
	
	return 0;
}

int
HTTP_Server::stop(const ACE_Time_Value* timeout)
{
	this->disable();
	// wait detached thread only work if activated by main thread
	this->thr_mgr()->wait(timeout);

	//ACE_Time_Value sleep_tv; sleep_tv.set(0.001);
	//while( this->thr_count() )
	//	ACE_OS::sleep(sleep_tv);
	//this->wait();

	return 0;
}

int
HTTP_Server::svc()
{
	////ACE_OS::printf("(%d) started...\n", ACE_OS::thr_self());
	//char filename[PATH_MAX+1];
	//ACE_OS::snprintf(filename, PATH_MAX, "%u.log", ACE_OS::thr_self());
	//ACE_HANDLE fh = ACE_OS::open(filename, O_CREAT | O_WRONLY);
	//if ( fh == ACE_INVALID_HANDLE )
	//	return 0;

	if ( shutdown_ == 1 )
		return 0;

#if USE_SSL == 1
	ACE_SSL_SOCK_Stream stream;
#else
	ACE_SOCK_Stream stream;
#endif
	ACE_Time_Value timeout(5);
	int flags = 0;

	int n_accept_sec = 1;
	ACE_Time_Value accept_timeout(n_accept_sec, 0);
	ACE_INET_Addr client_addr;
	while( acceptor_.accept(stream, &client_addr, &accept_timeout) == -1 )
	{
		//std::string msg = "accept() == -1\n";
		//ACE_OS::write(fh, msg.c_str(), msg.length());
		
		if ( shutdown_ == 1 )
		{
			ACE_OS::printf("shutdown == %d\n", shutdown_.value()); //@
			break;
		}

		accept_timeout.set(n_accept_sec, 0); // must reset accept_timeout for SSL accept()
		int error = ACE_OS::last_error(); // 10060 == ETIMEDOUT, 10035 == EWOULDBLOCK, 10054 == ECONNRESET
		//ACE_OS::printf("(%d) accept() error: %d\n", ACE_OS::thr_self(),  error);
		if ( error == ETIMEDOUT )
			continue;

		// other error, either spawn another listener,
		// or new another SSL_Stream, don't use the SSL_Stream
		this->activate(THR_NEW_LWP | THR_DETACHED, 1, 1);
		return 0;
	}
	if ( shutdown_ == 1 )
	{
		// server shuts down!
		stream.close();
		acceptor_.close();
		return 0;
	}

	//std::string msg = "start activate()\n";
	//ACE_OS::write(fh, msg.c_str(), msg.length());

	this->activate(THR_NEW_LWP | THR_DETACHED, 1, 1); // append new detached thread as listener
	//ACE_OS::printf("(%d) new thread created: %d!\n", ACE_OS::thr_self(), this->thr_count());

	//if ( this->thr_count() > MAX_CONN+1 )
	if ( this->thr_count() > max_conn_.value() )
	{
		// response server is temporarily unavailable!
		ACE_OS::printf("(%d) max_connection=%d reached!\n", ACE_OS::thr_self(), this->max_conn());
		stream.close();
		return 0;
	}

	//ACE_TCHAR addr[MAXHOSTNAMELEN];
	//client_addr.addr_to_string(addr, MAXHOSTNAMELEN);
	//ACE_OS::printf("%s\n", addr);

	ACE_Message_Block mb(4096); // read/write buffer
	HTTP_Server_IO io;
	io.open();

	ssize_t n_recv = -1;
	ssize_t n_send = -1;
	int support_keep_alive = 0;

	do
	{
		// read request
		io.read_reset(mb);
		while( io.read_state() < HTTP_Server_IO::RD_OK )
		{
			// buffer consumed, read more...
			if ( mb.length() == 0 )
			{
				mb.reset();
				n_recv = stream.recv(mb.wr_ptr(), mb.space(), flags, &timeout);
				if ( n_recv < 1 && ACE_OS::last_error() != EWOULDBLOCK )
					break;
				else
					mb.wr_ptr(n_recv);
			}
			// process buffer
			if ( mb.length() > 0 )
			{
				if ( io.read_state() != HTTP_Server_IO::RD_DATA )
				{
					aos::bcstr header = io.read_header(mb);
					//ACE_OS::printf("%s", io.buf().c_str());
					if ( io.read_state() > HTTP_Server_IO::RD_HEADER )
					{
						//io.dump_headers();
						//ACE_OS::printf("(%d) is_keep_alive(): %d\n", ACE_OS::thr_self(), io.is_keep_alive());
					}
				}
				else
				{
					aos::bcstr data = io.read_data(mb);
					//std::string in_data(data.buf, data.len); //@
					//ACE_OS::printf("%s", in_data.c_str()); //@
				}
			}
		}
		if ( n_recv < 1 ) break; // read failed, close connection
		//ACE_OS::printf("\n\n");

		std::string filter;

		std::string cmd;
		std::string url;
		io.get_request(&cmd, &url);
		if ( ACE_OS::strncasecmp(cmd.c_str(), "GET", 3) == 0 ||
			ACE_OS::strncasecmp(cmd.c_str(), "POST", 4) == 0 )
		{
			size_t qmark = url.find_first_of('?');
			if ( qmark != std::string::npos )
			{
				filter = url.substr(qmark+1);
				HTTP_Server::urldecode((char*) filter.c_str());
			}
		}
		else
		{
			// HTTP request error, close connection
			break;
		}

		this->finder_.cancel();
		ACE_Time_Value sleep_tv; sleep_tv.set(0.001);
		while( finder_.thr_count() != 0 )
		{
			ACE_OS::sleep(sleep_tv);
		}
		
		///*
		// write user-defined response

		//std::string content; content.reserve(1024);
		//int n = ACE_OS::snprintf(&content[0], content.capacity(), "%d\r\n", ACE_OS::time());
		//content.append(content.c_str(), n);
		//content += "\r\n";

		mb.reset();
		mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "HTTP/%.1f %d %s\r\n", 1.1, 200, "OK"));
		mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Content-Type: %s\r\n", "text/plain; charset=utf-8"));
		//mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Content-Length: %d\r\n", content.size()));
		//time_t t = ACE_OS::time();
		//struct tm tm_t;
		//ACE_OS::gmtime_r(&t, &tm_t);
		//mb.wr_ptr(ACE_OS::strftime(mb.wr_ptr(), mb.space(), "Date: %a, %d %b %Y %H:%M:%S GMT", &tm_t));
		mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Cache-Control: no-store, no-cache, must-revalidate\r\n"));
		mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Cache-Control: post-check=0, pre-check=0\r\n"));
		mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Pragma: no-cache\r\n"));
		if ( support_keep_alive && io.keep_alive() ) 
			mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Connection: %s\r\n", "Keep-Alive"));
		else
			mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "Connection: %s\r\n", "close"));
		mb.wr_ptr(ACE_OS::snprintf(mb.wr_ptr(), mb.space(), "\r\n"));
		//mb.copy(content.c_str(), content.size());

		// server write header
		n_send = stream.send_n(mb.rd_ptr(), mb.length(), flags, &timeout);
		if ( n_send < 1 ) break; // write failed, close connection

		if ( !filter.empty() )
		{
			//filter = "act='1';"
			//	"time_min='1238428800'; time_max='1249292800';"
			//	"dir='1';"
			//	//"sndr_ip='124.130.59.73';"
			//	//"size_min='9750000';size_max='0';" 
			//	;

			ACE_OS::printf("filter:%s\n", filter.c_str());
			int res = find_log(filter, &stream);
		}
		else
		{
			// Empty filter, close connection
			break;
		}
		//*/
	}
	while( support_keep_alive && io.keep_alive() );

	io.close();
	stream.close();
		
	return 0;
}

int
HTTP_Server::find_log(const std::string& filter, ACE_SOCK_Stream* stream)
{
	ACE_Time_Value t1 = ACE_OS::gettimeofday();

	finder_.stream(stream);
	finder_.filter(filter);
	//finder.activate(THR_NEW_LWP | THR_JOINABLE, ACE_OS::num_processors_online(), 0);
	//finder.activate(THR_NEW_LWP | THR_JOINABLE, 1, 1); // append
	finder_.activate(THR_NEW_LWP | THR_JOINABLE, 1, 0); // create

#ifdef ACE_WIN32
	const char* log_path = "c:/log";
#else
	const char* log_path = "/usr/local/mozart/smtpd/log";
#endif

	ACE_TCHAR buf[PATH_MAX+1];
	std::string log_dir(ACE_OS::realpath(log_path, buf));

	ACE_Dirent dir;
	ACE_DIRENT* d;
	std::string path;

	dir.open(log_dir.c_str());
	while( (d = dir.read()) != 0 )
	{
		path = log_dir;
		path += ACE_DIRECTORY_SEPARATOR_CHAR;
		path.append(d->d_name);

		ACE_stat stat;
		if ( ACE_OS::lstat(path.c_str(), &stat) != -1 && (stat.st_mode & S_IFMT) == S_IFREG ) 
		{
			if ( ACE_OS::strncasecmp(d->d_name, "blk", 3) == 0 )
			{
				//ACE_OS::printf("BLK:%s\n", path.c_str()); //@

				Finder_Message* msg = new Finder_Message(path, Finder_Message::BLK);
				if ( finder_.msg_queue()->enqueue_tail(msg) < 0 )
					delete msg;
			}
			else if ( ACE_OS::strncasecmp(d->d_name, "dlv", 3) == 0 )
			{
				//ACE_OS::printf("DLV:%s\n", path.c_str()); //@

				Finder_Message* msg = new Finder_Message(path, Finder_Message::DLV);
				if ( finder_.msg_queue()->enqueue_tail(msg) < 0 )
					delete msg;
			}
			else
			{
				//ACE_OS::printf("---:%s\n", path.c_str()); //@
			}
		}
	}
	dir.close();

	//ACE_OS::sleep(5);
	//ACE_OS::printf("cancelling...\n");
	//finder.cancel();
	//finder.wait();

	// send stop signal
	for(size_t i = 0, c = finder_.thr_count(); i < c; ++i)
	{
		int n_msg = finder_.msg_queue()->enqueue_tail(new Finder_Message());
		continue;
	}
	finder_.wait();

	ACE_Time_Value t2 = ACE_OS::gettimeofday();
	ACE_OS::printf("elasped:%d\n", t2.msec()-t1.msec());

	return 0;
}

// } // namespace aos

