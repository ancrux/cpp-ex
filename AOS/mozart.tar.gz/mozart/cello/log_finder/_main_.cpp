#include "aos/OS.h"
#include "ace/Get_Opt.h"
#include "aos/IPC.h"
using namespace aos::ipc;

#include "Log_File.h"
#include "Finder_Worker.h"

#include "HTTP_Server.h"

#include <iostream>
using namespace std;

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	int rc = 0;

	ACE_Time_Value t1 = ACE_OS::gettimeofday();

	rc = run_service_test(argc, argv);
	//rc = run_http_test(argc, argv);
	//rc = run_filter_test(argc, argv);
	//rc = run_blk_test(argc, argv);
	//rc = run_dlv_test(argc, argv);

	//rc = run_test2(argc, argv);
	
	ACE_Time_Value t2 = ACE_OS::gettimeofday();
	ACE_OS::printf("elasped:%d\n", t2.msec()-t1.msec());

	return rc;
}
