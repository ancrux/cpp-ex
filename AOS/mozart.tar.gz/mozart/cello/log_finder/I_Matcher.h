#ifndef _I_MATCHER_H_
#define _I_MATCHER_H_

#include "ace/OS.h"

#include "aos/String.h"

namespace mozart {

class I_Matcher
{
public:
	static const int NOT_MATCHED = -2;
	static const int LESSER = -1;
	static const int MATCHED = 0;
	static const int GREATER = 1;

public:
	virtual ~I_Matcher() {};

public:
	virtual int match(const char* cstr, size_t len) = 0;
};

class Time_Matcher : public I_Matcher
{
public:
	Time_Matcher(time_t min = 0, time_t max = 0);
	virtual ~Time_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	time_t min_;
	time_t max_;
};

class Direction_Matcher : public I_Matcher
{
public:
	static int direction(const char* cstr, size_t len);

public:
	enum
	{
		INBOUND = 0x0001,
		OUTBOUND = 0x0002,
		LOCAL = 0x0004,
		RELAY = 0x0008,
		SYSTEM = 0x0010,
		POP3 = 0x0020,
		UNKNOWN = 0x8000,
		ALL = 0xFFFF
	};

public:
	Direction_Matcher(int dir);
	virtual ~Direction_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	int dir_;
};

class Action_Matcher : public I_Matcher
{
public:
	static int action(const char* cstr, size_t len);

public:
	enum
	{
		BLOCKED = 0x0001,
		QUARANTINED = 0x0002,
		DELIVERED = 0x0004,
		QUEUED = 0x0008,
		RETURNED = 0x0010,
		UNKNOWN = 0x8000,
		ALL = 0xFFFF
	};

public:
	Action_Matcher(int action);
	virtual ~Action_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	int action_;
};

// to match DLV Reason, BLK Reason, BLK Sndr Addr, BLK Rcpt Addr
class Substring_Matcher : public I_Matcher
{
public:
	Substring_Matcher(const std::string& substr, int ignore_case = 1);
	virtual ~Substring_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	std::string substr_;
	int ignore_case_;
};

class UINT32_Matcher : public I_Matcher
{
public:
	UINT32_Matcher(ACE_UINT32 val);
	virtual ~UINT32_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	ACE_UINT32 val_;
};

class UINT32_Range_Matcher : public I_Matcher
{
public:
	UINT32_Range_Matcher(ACE_UINT32 min = 0, ACE_UINT32 max = 0);
	virtual ~UINT32_Range_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	ACE_UINT32 min_;
	ACE_UINT32 max_;
};

class Sender_Matcher : public I_Matcher
{
public:
	Sender_Matcher(const std::string& sndr = "", const std::string& ip = "", const std::string& auth = "");
	virtual ~Sender_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	std::string sndr_;
	std::string ip_;
	std::string auth_;
};

class Recipient_Matcher : public I_Matcher
{
public:
	Recipient_Matcher(const std::string& rcpt = "", const std::string& ip = "", const std::string& mx = "");
	virtual ~Recipient_Matcher();

public:
	virtual int match(const char* cstr, size_t len);

protected:
	std::string rcpt_;
	std::string ip_;
	std::string mx_;
};

} // namespace mozart

#endif // _I_MATCHER_H_
