#include "Log_File.h"

#include "ace/ACE.h"

namespace mozart {

Log_File::Log_File()
:
fh_(ACE_INVALID_HANDLE),
n_match_(0),
n_record_(0)
{
}

Log_File::Log_File(const char* filename)
:
fh_(ACE_INVALID_HANDLE),
n_match_(0),
n_record_(0)
{
	this->open(filename);
}


Log_File::~Log_File()
{
	this->close();
}

int
Log_File::open(const char* filename, ACE_SOCK_Stream* stream)
{
	int rc = 0;

	date_ = 0;
	rc = this->close();

	fh_ = ACE_OS::open(filename, O_BINARY | O_RDONLY);
	if ( fh_ != ACE_INVALID_HANDLE )
	{
		char buf[PATH_MAX+1];
		int ymd = ACE_OS::atoi(ACE::basename(ACE_OS::realpath(filename, buf), ACE_DIRECTORY_SEPARATOR_CHAR)+3);
		if ( ymd > 0 )
		{
			tm tm_val;
			//ACE_OS::memset(&tm_val, 0, sizeof(tm_val));
			tm_val.tm_year = (ymd/10000)-1900;
			tm_val.tm_mon = (ymd%10000)/100-1;
			tm_val.tm_mday = ymd%100;
			tm_val.tm_hour = tm_val.tm_min = tm_val.tm_sec = 0;
			
			date_ = ACE_OS::mktime(&tm_val);
		}

		stream_ = stream;
	}
	else
		rc = -1;

	return rc;
}

int
Log_File::close()
{
	int rc = 0;

	if ( fh_ != ACE_INVALID_HANDLE )
	{
		rc = ACE_OS::close(fh_);
		if ( rc == 0 )
			fh_ = ACE_INVALID_HANDLE;
	}

	return rc;
}

void
BLK_Log_File::on_matched(const char* log, int n_start_match, int n_start_record, int max_match, int max_record)
{
	//::printf("%d:%s", n_line, log);
	//getchar();

	if ( stream_ )
	{
		if ( !max_match || n_match_ <= max_match )
		{
			Log_Parser parser;
			parser.assign(log, ACE_OS::strlen(log));

			std::string tokens[7];

			aos::bcstr bstr;
			int i = 0;
			while( !parser.is_end() )
			{
				if ( i == 0 )
					parser.separator(']');
				else
					parser.separator(',');

				// get next item
				bstr = parser.next(0); // not included separator
				if ( i == 6 )
				{
					if ( bstr.len && bstr.buf[0] >= 'A' && bstr.buf[0] <= 'Z' )
					{
					}
					else
					{
						--i;
						//continue;
					}
				}
				if ( i < 7 )
					tokens[i].append(bstr.buf, bstr.len);
				else
				{
					tokens[6] += ',';
					tokens[6].append(bstr.buf, bstr.len);
				}

				++i;
			}

			std::string output;
			output += tokens[0].c_str() + 1; output += "\t";
			output += aos::trim(tokens[6]); output += "\t";
			output += "BLOCKED"; output += "\t";
			output += aos::trim(tokens[1]); output += "\t";

			output += tokens[4];
			if ( !tokens[2].empty() )
			{
				output += "("; output += tokens[2]; output += ")";
			}
			output += "\t";

			output += tokens[5];
			if ( !tokens[3].empty() )
			{
				output += "("; output += tokens[3]; output += ")";
			}
			output += "\t\t\t\n";

			//std::string quoted;
			//std::string output;
			//output += "[\"";
			//output += tokens[0].c_str() + 1; output += "\",\"";
			//output += aos::trim(tokens[6]); output += "\",\"";
			//output += "BLOCKED"; output += "\",\"";
			//output += aos::trim(tokens[1]); output += "\",";

			//quoted.resize(0);
			//quoted += tokens[4];
			//if ( !tokens[2].empty() )
			//{
			//	quoted += "("; quoted += tokens[2]; quoted += ")";
			//}
			//aos::QS::encode(quoted);
			//output += quoted; output += ",";

			//quoted.resize(0);
			//quoted += tokens[5];
			//if ( !tokens[3].empty() )
			//{
			//	quoted += "("; quoted += tokens[3]; quoted += ")";
			//}
			//aos::QS::encode(quoted);
			//output += quoted; output += ",";
			//
			//output += "\"\",\"\",\"\"]\n";

			ssize_t n_send = -1;
			n_send = stream_->send_n(output.c_str(), output.size(), 0, 0);
			//n_send = stream_->send_n(log, ACE_OS::strlen(log), 0, 0);
		}
	}
}

int
BLK_Log_File::search(Log_Matcher& matcher, int* n_total, int max_match, int max_record)
{
	int n_start_record = n_record_;
	int n_start_match = n_match_;

	if ( fh_ )
	{
		static const int BUF_SIZE = 16384;
		char buf[BUF_SIZE]; // static memory allocation (stack)

		aos::bcstr bstr;
		std::string line; //line.reserve(4096);
		
		char delimiter = '\n'; // line delimiter
		//char delimiter2 = '\r'; // line delimiter

		int parsing = 1;
		bool disable_time_matcher = false;
		I_Matcher* time_matcher = matcher.detach_matcher(0); // detach time_matcher
		if ( time_matcher && date_ )
		{
			// log min date
			time_t min_date = date_;
			tm tm_min_val;
			ACE_OS::localtime_r(&min_date, &tm_min_val);
			char minbuf[32];
			ACE_OS::strftime(minbuf, 31, "%Y-%m-%d %H:%M:%S", &tm_min_val);
			size_t n_minbuf = ACE_OS::strlen(minbuf);
			
			// log max date
			time_t max_date = date_ + 86400 - 1;
			tm tm_max_val;
			ACE_OS::localtime_r(&max_date, &tm_max_val);
			char maxbuf[32];
			ACE_OS::strftime(maxbuf, 31, "%Y-%m-%d %H:%M:%S", &tm_max_val);
			size_t n_maxbuf = ACE_OS::strlen(maxbuf);

			int match_min;
			int match_max;
			
			if ( parsing )
			{
				match_min = time_matcher->match(minbuf, n_minbuf);
				if ( match_min == I_Matcher::GREATER )
				{
					//ACE_OS::printf("search_range < min(%s), out of range!\n", minbuf); //@
					parsing = 0;
				}
			}

			if ( parsing )
			{
				match_max = time_matcher->match(maxbuf, n_maxbuf);
				if ( match_max == I_Matcher::LESSER )
				{
					//ACE_OS::printf("max(%s) < search_range, out of range!\n", maxbuf); //@
					parsing = 0;
				}
			}

			if ( parsing && match_min == I_Matcher::MATCHED && match_max == I_Matcher::MATCHED )
			{
				disable_time_matcher = true;
				//ACE_OS::printf("always inside time range! can take off time_matcher temporarily\n"); //@
			}
		}
		if ( !disable_time_matcher )
			matcher.set_matcher(0, time_matcher);

		while( parsing )
		{
			// read buffer
			ssize_t n_buf = ACE_OS::read(fh_, buf, BUF_SIZE);
			if ( n_buf == 0 )
			{
				if ( line.size() )
					++n_record_; // count for last line

				break;
			}

			// get lines
			const char* left = buf;
			size_t n_left = n_buf;
			while( 1 )
			{
				bstr = aos::get_line(left, n_left, delimiter);
				left += bstr.len;
				n_left -= bstr.len;
				if ( bstr.buf[bstr.len-1] == delimiter ) // BLK log
				{
					++n_record_; // read one line

					line.append(bstr.buf, bstr.len); 

					int matched = matcher.match(line.c_str(), line.size());
					if ( matched == I_Matcher::MATCHED )
					{
						++n_match_;
						this->on_matched(line.c_str(), n_start_match, n_start_record, max_match, max_record);
					}
					else 
					{
						if ( matched == I_Matcher::GREATER )
						{
							parsing = 0;
							break;
						}
					}

					line.resize(0);
				}
				else
				{
					line.append(bstr.buf, bstr.len);
				}

				if ( n_left <= 0 )
					break; // buffer consumed, get next buffer!
			}
		} // while( parsing )

		if ( disable_time_matcher )
			matcher.set_matcher(0, time_matcher);

	} // if ( fh_ )

	if ( n_total )
		*n_total = n_record_ - n_start_record;

	return n_match_ - n_start_match;
}

void
DLV_Log_File::on_matched(const char* log, int n_start_match, int n_start_record, int max_match, int max_record)
{
	//::printf("%d:%s", n_total, log);
	//getchar();

	if ( stream_ )
	{
		if ( !max_match || n_match_ <= max_match )
		{
			Log_Parser parser;
			parser.assign(log, ACE_OS::strlen(log));
			parser.separator(',');

			std::string tokens[10];

			aos::bcstr bstr;
			int i = 0;
			while( !parser.is_end() )
			{
				// get next item
				bstr = parser.next(0); // not included separator
				if ( i < 10 )
					tokens[i].append(bstr.buf, bstr.len);
				else
				{
					tokens[9] += ',';
					tokens[9].append(bstr.buf, bstr.len);
				}

				++i;
			}

			std::string output;
			output += tokens[0]; output += "\t";
			output += tokens[1]; output += "\t";
			output += tokens[6]; output += "\t";

			output += tokens[7];
			if ( !tokens[8].empty() )
			{
				output += " "; output += aos::trim(tokens[8]);
			}
			output += "\t";

			output += tokens[2]; output += "\t";
			output += tokens[3]; output += "\t";
			output += tokens[5]; output += "\t";
			output += tokens[4]; output += "\t";
			output += aos::trim(tokens[9]); output += "\n";
			//output += tokens[9]; // already contains "\n"

			//std::string quoted;
			//std::string output;
			//output += "[\"";
			//output += tokens[0]; output += "\",\"";
			//output += tokens[1]; output += "\",\"";
			//output += tokens[6]; output += "\",";

			//quoted.resize(0);
			//quoted += tokens[7];
			//if ( !tokens[8].empty() )
			//{
			//	quoted += " "; quoted += aos::trim(tokens[8]);
			//}
			//aos::QS::encode(quoted);
			//output += quoted; output += ",";

			//aos::QS::encode(tokens[2]);
			//output += tokens[2]; output += ",";

			//aos::QS::encode(tokens[3]);
			//output += tokens[3]; output += ",";

			//aos::QS::encode(aos::trim(tokens[9]));
			//output += tokens[9]; output += ",";
			//
			//output += "\"";
			//output += tokens[5]; output += "\",\"";
			//output += tokens[4];
			//output += "\"]\n";

			ssize_t n_send = -1;
			n_send = stream_->send_n(output.c_str(), output.size(), 0, 0);
			//n_send = stream_->send_n(log, ACE_OS::strlen(log), 0, 0);
		}
	}
}

int
DLV_Log_File::search(Log_Matcher& matcher, int* n_total, int max_match, int max_record)
{
	int n_start_record = n_record_;
	int n_start_match = n_match_;

	if ( fh_ )
	{
		static const int BUF_SIZE = 16384;
		char buf[BUF_SIZE]; // static memory allocation (stack)

		aos::bcstr bstr;
		std::string line; //line.reserve(4096);
		
		char delimiter = '\n'; // line delimiter
		char delimiter2 = '\r'; // line delimiter

		int parsing = 1;
		bool disable_time_matcher = false;
		I_Matcher* time_matcher = matcher.detach_matcher(0); // detach time_matcher
		if ( time_matcher && date_ )
		{
			// log min date
			time_t min_date = date_;
			tm tm_min_val;
			ACE_OS::localtime_r(&min_date, &tm_min_val);
			char minbuf[32];
			ACE_OS::strftime(minbuf, 31, "%Y-%m-%d %H:%M:%S", &tm_min_val);
			size_t n_minbuf = ACE_OS::strlen(minbuf);
			
			// log max date
			time_t max_date = date_ + 86400 - 1;
			tm tm_max_val;
			ACE_OS::localtime_r(&max_date, &tm_max_val);
			char maxbuf[32];
			ACE_OS::strftime(maxbuf, 31, "%Y-%m-%d %H:%M:%S", &tm_max_val);
			size_t n_maxbuf = ACE_OS::strlen(maxbuf);

			int match_min;
			int match_max;
			
			if ( parsing )
			{
				match_min = time_matcher->match(minbuf, n_minbuf);
				if ( match_min == I_Matcher::GREATER )
				{
					//ACE_OS::printf("search_range < min(%s), out of range!\n", minbuf); //@
					parsing = 0;
				}
			}

			if ( parsing )
			{
				match_max = time_matcher->match(maxbuf, n_maxbuf);
				if ( match_max == I_Matcher::LESSER )
				{
					//ACE_OS::printf("max(%s) < search_range, out of range!\n", maxbuf); //@
					parsing = 0;
				}
			}

			if ( parsing && match_min == I_Matcher::MATCHED && match_max == I_Matcher::MATCHED )
			{
				disable_time_matcher = true;
				//ACE_OS::printf("always inside time range! can take off time_matcher temporarily\n"); //@
			}
		}
		if ( !disable_time_matcher )
			matcher.set_matcher(0, time_matcher);

		while( parsing )
		{
			// read buffer
			ssize_t n_buf = ACE_OS::read(fh_, buf, BUF_SIZE);
			if ( n_buf == 0 )
			{
				if ( line.size() )
					++n_record_; // count for last line

				break;
			}

			// get lines
			const char* left = buf;
			size_t n_left = n_buf;
			while( 1 )
			{
				bstr = aos::get_line(left, n_left, delimiter);
				left += bstr.len;
				n_left -= bstr.len;
				if ( bstr.len > 1 && bstr.buf[bstr.len-1] == delimiter && bstr.buf[bstr.len-2] == delimiter2 ) // DLV log
				{
					++n_record_; // read one line

					line.append(bstr.buf, bstr.len); 

					int matched = matcher.match(line.c_str(), line.size());
					if ( matched == I_Matcher::MATCHED )
					{
						++n_match_;
						this->on_matched(line.c_str(), n_start_match, n_start_record, max_match, max_record);
					}
					else 
					{
						if ( matched == I_Matcher::GREATER )
						{
							parsing = 0;
							break;
						}
					}

					line.resize(0);
				}
				else
				{
					line.append(bstr.buf, bstr.len);
				}

				if ( n_left <= 0 )
					break; // buffer consumed, get next buffer!
			}
		} // while( parsing )

		if ( disable_time_matcher )
			matcher.set_matcher(0, time_matcher);

	} // if ( fh_ )

	if ( n_total )
		*n_total = n_record_ - n_start_record;

	return n_match_ - n_start_match;
}

}

