#include "Log_Matcher.h"

namespace mozart {

Log_Matcher::Log_Matcher()
{
}

Log_Matcher::~Log_Matcher()
{
	clear_matchers();
}

void
Log_Matcher::set_matcher(size_t idx, I_Matcher* matcher)
{
	if ( idx < matcher_count() )
	{
		if ( matchers_[idx] )
			delete matchers_[idx];
		matchers_[idx] = matcher;
	}
	else
	{
		for(size_t i = matcher_count(); i <= idx; ++i)
		{
			matchers_.push_back(0);
		}
		matchers_[idx] = matcher;
	}
	// remove null-matchers from the tail
	for(size_t i = matcher_count(); i > 0; --i)
	{
		if ( matchers_[i-1] == 0 )
			matchers_.pop_back();
		else
			break;
	}
}

void
Log_Matcher::clear_matchers()
{
	for(size_t i = 0; i < matchers_.size(); ++i)
	{
		if ( matchers_[i] )
			delete matchers_[i];
	}
	matchers_.clear();
}

} // namespace mozart

