#include "Finder_Worker.h"

namespace mozart {

/// class

Finder_Message::Finder_Message(int op_code)
:
op(op_code)
{
}

Finder_Message::Finder_Message(const std::string& str, int op_code)
:
m(str),
op(op_code)
{
}

Finder_Message::Finder_Message(const char* cstr, int op_code)
:
m(cstr),
op(op_code)
{
}

Finder_Message::~Finder_Message()
{
}

/// class

Finder_Worker::Finder_Worker(ACE_SOCK_Stream* stream)
:
cancel_(0),
max_match_(MAX_MATCH),
stream_(stream)
{
}

Finder_Worker::~Finder_Worker()
{
}

void
Finder_Worker::apply_filter(const std::string& str, BLK_Log_Matcher& blk_matcher, DLV_Log_Matcher& dlv_matcher)
{
	blk_matcher.clear_matchers();
	dlv_matcher.clear_matchers();

	time_t time_min = 0;
	time_t time_max = 0;
	int dir_flag = 0;
	int act_flag = 0;
	std::string act_reason;
	std::string sndr_addr;
	std::string sndr_ip;
	//sndr_auth
	std::string rcpt_addr;
	std::string rcpt_ip;
	//---
	ACE_UINT32 id = 0;
	ACE_UINT32 size_min = 0;
	ACE_UINT32 size_max = 0;
	std::string subject;

	size_t pos = std::string::npos;
	std::string key;
	std::string val; val.reserve(str.size());
	aos::QS qs('\'');
	char quote = '\'';
	char escape = '\\';
	
	// Time
	key = "time_min=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);

		time_min = ACE_OS::atoi(val.c_str());
	}

	key = "time_max=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);

		time_max = ACE_OS::atoi(val.c_str());
	}

	if ( time_min || time_max )
	{
		blk_matcher.set_matcher(0, new Time_Matcher(time_min, time_max));
		dlv_matcher.set_matcher(0, new Time_Matcher(time_min, time_max));
	}

	// Direction
	key = "dir=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);

		dir_flag = ACE_OS::atoi(val.c_str()); // or val.data()
	}

	if ( dir_flag )
	{
		blk_matcher.set_matcher(6, new Direction_Matcher(dir_flag));
		dlv_matcher.set_matcher(1, new Direction_Matcher(dir_flag));
	}

	// Action
	key = "act=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);

		act_flag = ACE_OS::atoi(val.c_str());
	}

	if ( act_flag )
	{
		dlv_matcher.set_matcher(6, new Action_Matcher(act_flag));
	}

	// Action Reason
	key = "act_reason=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		act_reason = val.c_str();
	}

	if ( act_reason.size() )
	{
		blk_matcher.set_matcher(1, new Substring_Matcher(act_reason));
		dlv_matcher.set_matcher(8, new Substring_Matcher(act_reason));
	}

	// Sndr_Addr, Sndr_IP
	key = "sndr_addr=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		sndr_addr = val.c_str();
	}

	key = "sndr_ip=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		sndr_ip = val.c_str();
	}

	if ( sndr_addr.size() || sndr_ip.size() )
	{
		if ( sndr_addr.size() )
			blk_matcher.set_matcher(4, new Substring_Matcher(sndr_addr));
		if ( sndr_ip.size() )
			blk_matcher.set_matcher(2, new Substring_Matcher(sndr_ip, 0));
		dlv_matcher.set_matcher(2, new Sender_Matcher(sndr_addr, sndr_ip));
	}

	// Rcpt_Addr, Rcpt_IP
	key = "rcpt_addr=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		rcpt_addr = val.c_str();
	}

	key = "rcpt_ip=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		rcpt_ip = val.c_str();
	}

	if ( rcpt_addr.size() || rcpt_ip.size() )
	{
		if ( rcpt_addr.size() )
			blk_matcher.set_matcher(5, new Substring_Matcher(rcpt_addr));
		if ( rcpt_ip.size() )
			blk_matcher.set_matcher(3, new Substring_Matcher(rcpt_ip, 0));
		dlv_matcher.set_matcher(3, new Recipient_Matcher(rcpt_addr, rcpt_ip));
	}

	// Mail_ID
	key = "id=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		id = ACE_OS::strtoul(val.c_str(), NULL, 10);
	}

	if ( id )
	{
		dlv_matcher.set_matcher(4, new UINT32_Matcher(id));
	}

	// Mail_Size
	key = "size_min=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		size_min = ACE_OS::strtoul(val.c_str(), NULL, 10);
	}

	key = "size_max=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);
		
		size_max = ACE_OS::strtoul(val.c_str(), NULL, 10);
	}

	if ( size_min || size_max )
	{
		dlv_matcher.set_matcher(5, new UINT32_Range_Matcher(size_min, size_max));
	}

	// Mail_Subject
	key = "subject=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);

		subject = val.c_str();
	}

	if ( subject.size() )
	{
		dlv_matcher.set_matcher(9, new Substring_Matcher(subject));
	}

	// Max Match
	key = "max_match=";
	pos = str.find(key);
	if ( pos != std::string::npos )
	{
		pos += key.size();

		val.assign(str.c_str()+pos);
		pos = val.find(quote, 1);
		while( pos != std::string::npos )
		{
			if ( val[pos-1] != escape )
				break;
			else
				pos = val.find(quote, pos+1);
		}
		if ( pos != std::string::npos )
			val.resize(pos+1);
		aos::QS::decode(val, quote, escape);

		this->max_match_ = ACE_OS::atoi(val.c_str());
	}
}

int
Finder_Worker::svc(void)
{
	//ACE_DEBUG((LM_DEBUG, ACE_TEXT ("(%t) starting up \n")));

	int rc = -1;

	BLK_Log_Matcher blk_matcher;
	DLV_Log_Matcher dlv_matcher;

	BLK_Log_File blk_log;
	DLV_Log_File dlv_log;

	// Apply filter and optimize search
	apply_filter(this->filter_, blk_matcher, dlv_matcher);
	int search_blk = 1;
	int search_dlv = 1;
	if ( dlv_matcher.get_matcher(4) || dlv_matcher.get_matcher(5) || dlv_matcher.get_matcher(9) )
	{
		search_blk = 0;
	}
	Action_Matcher* act_matcher = (Action_Matcher*) dlv_matcher.get_matcher(6);
	if ( act_matcher )
	{
		if ( act_matcher->match("BLOCKED", 7) != I_Matcher::MATCHED )
			search_blk = 0;
		if ( act_matcher->match("QUARANTINED", 11) != I_Matcher::MATCHED &&
			act_matcher->match("DELIVERED", 9) != I_Matcher::MATCHED &&
			act_matcher->match("QUEUED", 6) != I_Matcher::MATCHED &&
			act_matcher->match("RETURNED", 8) != I_Matcher::MATCHED &&
			act_matcher->match("UNKNOWN", 7) != I_Matcher::MATCHED )
			search_dlv = 0;
	}

	Finder_Message* msg;
	//long last_notify_id = -1;

	int n_total_match = 0;
	int n_total_record = 0;
	while( cancel_ == 0 )
	{
		int n_msg = this->msg_queue()->dequeue_head(msg);
		if ( n_msg != -1 )
		{
			//if ( msg->op == 0 )
			if ( msg->m.empty() )
			{
				delete msg;
				rc = 0;

				break;
			}

			//ACE_OS::printf("(%d) %s\n", ACE_OS::thr_self(), msg->m.c_str());

			int n_match = 0;
			int n_record = 0;
			switch( msg->op )
			{
				case Finder_Message::BLK:
				{
					if ( !search_blk )
						break;
					if ( blk_log.open(msg->m.c_str(), stream_) == 0 )
					{
						blk_log.n_match(n_total_match);
						blk_log.n_record(n_total_record);

						n_match = blk_log.search(blk_matcher, &n_record, max_match_);

						n_total_match = blk_log.n_match();
						n_total_record = blk_log.n_record();
						blk_log.close();

						if ( n_total_match > max_match_ )
							cancel_ = 1;
					}
					if ( n_record )
					{
						ACE_OS::printf("(%u) %s: %d/%d\n", ACE_OS::thr_self(), msg->m.c_str(), n_match, n_record);
					}
					break;
				}
				case Finder_Message::DLV:
				{
					if ( !search_dlv )
						break;
					if ( dlv_log.open(msg->m.c_str(), stream_) == 0 )
					{
						dlv_log.n_match(n_total_match);
						dlv_log.n_record(n_total_record);

						n_match = dlv_log.search(dlv_matcher, &n_record, max_match_);

						n_total_match = dlv_log.n_match();
						n_total_record = dlv_log.n_record();
						dlv_log.close();

						if ( n_total_match > max_match_ )
							cancel_ = 1;
					}
					if ( n_record )
					{
						ACE_OS::printf("(%u) %s: %d/%d\n", ACE_OS::thr_self(), msg->m.c_str(), n_match, n_record);
					}
					break;
				}
			}

			delete msg;
		}
		else
		{
			break;
		}
	}

	//ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) shutting down\n")));

	return rc;
}

//blk_matcher.set_matcher(0, new Time_Matcher(1240156800, 1240156800+864000-0)); // Time
//blk_matcher.set_matcher(1, new Substring_Matcher("11312")); // Reason
//blk_matcher.set_matcher(6, new Direction_Matcher(Direction_Matcher::INBOUND | Direction_Matcher::OUTBOUND)); // Direction
//blk_matcher.set_matcher(2, new Substring_Matcher("124.130.59.73", 0)); // Sndr IP
//blk_matcher.set_matcher(3, new Substring_Matcher("203.66.210.82", 0)); // Rcpt IP
//blk_matcher.set_matcher(4, new Substring_Matcher("gary_mei@xuite.net")); // Sndr Addr
//blk_matcher.set_matcher(5, new Substring_Matcher("ccy_piggy@so-net.net.tw")); // Rcpt Addr

//dlv_matcher.set_matcher(0, new Time_Matcher(1228492800, 1228492800+864000-0)); // Time
//dlv_matcher.set_matcher(1, new Direction_Matcher(Direction_Matcher::OUTBOUND)); // Direction
//dlv_matcher.set_matcher(6, new Action_Matcher(Action_Matcher::DELIVERED)); // Action
//dlv_matcher.set_matcher(4, new UINT32_Matcher(25350984)); // Mail ID
//dlv_matcher.set_matcher(5, new UINT32_Matcher(536838)); // Mail Size
//dlv_matcher.set_matcher(9, new Substring_Matcher("gucci")); // Mail Subject
//dlv_matcher.set_matcher(2, new Sender_Matcher("@yahoo.com", "203.66.210.83")); // Sndr
//dlv_matcher.set_matcher(2, new Sender_Matcher("", "", "inquiry")); // Sndr
//dlv_matcher.set_matcher(3, new Recipient_Matcher("xinger0937@gmail.com")); // Rcpt
//dlv_matcher.set_matcher(3, new Recipient_Matcher("", "209.85.143.27", "gmail-smtp-in.l.google.com")); // Rcpt
//dlv_matcher.set_matcher(8, new Substring_Matcher("451")); // Reason

} // namespace mozart

