#ifndef _FINDER_WORKER_H_
#define _FINDER_WORKER_H_

#include "ace/OS.h"
#include "ace/Atomic_Op.h"
#include "ace/Task_Ex_T.h"

#include "ace/SSL/SSL_SOCK_Stream.h" //#include "ace/SOCK_Stream.h"

#include "Log_File.h"

#include <iostream>
using namespace std;

namespace mozart {

class Finder_Message
{
public:
	std::string m;
	int op;

public:
	enum
	{
		EXIT = 0,
		//FILTER,
		BLK,
		DLV
	};

public:
	Finder_Message(int op_code = 0);
	Finder_Message(const std::string& str, int op_code = 0);
	Finder_Message(const char* cstr, int op_code = 0);
	~Finder_Message();
};

class Finder_Worker : public ACE_Task_Ex<ACE_MT_SYNCH, Finder_Message>
{
public:
	static const int MAX_MATCH = 1000; // default max match

public:
	Finder_Worker(ACE_SOCK_Stream* stream = 0);
	virtual ~Finder_Worker();

public:
	virtual int svc();

public:
	void stream(ACE_SOCK_Stream* stream)
	{
		stream_ = stream;
	};
	void filter(const std::string& filter)
	{
		filter_ = filter;
		cancel_ = 0;
	};
	void cancel()
	{
		cancel_ = 1;
		//this->msg_queue()->deactivate();
		this->msg_queue()->flush();
		//this->msg_queue()->activate();
	}
	int is_cancelled()
	{
		return (int) cancel_.value();
	}

protected:
	void apply_filter(const std::string& str, BLK_Log_Matcher& blk_matcher, DLV_Log_Matcher& dlv_matcher);

protected:
	std::string filter_;
	ACE_Atomic_Op<ACE_Thread_Mutex, long> cancel_;
	int max_match_;

protected:
	ACE_SOCK_Stream* stream_;

//public:
//	void apply_filter();
//	// return previous notify count
//	long notify(long event_type)
//	{
//		// need mutex lock here??
//		// or use this->suspend()/this->resume()??
//		if ( notify_count == 0 )
//		{
//			// notify consumer threads
//			notify_count = this->thr_count();
//			notify_event = 1234; // user-defined event type
//			++notify_id;
//		}
//		else
//		{
//			// last notify is not consumed completed by all threads
//		}
//		return 0;
//	};
//
//protected:
//	void notify_handler()
//	{
//	};
//
//protected:
//	ACE_Atomic_Op<ACE_Thread_Mutex, long> notify_count;
//	ACE_Atomic_Op<ACE_Thread_Mutex, long> notify_event; //? can be non-atomic
//	ACE_Atomic_Op<ACE_Thread_Mutex, long> notify_id; //? can be non-atomic
};

} // namespace mozart

#endif // _FINDER_WORKER_H_


