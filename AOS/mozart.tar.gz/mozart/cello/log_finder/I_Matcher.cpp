#include "I_Matcher.h"

namespace mozart {

/// class

Time_Matcher::Time_Matcher(time_t min, time_t max)
:
min_(min),
max_(max)
{
}

Time_Matcher::~Time_Matcher()
{
}

int
Time_Matcher::match(const char* cstr, size_t len)
{
	int matched = I_Matcher::MATCHED;

	tm tm_val;

	//ACE_OS::strptime(cstr, "%Y-%m-%d %H:%M:%S", &tm_val); // 1735-1234=501ms (n=4396171)
	///* // 1438-1234=204ms (n=4396171)
	int val = 0;
	int n_val = 0;
	bool is_digit = false;
	register const char* ptr = cstr;
	while( *ptr )
	{
		unsigned int n = static_cast<unsigned int>(*ptr-'0');
		if ( n < 10 ) //if ( *ptr >= '0' && *ptr <= '9' )
		{
			if ( !is_digit )
			{
				is_digit = true;
				val = 0;
			}
			val = val * 10 + n; //(*ptr - '0');
		}
		else
		{
			if ( is_digit )
			{
				is_digit = false;
				switch(n_val)
				{
					case 0:
						tm_val.tm_year = val-1900;
						break;
					case 1:
						tm_val.tm_mon = val-1;
						break;
					case 2:
						tm_val.tm_mday = val;
						break;
					case 3:
						tm_val.tm_hour = val;
						break;
					case 4:
						tm_val.tm_min = val;
						break;
					case 5:
						tm_val.tm_sec = val;
						break;
				}
				++n_val;
			}
		}
		++ptr;
	}
	if ( is_digit )
	{
		switch(n_val)
		{
			case 0:
				tm_val.tm_year = val-1900;
				break;
			case 1:
				tm_val.tm_mon = val-1;
				break;
			case 2:
				tm_val.tm_mday = val;
				break;
			case 3:
				tm_val.tm_hour = val;
				break;
			case 4:
				tm_val.tm_min = val;
				break;
			case 5:
				tm_val.tm_sec = val;
				break;
		}
	}
	//*/

	if ( n_val < 5 )
	{
		matched = I_Matcher::NOT_MATCHED;
		return matched;
	}

	//char buf[128];
	//ACE_OS::strftime(buf, 127, "%Y-%m-%d %H:%M:%S", &tm_val);
	//ACE_OS::printf("time=%s\n", buf);

	time_t tt_val = ACE_OS::mktime(&tm_val); // 2390-1250=1140ms (n=4396171)
	//ACE_OS::printf("time_t=%d\n", tt_val);

	if ( matched == I_Matcher::MATCHED && min_ && tt_val < min_ )
		matched = I_Matcher::LESSER;
		
	if ( matched == I_Matcher::MATCHED && max_ && tt_val >= max_ )
		matched = I_Matcher::GREATER;

	//getchar();

	return matched;
}

/// class

int
Direction_Matcher::direction(const char* cstr, size_t len)
{
	int dir = UNKNOWN;
	if ( len )
	{
		switch( cstr[0] )
		{
			case 'I':
				dir = INBOUND;
				break;
			case 'O':
				dir = OUTBOUND;
				break;
			case 'L':
				dir = LOCAL;
				break;
			case 'R':
				dir = RELAY;
				break;
			case 'S':
				dir = SYSTEM;
				break;
			case 'P':
				dir = POP3;
				break;
		}
	}

	return dir;
}

Direction_Matcher::Direction_Matcher(int dir)
:
dir_(dir)
{
}

Direction_Matcher::~Direction_Matcher()
{
}

int
Direction_Matcher::match(const char* cstr, size_t len)
{
	int matched = I_Matcher::NOT_MATCHED;

	int dir = Direction_Matcher::direction(cstr, len);
	if ( dir & dir_ )
		matched = I_Matcher::MATCHED;

	return matched;
}

/// class

int
Action_Matcher::action(const char* cstr, size_t len)
{
	int action = UNKNOWN;
	if ( ACE_OS::strncasecmp("BLOCKED", cstr, len) == 0 )
	{
		action = BLOCKED;
	}
	else if ( ACE_OS::strncasecmp("QUARANTINED", cstr, len) == 0 )
	{
		action = QUARANTINED;
	}
	else if ( ACE_OS::strncasecmp("DELIVERED", cstr, len) == 0 )
	{
		action = DELIVERED;
	}
	else if ( ACE_OS::strncasecmp("QUEUED", cstr, len) == 0 )
	{
		action = QUEUED;
	}
	else if ( ACE_OS::strncasecmp("RETURNED", cstr, len) == 0 )
	{
		action = RETURNED;
	}

	return action;
}

Action_Matcher::Action_Matcher(int action)
:
action_(action)
{
}

Action_Matcher::~Action_Matcher()
{
}

int
Action_Matcher::match(const char* cstr, size_t len)
{
	int matched = I_Matcher::NOT_MATCHED;

	int action = Action_Matcher::action(cstr, len);
	if ( action & action_ )
		matched = I_Matcher::MATCHED;

	return matched;
}

/// class

Substring_Matcher::Substring_Matcher(const std::string& substr, int ignore_case)
:
substr_(substr),
ignore_case_(ignore_case)
{
	if ( !substr_.empty() && ignore_case_ )
	{
		aos::tolower(substr_);
	}
}

Substring_Matcher::~Substring_Matcher()
{
}

int
Substring_Matcher::match(const char* cstr, size_t len)
{
	int matched = I_Matcher::MATCHED;

	if ( ignore_case_ ) aos::tolower((char*) cstr);
	if ( matched == I_Matcher::MATCHED && !substr_.empty() && ACE_OS::strstr(cstr, substr_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;

	return matched;
}

/// class

UINT32_Matcher::UINT32_Matcher(ACE_UINT32 val)
:
val_(val)
{
}

UINT32_Matcher::~UINT32_Matcher()
{
}

int
UINT32_Matcher::match(const char* cstr, size_t len)
{
	int matched = I_Matcher::NOT_MATCHED;

	ACE_UINT32 val = ACE_OS::atoi(cstr);
	if ( val == val_ )
		matched = I_Matcher::MATCHED;

	return matched;
}

/// class

UINT32_Range_Matcher::UINT32_Range_Matcher(ACE_UINT32 min, ACE_UINT32 max)
:
min_(min),
max_(max)
{
}

UINT32_Range_Matcher::~UINT32_Range_Matcher()
{
}

int
UINT32_Range_Matcher::match(const char* cstr, size_t len)
{
	int matched = I_Matcher::MATCHED;

	ACE_UINT32 val = ACE_OS::strtoul(cstr, NULL, 10);
	if ( matched == I_Matcher::MATCHED && min_ && val < min_ )
		matched = I_Matcher::NOT_MATCHED;
	if ( matched == I_Matcher::MATCHED && max_ && val >= max_ )
		matched = I_Matcher::NOT_MATCHED;

	return matched;
}

/// class

Sender_Matcher::Sender_Matcher(const std::string& sndr, const std::string& ip, const std::string& auth)
:
sndr_(sndr),
ip_(ip),
auth_(auth)
{
	if ( !sndr_.empty() )
	{
		aos::tolower(sndr_);
	}
	if ( !ip_.empty() )
	{
		ip_ = '(' + ip_;
	}
	if ( !auth_.empty() )
	{
		aos::tolower(auth_);
		auth_ = '-' + auth_;
		auth_ += ')';
	}
}

Sender_Matcher::~Sender_Matcher()
{
}

int
Sender_Matcher::match(const char* cstr, size_t len)
{
	//if ( sndr_.empty() && ip_.empty() && auth_.empty() )
	//	return I_Matcher::NOT_MATCHED;
	
	int matched = I_Matcher::MATCHED;

	aos::tolower((char*) cstr);
	if ( matched == I_Matcher::MATCHED && !sndr_.empty() && ACE_OS::strstr(cstr, sndr_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;
	if ( matched == I_Matcher::MATCHED && !ip_.empty() && ACE_OS::strstr(cstr, ip_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;
	if ( matched == I_Matcher::MATCHED && !auth_.empty() && ACE_OS::strstr(cstr, auth_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;

	return matched;
}

/// class

Recipient_Matcher::Recipient_Matcher(const std::string& rcpt, const std::string& ip, const std::string& mx)
:
rcpt_(rcpt),
ip_(ip),
mx_(mx)
{
	if ( !rcpt_.empty() )
	{
		aos::tolower(rcpt_);
	}
	if ( !ip_.empty() )
	{
		ip_ = '(' + ip_;
	}
	if ( !mx_.empty() )
	{
		aos::tolower(mx_);
		mx_ = '-' + mx_;
		mx_ += ')';
	}
}

Recipient_Matcher::~Recipient_Matcher()
{
}

int
Recipient_Matcher::match(const char* cstr, size_t len)
{
	//if ( rcpt_.empty() && ip_.empty() )
	//	return I_Matcher::NOT_MATCHED;
	
	int matched = I_Matcher::MATCHED;

	aos::tolower((char*) cstr);
	if ( matched == I_Matcher::MATCHED && !rcpt_.empty() && ACE_OS::strstr(cstr, rcpt_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;
	if ( matched == I_Matcher::MATCHED && !ip_.empty() && ACE_OS::strstr(cstr, ip_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;
	if ( matched == I_Matcher::MATCHED && !mx_.empty() && ACE_OS::strstr(cstr, mx_.c_str()) == 0 )
		matched = I_Matcher::NOT_MATCHED;

	return matched;
}

} // namespace mozart
