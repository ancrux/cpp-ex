#!/bin/sh
USERHOME=$(./userhome $1)
OUTPUT="$1$2.lst"
LIST=$(./dumpdir $USERHOME/$2 | tr -d '\t' | grep "^File: " | cut -d ' ' -f 2 | tr -d ',')
rm -f $OUTPUT
for i in $LIST 
do
	#echo "$USERHOME/MSGS/$i"
	echo "$USERHOME/MSGS/$i" >> $OUTPUT
done
