
int run_imap4_client_io(int argc, ACE_TCHAR* argv[])
{
	std::string server("localhost");
	u_short port = 143;
	int ssl = 0;
	std::string user;
	std::string pass;
	std::string mbox("INBOX");
	std::string folder;

	// get console parameters
	ACE_Get_Opt cmdline(argc, argv, ACE_TEXT(""));

	if ( argc < 5 )
	{
		ACE_OS::printf("Usage: %s <user> <pass> <mbox> <folder>\n", ACE::basename(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
		return -1;
	}

	// get configuration filename
	std::string cfg_file(ACE::basename(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
	if ( cfg_file.rfind('.') != std::string::npos ) cfg_file = ACE::dirname(cfg_file.c_str(), '.');
	cfg_file.insert(0, 1, ACE_DIRECTORY_SEPARATOR_CHAR);
	cfg_file.insert(0, ACE::dirname(cmdline.argv()[0], ACE_DIRECTORY_SEPARATOR_CHAR));
	cfg_file += ".ini";
	ACE_OS::printf("cfg_file:%s\n", cfg_file.c_str()); //@

	// read configurattion
	ACE_Configuration_Heap config;
	config.open();

	ACE_Ini_ImpExp iniIO(config);
	iniIO.import_config(cfg_file.c_str());

	// iterate through entire file (not including sub-section iteration)
	ACE_Configuration_Section_Key sec;
	config.open_section(config.root_section(), ACE_TEXT("Server"), 0, sec);

	ACE_TString value;

	config.get_string_value(sec, ACE_TEXT("Server"), value);
	server = value.c_str();
	ACE_OS::printf("Server: %s\n", server.c_str());
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("Port"), value);
	port = (u_short) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("Port: %d\n", port);
	value.resize(0);

	config.get_string_value(sec, ACE_TEXT("SSL"), value);
	ssl = (int) ACE_OS::atoi(value.c_str());
	ACE_OS::printf("SSL: %d\n", ssl);
	value.resize(0);

	user = argv[1];
	pass = argv[2];
	mbox = argv[3];
	folder = argv[4];

	/*
	server = "192.168.1.19";
	port = 993;
	ssl = 1;
	user = "angus";
	pass = "111111";
	mbox = "Sent";
	folder = "d:\\_send_\\post\\@.sent";
	//*/

	if ( ssl )
	{
		//ACE_INET_Addr server_addr(143, "zcsdemo.cellopoint.com");
		//ACE_SOCK_Connector connector;
		//ACE_SOCK_Stream stream;

		ACE_INET_Addr server_addr(port, server.c_str()); // SSL
		ACE_SSL_SOCK_Connector connector; // SSL
		aos::SSL_Socket_Stream stream; //ACE_SSL_SOCK_Stream stream; // SSL

		ACE_Time_Value timeout(3);
		int flags = 0;

		ACE_Message_Block mb(4096); // read/write buffer
		if ( connector.connect(stream, server_addr, &timeout) != -1 )
		{
			int status = IMAP4_Client_IO::OK;

			IMAP4_Client_IO io;
			io.open("A001");

			// greetings
			io.greetings(stream, flags, &timeout, mb);

			// login
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.login(stream, flags, &timeout, mb, user.c_str(), pass.c_str());
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
			}

			//io.capability(stream, flags, &timeout, mb);
			//io.list(stream, flags, &timeout, mb, "\"\"", "\"*\"");

			// select
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.select(stream, flags, &timeout, mb, mbox.c_str());
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("ERROR: %s\n", io.buf().c_str());
			}

			// open folder
			ACE_OS::printf("Import Folder: %s\n", folder.c_str());
			ACE_Dirent dir;
			ACE_DIRENT* d;

			std::string charset("big5");
			std::string path;

			dir.open(folder.c_str());
			while( (d = dir.read()) != 0 )
			{
				path = folder;
				path += ACE_DIRECTORY_SEPARATOR_CHAR;
				path.append(d->d_name);

				ACE_stat stat;
				if ( ACE_OS::lstat(path.c_str(), &stat) != -1
					&& (stat.st_mode & S_IFMT) == S_IFREG
					&& *(d->d_name) != '.' ) 
				{
					ACE_OS::printf("file: %s\n", path.c_str());
					
					aos::MIME_Entity e;

					// import eml
					e.import_file(path.c_str());

					// process eml
					ZM_Util::zm_fix_ctype_text(e, charset.c_str());
					charset = ZM_Util::zm_get_best_charset(e, charset.c_str());
					::printf("default_charset:%s\n", charset.c_str()); //@
					ZM_Util::zm_fix_mail_header(e, charset.c_str());

					// export eml
					std::string data;
					e.export_data(data);

					// append
					status = io.append_from_data(stream, flags, &timeout, mb, mbox.c_str(), data.c_str(), data.size());
					if ( status != IMAP4_Client_IO::OK )
					{
						ACE_OS::printf("ERROR: %s\n", io.buf().c_str());
						break;
					}
				} // if() // file begin without '.'
			}
			dir.close();

			//// fetch
			//std::string data;
			//io.fetch_to_data(stream, flags, &timeout, mb, "1", "BODY[]", data);
			//ACE_OS::printf("%s\n", data.c_str());

			// logout
			io.logout(stream, flags, &timeout, mb);

			io.close();
			stream.close();
		}
		else
		{
			ACE_OS::printf("connect: %s:%d failed!\n", server.c_str(), port);
		}
	}
	else
	{
		ACE_INET_Addr server_addr(port, server.c_str());
		ACE_SOCK_Connector connector;
		aos::Socket_Stream stream; //ACE_SOCK_Stream stream;

		//ACE_INET_Addr server_addr(port, server.c_str()); // SSL
		//ACE_SSL_SOCK_Connector connector; // SSL
		//ACE_SSL_SOCK_Stream stream; // SSL

		ACE_Time_Value timeout(3);
		int flags = 0;

		ACE_Message_Block mb(4096); // read/write buffer
		if ( connector.connect(stream, server_addr, &timeout) != -1 )
		{
			int status = IMAP4_Client_IO::OK;

			IMAP4_Client_IO io;
			io.open("A001");

			// greetings
			io.greetings(stream, flags, &timeout, mb);

			// login
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.login(stream, flags, &timeout, mb, user.c_str(), pass.c_str());
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
			}

			//io.capability(stream, flags, &timeout, mb);
			//io.list(stream, flags, &timeout, mb, "\"\"", "\"*\"");

			// select
			if ( status == IMAP4_Client_IO::OK )
			{
				status = io.select(stream, flags, &timeout, mb, mbox.c_str());
				if ( status != IMAP4_Client_IO::OK )
					ACE_OS::printf("%s\n", io.buf().c_str());
			}

			// open folder
			ACE_OS::printf("Import Folder: %s\n", folder.c_str());
			ACE_Dirent dir;
			ACE_DIRENT* d;

			std::string charset("big5");
			std::string path;

			dir.open(folder.c_str());
			while( (d = dir.read()) != 0 )
			{
				path = folder;
				path += ACE_DIRECTORY_SEPARATOR_CHAR;
				path.append(d->d_name);

				ACE_stat stat;
				if ( ACE_OS::lstat(path.c_str(), &stat) != -1
					&& (stat.st_mode & S_IFMT) == S_IFREG
					&& *(d->d_name) != '.' ) 
				{
					ACE_OS::printf("file: %s\n", path.c_str());

					aos::MIME_Entity e;

					// import eml
					e.import_file(path.c_str());

					// process eml
					ZM_Util::zm_fix_ctype_text(e, charset.c_str());
					charset = ZM_Util::zm_get_best_charset(e, charset.c_str());
					::printf("default_charset:%s\n", charset.c_str()); //@
					ZM_Util::zm_fix_mail_header(e, charset.c_str());

					// export eml
					std::string data;
					e.export_data(data);

					// append
					status = io.append_from_data(stream, flags, &timeout, mb, mbox.c_str(), data.c_str(), data.size());
					if ( status != IMAP4_Client_IO::OK )
					{
						ACE_OS::printf("%s\n", io.buf().c_str());
						break;
					}
				} // if() // file begin without '.'
			}
			dir.close();

			//// fetch
			//std::string data;
			//io.fetch_to_data(stream, flags, &timeout, mb, "1", "BODY[]", data);
			//ACE_OS::printf("%s\n", data.c_str());

			// logout
			io.logout(stream, flags, &timeout, mb);

			io.close();
			stream.close();
		}
		else
		{
			ACE_OS::printf("connect: %s:%d failed!\n", server.c_str(), port);
		}
	}

	return 0;
}

