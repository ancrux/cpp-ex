#include "ZM_Util.h"

#include "MIME_Util.h"
#include "MIME_Header.h"

#include "unicode/utypes.h" /* Basic ICU data types */
#include "unicode/ucnv.h" /* C Converter API */
#include "unicode/ucsdet.h" /* C Detector API */
#include "unicode/unistr.h" /* UnicodeString class */

#include <boost/regex.hpp>
using namespace boost;

namespace mozart {

const char*
ZM_Util::ZM_DEFAULT_CHARSET = "ISO-8859-1";

void
ZM_Util::zm_fix_mail_header(MIME_Entity& e, const char* default_charset)
{
	static const size_t GUESS_MIN_SIZE = 64;

	if ( e.has_header() )
	{
		MIME_Header hdr;

		std::string replace;
		aos::Base64 base64(0);

		for(MIME_Header_List::iterator it = e.header().begin();
			it != e.header().end();
			++it)
		{
			replace.resize(0);

			if ( aos::strnicmp((*it)->c_str(), "from:", 5) == 0 ||
				aos::strnicmp((*it)->c_str(), "to:", 3) == 0 ||
				aos::strnicmp((*it)->c_str(), "cc:", 3) == 0 ||
				aos::strnicmp((*it)->c_str(), "reply-to:", 9) == 0 ||
				aos::strnicmp((*it)->c_str(), "sender:", 7) == 0 )
			{
				hdr.assign(*(*it), MIME_Header::No_Parser);

				aos::Tokenizer toker;
				toker.set_separator(",\r\n");
				toker.str(hdr.value().c_str(), hdr.value().size());

				std::string token;
				int ch = toker.next();
				while( ch > aos::Tokenizer::End )
				{
					std::string temp(toker.token(), toker.size());
					token += temp;
					if ( token.find('@') == std::string::npos )
					{
						ch = toker.next();
						continue;
					}

					bool is_ascii = true;
					const char* cstr = token.c_str();
					for(size_t i=0; i < token.size(); ++i)
					{
						if ( cstr[i] & 0x80 )
						{
							is_ascii = false;
							break;
						}
					}

					if ( !is_ascii )
					{
						// special handling of from/to email address
						std::string email;
						std::string::size_type e1, e2;
						e1 = token.rfind('<');
						e2 = token.rfind('>');
						if ( e2 != std::string::npos && e1 < e2 )
						{
							email = token.substr(e1, e2-e1+1);
							token.erase(e1, e2-e1+1);
							aos::trim(token, " \t\r\n\"\0\x0B");
						}

						///* base64 encoding
						if ( token.size() > 0 )
						{
							std::string charset;
							//charset = ZM_Util::guess_charset(token.c_str(), token.size());
							//string_lower_inplace(charset);
							//::printf("guess from/to:%s\n", charset.c_str()); //@
							if ( 1 || token.size() < GUESS_MIN_SIZE || charset == "iso-8859-1")
								charset = default_charset;

							std::string tmp(token);
							size_t n_enough_encode = base64.enough_encode_size(token.size());
							token.resize(n_enough_encode);
							size_t n_encode = base64.encode(tmp.c_str(), tmp.size(), (char*) token.c_str());
							token.resize(n_encode);

							token = "=?" + charset + "?B?" + token;
							token += "?=";
						}
						replace += token + email + ',';
						//*/
					}
					else
					{
						replace += token + ',';
					}
					
					ch = toker.next();
					token.resize(0);
				}
				if ( !replace.empty() )
				{
					//if ( replace[replace.size()-1] == ',' )
					//	replace[replace.size()-1] = ' ';

					hdr.address(replace);
					replace.resize(0);

					for(MIME_Header::Pairs::iterator it = hdr.begin();
						it != hdr.end();
						++it)
					{
						MIME_Header hd;
						hd.decode(it->first);
						for(MIME_Header::Pairs::iterator iter = hd.begin();
						iter != hd.end();
						++iter)
						{
							if ( iter->first.empty() )
							{
								replace += iter->second;
								continue;
							}
							
							std::string name(iter->second);
							std::string name_encoded;
							
							size_t n_enough_encode = base64.enough_encode_size(name.size());
							name_encoded.resize(n_enough_encode);
							size_t n_encode = base64.encode(name.c_str(), name.size(), (char*) name_encoded.c_str());
							name_encoded.resize(n_encode);

							replace += "=\?";
							replace += iter->first;
							replace += "\?B\?";
							replace += name_encoded;
							replace += "?=";
						}

						replace += ' ';
						replace += it->second;
						replace += ',';
					}
					if ( !replace.empty() )
					{
						if ( replace[replace.size()-1] == ',' )
							replace.resize(replace.size()-1);
					}
				}
				zm_fix_header_charset(replace);

				replace = ": " + replace;
				replace = hdr.name() + replace;
				replace += "\r\n";

				(*it)->assign(replace);
				::printf("replace:%s\n", replace.c_str());
			}
			else if ( aos::strnicmp((*it)->c_str(), "subject:", 8) == 0 )
			{
				hdr.assign(*(*it), MIME_Header::Decode_Parser);

				for(MIME_Header::Pairs::iterator iter = hdr.begin(); iter != hdr.end(); ++iter)
				{
					// charset: auto-detect if not found
					if ( iter->first.empty() )
					{
						bool is_ascii = true;
						const char* cstr = iter->second.c_str();
						for(size_t i=0; i < iter->second.size(); ++i)
						{
							if ( cstr[i] & 0x80 )
							{
								is_ascii = false;
								break;
							}
						}

						if ( !is_ascii )
						{
							iter->first = MIME_Util::guess_charset(iter->second.c_str(), iter->second.size());
							aos::tolower(iter->first);
							::printf("guess subject:%s\n", iter->first.c_str()); //@

							if ( iter->second.size() < GUESS_MIN_SIZE || iter->first == "iso-8859-1" )
								iter->first = default_charset;
						}
					}

					///* base64 encoding
					if ( iter->first.empty() )
					{
					}
					else if ( iter->second.size() > 0 )
					{
						std::string tmp(iter->second);
						size_t n_enough_encode = base64.enough_encode_size(iter->second.size());
						iter->second.resize(n_enough_encode);
						size_t n_encode = base64.encode(tmp.c_str(), tmp.size(), (char*) iter->second.c_str());
						iter->second.resize(n_encode);

						iter->second = "=?" + iter->first + "?B?" + iter->second;
						iter->second += "?=";
					}
					replace.append(iter->second);
					//*/
				} // for (pairs)
				zm_fix_header_charset(replace);

				replace = ": " + replace;
				replace = hdr.name() + replace;
				replace += "\r\n";

				(*it)->assign(replace);
			} // if (from/to/cc/subject...)
		} // for (headers)

		//add custom header: X-ZM-Fixer
		std::string* pstr = new std::string("X-ZMF-Info: default_cs=");
		pstr->append(default_charset);
		pstr->append("\r\n");
		e.head_header(pstr);
	}

	if ( e.empty_child() && e.get_charset() == "" && e.body().size() > 0 )
	{
		if ( e.find_header("Content-Type", e.header().begin()) == e.header().end() )
		{
			std::string* hdr_ctype = new std::string("Content-Type: text/plain; charset=");
			hdr_ctype->append(default_charset);
			hdr_ctype->append("\r\n");
			e.add_last_header(hdr_ctype);
			//e.add_last_header(new std::string("MIME-Version: 1.0\r\n"));
		}
		e.set_charset(default_charset);
	}
}

void
ZM_Util::zm_fix_ctype_text(MIME_Entity& e, const char* default_charset)
{
	static const size_t GUESS_MIN_SIZE = 256;

	// fix headers
	if ( e.has_header() )
	{
		for(MIME_Header_List::iterator it = e.header().begin();
			it != e.header().end();
			++it)
		{
			if ( (*(*it))[0] == '\r' || (*(*it))[0]  == '\n' ) continue;
			if ( (*it)->find(':') == std::string::npos ) 
			{
				(*it)->insert(0, "X-ZMF: ");
			}
			zm_fix_header_charset(*(*it));
		}
	}

	if ( e.empty_child() )
	{
		// judge if the entity is an attachment
		bool is_attachment = false;
		for(MIME_Header_List::iterator it = e.header().begin();
			it != e.header().end();
			++it)
		{
			if ( aos::strnicmp((*it)->c_str(), "content-disposition:", 20) == 0 )
			{
				is_attachment = true;
				break;
			}
		}

		if ( e.get_primary_type() == "text" && is_attachment == false )
		{
			//::printf("[BODY ctype='%s' encoding='%s' charset='%s']\n", e.get_content_type().c_str(), e.get_encoding().c_str(), e.get_charset().c_str());
			std::string charset(e.get_charset());

			if ( charset.empty() )
			{
				// charset: auto-detect
				std::string decoded_body;
				e.copy_decoded_body(decoded_body);
				std::string cs_guess = MIME_Util::guess_charset(decoded_body.c_str(), decoded_body.size());
				::printf("guess body:%s\n", cs_guess.c_str());

				//std::string encoded_body(e.body());
				//e.decode_body();
				//std::string cs_guess = MIME_Util::guess_charset(e.body().c_str(), e.body().size());
				//::printf("guess body:%s\n", cs_guess.c_str());
				//e.body().assign(encoded_body);
				//MIME_Util::set_status(e, MIME_Util::get_status(e) | MIME_Entity::Status::BODY_ENCODED);

				// if cs_guess == ascii, use default_charset
				aos::tolower(cs_guess);
				if ( e.body().size() < GUESS_MIN_SIZE || ::strncmp(cs_guess.c_str(), "iso-8859", 8) == 0 )
					cs_guess = default_charset;
				e.set_charset(cs_guess.c_str());
			}
			else
			{
				aos::tolower(charset);
				if ( ::strncmp(charset.c_str(), "gb", 2) == 0 ) e.set_charset("GB18030");
				if ( charset.find("big5") != std::string::npos ) e.set_charset("BIG5");
			}
		}
	}
	else
	{
		//size_t n_boundary = e.get_boundary().size();
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			zm_fix_ctype_text(*(*it), default_charset);
		}
	}

	return;
}

void
ZM_Util::zm_fix_header_charset(std::string& hdr)
{
	static const regex re_gb("=\\?(gb2312)\\?(B|Q)\\?", regex::icase);
	//static const regex re_big5("=\\?(.*big5.*)\\?(B|Q)\\?", regex::icase);
	static const regex re_utf7("=\\?(.*utf-7.*)\\?(B|Q)\\?", regex::icase);
	hdr = regex_replace(hdr, re_gb, "=\?GB18030\?$2\?");
	//hdr = regex_replace(hdr, re_big5, "=\?BIG5\?$2\?");
	hdr = regex_replace(hdr, re_utf7, "=\?UTF-7\?$2\?");
}

std::string
ZM_Util::zm_get_best_charset(MIME_Entity& e, const char* default_charset)
{
	std::string charset;
	CHARSET_HITS hits;

	// get mail charset
	std::string cs(e.get_charset());
	if ( !cs.empty() )
		hits.insert(std::make_pair(cs, 1));

	// get mail content charset
	if ( e.has_child() )
	{
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			zm_get_charset_hit(*(*it), hits);
		}
	}

	// use max-hit charset in mail content
	int max_hits = 0;
	for(CHARSET_HITS::iterator it = hits.begin();
		it != hits.end();
		++it)
	{
		if ( it->second > max_hits )
		{
			max_hits = it->second;
			charset = it->first;
			//::printf("%s=%d\n", it->first.c_str(), it->second); //@
		}
	}

	//static const regex re("=\\?([^?]+)\\?(B|Q)\\?([^?]+)\\?=", regex::icase);
	//smatch match;
	//// get "subject" charset
	//if ( charset.empty() )
	//{
	//	MIME_Header_List::iterator it = e.find_header("subject", e.header().begin());
	//	if ( it != e.header().end() && regex_search(*(*it), match, re) )
	//	{
	//		charset.assign(match[1].first, match[1].second);
	//	}
	//}

	//// use "from" charset
	//if ( charset.empty() )
	//{
	//	MIME_Header_List::iterator it = e.find_header("from", e.header().begin());
	//	if ( it != e.header().end() && regex_search(*(*it), match, re) )
	//	{
	//		charset.assign(match[1].first, match[1].second);
	//	}
	//}

	//// use "to" charset
	//if ( charset.empty() )
	//{
	//	MIME_Header_List::iterator it = e.find_header("to", e.header().begin());
	//	if ( it != e.header().end() && regex_search(*(*it), match, re) )
	//	{
	//		charset.assign(match[1].first, match[1].second);
	//	}
	//}

	//// use "cc" charset
	//if ( charset.empty() )
	//{
	//	MIME_Header_List::iterator it = e.find_header("cc", e.header().begin());
	//	if ( it != e.header().end() && regex_search(*(*it), match, re) )
	//	{
	//		charset.assign(match[1].first, match[1].second);
	//	}
	//}

	if ( charset.empty() ) charset = default_charset;

	return charset;
}

void
ZM_Util::zm_get_charset_hit(MIME_Entity& e, CHARSET_HITS& hits)
{
	if ( e.empty_child() )
	{
		std::string cs(e.get_charset());
		if ( !cs.empty() )
		{
			aos::tolower(cs);
			CHARSET_HITS::iterator it = hits.find(cs);
			if ( it != hits.end() )
				it->second += 1;
			else
				hits.insert(std::make_pair(cs, 1));
		}
	}
	else
	{
		for(MIME_Entity_List::iterator it = e.child().begin();
			it != e.child().end();
			++it)
		{
			zm_get_charset_hit(*(*it), hits);
		}
	}
}

} // namespace mozart
