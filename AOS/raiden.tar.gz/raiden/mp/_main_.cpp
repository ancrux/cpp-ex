#include "ace/OS.h"
#include "ace/Get_Opt.h"
#include "ace/Dirent.h"

#include "aos/String.h"
#include "aos/mime/MIME_Entity.h"
using namespace aos;

#include "MP_Worker.h"

#include <string>
#include <iostream>
#include <fstream>
using namespace std;

#include <boost/regex.hpp>
using namespace boost;

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	ACE_Get_Opt cmd(argc, argv, ACE_TEXT(""));

	//if ( cmd.argc() != 2 )
	//{
	//	ACE_OS::printf("Invalid arguments!\r\n");
	//	ACE_OS::exit(1);
	//}

	// print max path
	ACE_OS::printf("max_path:%d\n", MAX_PATH);

	ACE_Time_Value t1 = ACE_OS::gettimeofday();

	MP_Worker mp;

	mp.activate(THR_NEW_LWP | THR_JOINABLE, 1); //ACE_OS::num_processors_online());

	MIME_Entity e;

	// delete log
	ACE_OS::unlink("d:/_spam_/_log_/utf-8.txt");

	// search for all files in path
	ACE_TCHAR path[MAX_PATH+1];
	ACE_OS::strncpy(path, "d:/_spam_/2009-01-31/", MAX_PATH);
	//ACE_OS::strncpy(path, "d:/_spam_/_test_/", MAX_PATH);
	size_t n_path = ACE_OS::strlen(path);
	// dirent
	ACE_Dirent dir;
	ACE_DIRENT* d;

	int n_file = 0;

	cout << "ACE_Dirent: " << path << endl;
	cout << "open: " << dir.open(path) << endl;

	while( (d = dir.read()) != 0 )
	{
		ACE_stat stat;
		ACE_OS::strcpy(path + n_path, d->d_name);
		if ( ACE_OS::lstat(path, &stat) != -1 && (stat.st_mode & S_IFMT) == S_IFREG ) 
		{
			if (  1 || n_file >=0 && n_file < 100 )
			{
			///*
			ACE_Message_Block* mb = new ACE_Message_Block(strlen(path)+1);
			mb->copy(path);
			mp.msg_queue()->enqueue_tail(mb);
			//*/
			}

			/*
			//cout << path << endl;
			e.import_file(path);
			//cout << e.get_content_type() << endl;
			//*/

			++n_file;
		}
	}
	dir.close();
	path[n_path] = '\0'; // restore path length
	
	// send stop signal
	for(size_t i = 0, c = mp.thr_count(); i < c; ++i)
		mp.msg_queue()->enqueue_tail(new ACE_Message_Block(""));

	mp.wait();
	//*/

	ACE_Time_Value t2 = ACE_OS::gettimeofday();

	ACE_OS::printf("elasped:%d\n", t2.msec()-t1.msec());
	::printf("total files:%d\n", n_file);

	return 0;
}