#include "ace/OS.h"
#include "ace/Get_Opt.h"
#include "ace/Configuration_Import_Export.h"

//test
#include "ace/File_Lock.h"
#include "ace/Atomic_Op.h"

#include "aos/String.h"
using namespace aos;

#include <iostream>
using namespace std;

#include "_main_.h"

int ACE_TMAIN(int argc, ACE_TCHAR* argv[])
{
	// get console parameters
	ACE_Get_Opt cmd(argc, argv, ACE_TEXT(""));

	if ( cmd.argc() < 3 )
	{
		ACE_OS::printf("Invalid arguments!\r\n");
		ACE_OS::exit(1);
	}

	// get raiden maild root
	HKEY hkey = ACE_Configuration_Win32Registry::resolve_key(
		HKEY_LOCAL_MACHINE,
		ACE_TEXT("SOFTWARE\\RaidenMAILDService"));
	ACE_Configuration_Win32Registry w32reg(hkey);

	ACE_TString curr_val;
	w32reg.get_string_value(w32reg.root_section(), ACE_TEXT("EXEPATH"), curr_val);

	ACE_TString raiden_root;
	ACE_TString::size_type pos = curr_val.rfind(ACE_DIRECTORY_SEPARATOR_CHAR);
	if ( pos != ACE_TString::npos )
		raiden_root = curr_val.substr(0, pos);

	if ( raiden_root == "" )
	{
		// failed to locate RaidenMaild root
		ACE_OS::exit(1);
	}

	ACE_TString m_id = ACE::dirname(ACE::basename(cmd.argv()[1]), '.');
	ACE_TString account_dir = ACE::dirname(cmd.argv()[1]);
	ACE_TString target_dir = raiden_root + "\\mq\\in";
	ACE_TString target_eml = target_dir + "\\" + m_id + ".eml";
	ACE_TString target_evp = target_dir + "\\" + m_id + ".evp";

	// create evp
	FILE* fp = ACE_OS::fopen(target_evp.c_str(), "wb");
	if ( !fp )
	{
		// failed to open evp
		ACE_OS::exit(1);
	}
	
	ACE_OS::fputs("MBOX=", fp);
	ACE_OS::fputs(account_dir.c_str(), fp);
	ACE_OS::fputs("\n", fp);

	ACE_OS::fputs("USER=", fp);
	ACE_OS::fputs(cmd.argv()[2], fp);
	ACE_OS::fputs("\n", fp);

	ACE_OS::fclose(fp);

	// move eml
	int res = ACE_OS::rename(cmd.argv()[1], target_eml.c_str()); // return 0 == OK, -1 == FAILED
	if ( res != 0 )
	{
		// failed to move eml
		ACE_OS::exit(1);
	}

	return 0;
}